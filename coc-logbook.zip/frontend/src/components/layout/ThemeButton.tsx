import { toggleTheme, useSettings } from "../../store/useSettings";

/** 「浅/深」按钮：三个模块共用，选择持久化 */
export function ThemeButton({ testid = "theme-toggle" }: { testid?: string }) {
  const theme = useSettings((s) => s.settings.theme);
  return (
    <button
      className="btn"
      data-testid={testid}
      onClick={() => void toggleTheme()}
      title={theme === "dark" ? "切换到浅色" : "切换到深色"}
    >
      浅/深
    </button>
  );
}
