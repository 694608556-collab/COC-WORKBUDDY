import { NavLink } from "react-router-dom";

const ITEMS = [
  { to: "/records", key: "records", label: "跑团记录汇总" },
  { to: "/characters", key: "characters", label: "调查员角色卡" },
  { to: "/settings", key: "settings", label: "数据与设置" },
];

/**
 * 侧边导航：当前模块前用圆点高亮（不是灰色圆角方块）
 */
export function SideNav() {
  return (
    <div className="side" data-testid="sidenav">
      {ITEMS.map((it) => (
        <NavLink
          key={it.key}
          to={it.to}
          data-testid={`nav-${it.key}`}
          className={({ isActive }) => (isActive ? "nav on" : "nav")}
        >
          {({ isActive }) => (
            <>
              <i className="dot" data-active={isActive ? "true" : "false"} />
              <span>{it.label}</span>
            </>
          )}
        </NavLink>
      ))}
    </div>
  );
}
