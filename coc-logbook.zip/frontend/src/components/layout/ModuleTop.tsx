import type { ReactNode } from "react";

const HEIGHT_VAR: Record<string, string> = {
  m1: "var(--top-h-m1)",
  m2: "var(--top-h-m2)",
  m3: "var(--top-h-m3)",
};

const HEIGHT_PX: Record<string, string> = {
  m1: "54px",
  m2: "72px",
  m3: "72px",
};

type Props = {
  /** 模块编号，决定标题栏高度：模块一 54px，模块二 / 三 72px */
  module: "m1" | "m2" | "m3";
  title: string;
  subtitle?: string;
  actions?: ReactNode;
};

export function ModuleTop({ module, title, subtitle, actions }: Props) {
  return (
    <div
      className="top"
      data-testid="module-top"
      data-module={module}
      data-height={HEIGHT_PX[module]}
      style={{ height: HEIGHT_VAR[module] }}
    >
      <div>
        <div className="t1">{title}</div>
        {subtitle ? <div className="t2">{subtitle}</div> : null}
      </div>
      {actions ? <div className="actions">{actions}</div> : null}
    </div>
  );
}
