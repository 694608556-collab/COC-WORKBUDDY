/**
 * 标题栏：左侧应用名（纯文字，无图标色块），右侧三个圆点（微软布局）
 */
export function Winbar() {
  return (
    <div className="winbar" data-testid="winbar">
      <span className="brand" data-testid="brand">
        COC 跑团记录簿
      </span>
      <div className="wbs">
        <i className="wb min" data-testid="wb-min" title="最小化" />
        <i className="wb max" data-testid="wb-max" title="最大化" />
        <i className="wb close" data-testid="wb-close" title="关闭" />
      </div>
    </div>
  );
}
