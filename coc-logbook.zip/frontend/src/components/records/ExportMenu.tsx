type Props = {
  onCsv: () => void;
  onXlsx: () => void;
};

/** 「导出表格 ▾」按钮：展开 CSV / Excel 两种导出方式 */
export function ExportMenu({ onCsv, onXlsx }: Props) {
  return (
    <span className="dl">
      <button className="btn" data-testid="export-open">
        导出表格 ▾
      </button>
      <span className="dl-menu" data-testid="export-menu">
        <button className="dl-item" data-testid="export-csv" onClick={onCsv}>
          导出 CSV
        </button>
        <button className="dl-item" data-testid="export-xlsx" onClick={onXlsx}>
          导出 Excel
        </button>
      </span>
    </span>
  );
}
