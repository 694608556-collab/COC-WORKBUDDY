import { useState } from "react";

export type MergeKind = "docx" | "txt" | "pdf";

type Props = {
  open: boolean;
  /** 已勾选的记录条数 */
  count: number;
  onCancel: () => void;
  onMerge: (kind: MergeKind) => void;
};

const KINDS: { value: MergeKind; label: string }[] = [
  { value: "docx", label: "docx" },
  { value: "txt", label: "TXT" },
  { value: "pdf", label: "PDF" },
];

/** 「批量合成」弹窗：选择合并文档的格式 */
export function MergeDialog({ open, count, onCancel, onMerge }: Props) {
  const [kind, setKind] = useState<MergeKind>("docx");
  if (!open) return null;

  return (
    <div className="mask" data-testid="merge-dialog">
      <div className="dlg" style={{ width: 420 }}>
        <div className="dh">批量合成</div>
        <div className="db">
          <div className="hint" style={{ marginBottom: 10 }}>
            {count > 0
              ? `把勾选的 ${count} 条记录正文合并成一份文档，顺序按「模组 + 场次」排列。未抓取正文的场次会被跳过。`
              : "还没勾选记录：先在表格里勾选要合并的记录，再点「批量合成」。"}
          </div>
          <div className="field">
            <label className="lb">合并格式</label>
            <div className="seg" data-testid="merge-kind">
              {KINDS.map((k) => (
                <span
                  key={k.value}
                  className={kind === k.value ? "on" : ""}
                  data-testid={`merge-${k.value}`}
                  onClick={() => setKind(k.value)}
                >
                  {k.label}
                </span>
              ))}
            </div>
          </div>
        </div>
        <div className="dfoot">
          <button className="btn" data-testid="merge-cancel" onClick={onCancel}>
            取消
          </button>
          <button className="btn primary" data-testid="merge-confirm" onClick={() => onMerge(kind)}>
            生成合并文档
          </button>
        </div>
      </div>
    </div>
  );
}
