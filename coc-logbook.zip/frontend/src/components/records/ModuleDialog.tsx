import { useEffect, useState } from "react";
import type { ParticipantPair } from "../../lib/types";

export type ModuleForm = {
  name: string;
  kps: string[];
  pairs: ParticipantPair[];
};

type Props = {
  open: boolean;
  mode: "new" | "edit";
  initial?: ModuleForm;
  onCancel: () => void;
  onSave: (form: ModuleForm) => void;
  onDelete?: () => void;
};

const EMPTY: ModuleForm = { name: "", kps: [""], pairs: [{ pc: "", pl: "" }] };

export function ModuleDialog({ open, mode, initial, onCancel, onSave, onDelete }: Props) {
  const [form, setForm] = useState<ModuleForm>(EMPTY);

  useEffect(() => {
    if (!open) return;
    setForm(
      initial
        ? {
            name: initial.name,
            kps: initial.kps.length ? [...initial.kps] : [""],
            pairs: initial.pairs.length ? [...initial.pairs] : [{ pc: "", pl: "" }],
          }
        : { name: "", kps: [""], pairs: [{ pc: "", pl: "" }] },
    );
  }, [open, initial]);

  if (!open) return null;

  const setKp = (i: number, v: string) => {
    const kps = [...form.kps];
    kps[i] = v;
    setForm({ ...form, kps });
  };
  const removeKp = (i: number) => setForm({ ...form, kps: form.kps.filter((_, k) => k !== i) });
  const setPair = (i: number, key: keyof ParticipantPair, v: string) => {
    const pairs = form.pairs.map((p, k) => (k === i ? { ...p, [key]: v } : p));
    setForm({ ...form, pairs });
  };
  const removePair = (i: number) =>
    setForm({ ...form, pairs: form.pairs.filter((_, k) => k !== i) });

  const submit = () => {
    onSave({
      name: form.name.trim() || "未命名模组",
      kps: form.kps.map((k) => k.trim()).filter(Boolean),
      pairs: form.pairs
        .map((p) => ({ pc: p.pc.trim(), pl: p.pl.trim() }))
        .filter((p) => p.pc || p.pl),
    });
  };

  return (
    <div className="mask" data-testid="module-dialog">
      <div className="dlg">
        <div className="dh">{mode === "new" ? "新建模组" : "编辑模组"}</div>
        <div className="db">
          <div className="field">
            <label className="lb">模组名</label>
            <input
              className="inp"
              data-testid="module-name"
              value={form.name}
              placeholder="例：暗影循迹"
              onChange={(e) => setForm({ ...form, name: e.target.value })}
            />
          </div>

          <hr />

          <div className="field">
            <div className="sub">
              <b>参与者</b>
              <span>整个模组共用一份名单，该模组下所有场次都使用这份名单</span>
            </div>

            <div className="sub">
              <span>KP（守密人） · 可添加多位</span>
            </div>
            <div data-testid="kp-rows">
              {form.kps.map((kp, i) => (
                <div className="kp-row" key={`kp-${i}`} style={rowStyle}>
                  <span className="tag">KP</span>
                  <input
                    className="inp"
                    data-testid={`kp-input-${i}`}
                    value={kp}
                    placeholder="守密人名称"
                    onChange={(e) => setKp(i, e.target.value)}
                  />
                  <button
                    className="del"
                    data-testid={`kp-del-${i}`}
                    title="删除"
                    onClick={() => removeKp(i)}
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
            <button
              className="add"
              data-testid="kp-add"
              onClick={() => setForm({ ...form, kps: [...form.kps, ""] })}
            >
              + 添加 KP
            </button>

            <hr className="dash" />

            <div className="sub">
              <span>PC（角色）与 PL（玩家） · 一一对应，成对填写</span>
            </div>
            <div data-testid="pair-rows">
              {form.pairs.map((p, i) => (
                <div className="pair-row" key={`pair-${i}`} style={pairRowStyle}>
                  <span className="tag" data-testid={`pc-tag-${i}`}>
                    PC{i + 1}
                  </span>
                  <input
                    className="inp"
                    data-testid={`pc-input-${i}`}
                    value={p.pc}
                    placeholder="角色名"
                    onChange={(e) => setPair(i, "pc", e.target.value)}
                  />
                  <span className="tag dash" data-testid={`pl-tag-${i}`}>
                    PL{i + 1}
                  </span>
                  <input
                    className="inp"
                    data-testid={`pl-input-${i}`}
                    value={p.pl}
                    placeholder="玩家名"
                    onChange={(e) => setPair(i, "pl", e.target.value)}
                  />
                  <button
                    className="del"
                    data-testid={`pair-del-${i}`}
                    title="删除这一对"
                    onClick={() => removePair(i)}
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
            <button
              className="add"
              data-testid="pair-add"
              onClick={() => setForm({ ...form, pairs: [...form.pairs, { pc: "", pl: "" }] })}
            >
              + 添加角色与玩家（PC / PL）
            </button>
            <div className="hint">
              编号会自动重排。删除某一对时，角色与玩家一起移除；数量不限，可随时添加或删除。
            </div>
          </div>
        </div>

        <div className="dfoot">
          {mode === "edit" && onDelete ? (
            <button className="danger-link" data-testid="module-delete" onClick={onDelete}>
              删除模组
            </button>
          ) : null}
          <button
            className="btn"
            data-testid="module-cancel"
            style={{ marginLeft: mode === "edit" ? 0 : "auto" }}
            onClick={onCancel}
          >
            取消
          </button>
          <button className="btn primary" data-testid="module-save" onClick={submit}>
            保存
          </button>
        </div>
      </div>
    </div>
  );
}

const rowStyle: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "46px 1fr 24px",
  gap: 8,
  alignItems: "center",
  marginBottom: 8,
};

const pairRowStyle: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "46px 1fr 46px 1fr 24px",
  gap: 8,
  alignItems: "center",
  marginBottom: 8,
};
