import type { Module, RecordItem } from "../../lib/types";
import type { DownloadKind } from "../../lib/export";
import { FolderIcon } from "../ui/FolderIcon";
import { RecordTable } from "./RecordTable";

type Props = {
  module: Module;
  records: RecordItem[];
  /** 正在检测的记录 id */
  checkingId?: string | null;
  isFirst: boolean;
  isLast: boolean;
  selectedIds: Set<string>;
  statusSummary: string;
  onToggle: () => void;
  onEditModule: () => void;
  onAddRecord: () => void;
  onCheck: (r: RecordItem) => void;
  onDownload: (r: RecordItem, kind: DownloadKind) => void;
  onTxt: (r: RecordItem) => void;
  onPdf: (r: RecordItem) => void;
  onEditRecord: (r: RecordItem) => void;
  onDeleteRecord: (r: RecordItem) => void;
  onFolder: (moduleName: string) => void;
  onSelectAll: (checked: boolean) => void;
  onMoveModule: (dir: -1 | 1) => void;
  onToggleSelect: (id: string) => void;
  onMoveRecord: (r: RecordItem, dir: -1 | 1) => void;
};

export function ModuleGroup({
  module,
  records,
  checkingId,
  isFirst,
  isLast,
  selectedIds,
  statusSummary,
  onToggle,
  onEditModule,
  onAddRecord,
  onCheck,
  onDownload,
  onTxt,
  onPdf,
  onEditRecord,
  onDeleteRecord,
  onFolder,
  onSelectAll,
  onMoveModule,
  onToggleSelect,
  onMoveRecord,
}: Props) {
  const kp = module.kps.filter(Boolean);
  const pairs = module.pairs.filter((p) => p.pc || p.pl);
  const tail = [
    kp.length ? `KP ${kp.join("、")}` : null,
    pairs.length ? `${pairs.length} 名调查员` : null,
  ]
    .filter(Boolean)
    .join(" · ");
  const allSelected = records.length > 0 && records.every((r) => selectedIds.has(r.id));

  return (
    <div className="grp" data-testid={`module-${module.id}`} data-collapsed={module.collapsed ? "1" : "0"}>
      <div className={`gh${module.collapsed ? " collapsed" : ""}`}>
        <button
          className="fold"
          data-testid={`fold-${module.id}`}
          title={module.collapsed ? "展开" : "折叠"}
          onClick={onToggle}
        >
          {module.collapsed ? "▸" : "▾"}
        </button>
        <span className="gname" data-testid={`gname-${module.id}`} onClick={onEditModule}>
          {module.name}
        </span>
        <span className="cnt" data-testid={`count-${module.id}`}>
          {records.length} 条记录
        </span>
        <button className="ico" data-testid={`folder-${module.id}`} title="打开该模组的归档文件夹" onClick={() => onFolder(module.name)}>
          <FolderIcon />
        </button>
        <label className="selall" title="全选本模组">
          <input
            type="checkbox"
            className="cbx"
            data-testid={`module-selectall-${module.id}`}
            checked={allSelected}
            onChange={(e) => onSelectAll(e.target.checked)}
          />
          全选
        </label>
        <button className="ico" data-testid={`add-${module.id}`} title="新增场次" onClick={onAddRecord}>
          ＋
        </button>
        <button
          className="ico"
          data-testid={`module-up-${module.id}`}
          title="上移模组"
          disabled={isFirst}
          onClick={() => onMoveModule(-1)}
        >
          ↑
        </button>
        <button
          className="ico"
          data-testid={`module-down-${module.id}`}
          title="下移模组"
          disabled={isLast}
          onClick={() => onMoveModule(1)}
        >
          ↓
        </button>
        {tail ? (
          <span className="tail" data-testid={`tail-${module.id}`}>
            {tail}
          </span>
        ) : null}
        {statusSummary ? (
          <span className="stsum" data-testid={`stsum-${module.id}`}>
            {statusSummary}
          </span>
        ) : null}
      </div>
      {module.collapsed ? null : (
        <RecordTable
          records={records}
          checkingId={checkingId}
          selectedIds={selectedIds}
          onToggleSelect={onToggleSelect}
          onMove={onMoveRecord}
          onCheck={onCheck}
          onDownload={onDownload}
          onTxt={onTxt}
          onPdf={onPdf}
          onEdit={onEditRecord}
          onDelete={onDeleteRecord}
        />
      )}
    </div>
  );
}
