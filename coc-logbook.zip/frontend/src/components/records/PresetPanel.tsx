import { useEffect, useState } from "react";
import { useSettings } from "../../store/useSettings";
import {
  DEFAULT_EXPORT_OPTIONS,
  type ExportOptions,
} from "../../lib/types";

const OPTIONS: { key: keyof ExportOptions; label: string }[] = [
  { key: "filterDice", label: "骰子指令过滤" },
  { key: "filterImage", label: "表情图片过滤" },
  { key: "filterOoc", label: "场外发言过滤" },
  { key: "filterTime", label: "时间显示过滤" },
  { key: "hideAccount", label: "平台账号隐藏" },
  { key: "hideDate", label: "年月日不展示" },
  { key: "indentFirstLine", label: "首行缩进对齐" },
  { key: "darkMode", label: "深色模式展示" },
];

type Props = { open: boolean; onClose: () => void };

export function PresetPanel({ open, onClose }: Props) {
  const options = useSettings((s) => s.settings.exportOptions);
  const patch = useSettings((s) => s.patch);
  const [local, setLocal] = useState<ExportOptions>(options);

  useEffect(() => {
    if (open) setLocal(options);
  }, [open, options]);

  if (!open) return null;

  const toggle = (key: keyof ExportOptions) => {
    const next = { ...local, [key]: !local[key] };
    setLocal(next);
    void patch({ exportOptions: next });
  };

  const reset = () => {
    setLocal({ ...DEFAULT_EXPORT_OPTIONS });
    void patch({ exportOptions: { ...DEFAULT_EXPORT_OPTIONS } });
  };

  return (
    <div className="mask" data-testid="preset-panel">
      <div className="dlg" style={{ width: 420 }}>
        <div className="dh">选项预设</div>
        <div className="db">
          <div className="hint" style={{ marginBottom: 10 }}>
            海豹日志页面的过滤选项，勾选状态全局记忆，导出时按此生效。
          </div>
          {OPTIONS.map((o) => (
            <div className="preset-row" key={o.key}>
              <span>{o.label}</span>
              <button
                className={`sw${local[o.key] ? " on" : ""}`}
                data-testid={`preset-${o.key}`}
                role="switch"
                aria-checked={local[o.key]}
                onClick={() => toggle(o.key)}
              >
                <i />
              </button>
            </div>
          ))}
        </div>
        <div className="dfoot">
          <button className="btn" data-testid="preset-reset" style={{ marginRight: "auto" }} onClick={reset}>
            恢复默认
          </button>
          <button className="btn primary" data-testid="preset-close" onClick={onClose}>
            完成
          </button>
        </div>
      </div>
    </div>
  );
}
