import type { RecordItem } from "../../lib/types";
import type { DownloadKind } from "../../lib/export";
import { DownloadMenu } from "./DownloadMenu";

const STATUS_TEXT: Record<RecordItem["status"], string> = {
  unknown: "待检测",
  valid: "有效",
  dead: "失效",
};

const STATUS_CLASS: Record<RecordItem["status"], string> = {
  unknown: "st wa",
  valid: "st ok",
  dead: "st no",
};

function statusLabel(r: RecordItem): { text: string; cls: string } {
  // 手动粘贴、且尚未联网检测（状态仍为待检测）的记录才标为「手动内容」
  if (!r.link && r.manualText && r.status === "unknown") {
    return { text: "手动内容", cls: "st wa" };
  }
  return { text: STATUS_TEXT[r.status], cls: STATUS_CLASS[r.status] };
}

type Props = {
  records: RecordItem[];
  /** 正在检测的记录 id */
  checkingId?: string | null;
  selectedIds: Set<string>;
  onToggleSelect: (id: string) => void;
  onMove: (r: RecordItem, dir: -1 | 1) => void;
  onCheck: (r: RecordItem) => void;
  onDownload: (r: RecordItem, kind: DownloadKind) => void;
  onTxt: (r: RecordItem) => void;
  onPdf: (r: RecordItem) => void;
  onEdit: (r: RecordItem) => void;
  onDelete: (r: RecordItem) => void;
};

export function RecordTable({
  records,
  checkingId,
  selectedIds,
  onToggleSelect,
  onMove,
  onCheck,
  onDownload,
  onTxt,
  onPdf,
  onEdit,
  onDelete,
}: Props) {
  return (
    <div data-testid="record-table">
      <div className="trow th" style={cols}>
        <span style={{ textAlign: "center" }}>选择</span>
        <span>名称</span>
        <span>状态</span>
        <span>跑团日期</span>
        <span style={{ textAlign: "right" }}>操作</span>
      </div>
      {records.length === 0 ? (
        <div className="trow" style={{ ...cols, height: 44 }}>
          <span className="hint" style={{ gridColumn: "1 / -1" }}>
            这个模组还没有场次，点标题行右侧的「＋」新增
          </span>
        </div>
      ) : (
        records.map((r, i) => {
          const st = statusLabel(r);
          return (
            <div className="trow" key={r.id} data-testid={`rec-row-${r.id}`} style={cols}>
              <span style={{ textAlign: "center" }}>
                <input
                  type="checkbox"
                  className="cbx"
                  data-testid={`rec-select-${r.id}`}
                  checked={selectedIds.has(r.id)}
                  onChange={() => onToggleSelect(r.id)}
                />
              </span>
              <span data-testid={`rec-name-${r.id}`} title={r.name} style={ellipsis}>
                {r.name}
              </span>
              <span className={st.cls} data-testid={`rec-status-${r.id}`}>
                {st.text}
              </span>
              <span data-testid={`rec-date-${r.id}`} className="cnt">
                {r.playDate ?? "—"}
              </span>
              <span className="ops">
                <button
                  className="lnk"
                  data-testid={`check-${r.id}`}
                  disabled={checkingId === r.id}
                  onClick={() => onCheck(r)}
                >
                  {checkingId === r.id ? "检测中…" : "检测"}
                </button>
                <DownloadMenu id={r.id} onPick={(k) => onDownload(r, k)} />
                <button className="lnk" data-testid={`txt-${r.id}`} onClick={() => onTxt(r)}>
                  TXT
                </button>
                <button className="lnk" data-testid={`pdf-${r.id}`} onClick={() => onPdf(r)}>
                  PDF
                </button>
                <button
                  className="lnk"
                  data-testid={`rec-up-${r.id}`}
                  disabled={i === 0}
                  title="上移"
                  onClick={() => onMove(r, -1)}
                >
                  ↑
                </button>
                <button
                  className="lnk"
                  data-testid={`rec-down-${r.id}`}
                  disabled={i === records.length - 1}
                  title="下移"
                  onClick={() => onMove(r, 1)}
                >
                  ↓
                </button>
                <button className="lnk" data-testid={`rec-edit-${r.id}`} onClick={() => onEdit(r)}>
                  编辑
                </button>
                <button className="lnk" data-testid={`rec-del-${r.id}`} onClick={() => onDelete(r)}>
                  删除
                </button>
              </span>
            </div>
          );
        })
      )}
    </div>
  );
}

const cols: React.CSSProperties = {
  gridTemplateColumns: "44px 1.3fr 64px 96px 400px",
  gap: 8,
};

const ellipsis: React.CSSProperties = {
  overflow: "hidden",
  textOverflow: "ellipsis",
  whiteSpace: "nowrap",
};
