import { useState } from "react";
import type { DownloadKind } from "../../lib/export";
import { DOWNLOAD_LABELS } from "../../lib/export";

const MENU_KINDS: DownloadKind[] = ["raw", "imagedoc", "dialog", "docx"];

type Props = {
  id: string;
  onPick: (kind: DownloadKind) => void;
};

/** 记录行「下载 ▾」按钮：展开海豹页面的四种下载方式 */
export function DownloadMenu({ id, onPick }: Props) {
  const [open, setOpen] = useState(false);

  return (
    <span className="dl">
      <button className="lnk" data-testid={`dl-${id}`} onClick={() => setOpen((v) => !v)}>
        下载 ▾
      </button>
      {open ? (
        <span className="dl-menu" data-testid={`dl-menu-${id}`}>
          {MENU_KINDS.map((k) => (
            <button
              key={k}
              className="dl-item"
              data-testid={`dl-${k}-${id}`}
              onClick={() => {
                setOpen(false);
                onPick(k);
              }}
            >
              {DOWNLOAD_LABELS[k]}
            </button>
          ))}
        </span>
      ) : null}
    </span>
  );
}
