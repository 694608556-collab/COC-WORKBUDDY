import { useRef, useState } from "react";
import {
  downloadTableCsv,
  importTableRows,
  parseTableCsv,
  parseTableXlsx,
  type ImportResult,
  type TableRow,
} from "../../lib/table";

type Props = {
  open: boolean;
  onCancel: () => void;
  onDone: (result: ImportResult) => void;
};

export function ImportTableDialog({ open, onCancel, onDone }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);

  if (!open) return null;

  const handleFile = async (file: File) => {
    setBusy(true);
    setMsg("");
    try {
      let rows: TableRow[] = [];
      if (file.name.toLowerCase().endsWith(".csv")) {
        rows = parseTableCsv(await file.text());
      } else {
        rows = await parseTableXlsx(file);
      }
      if (!rows.length) {
        setMsg("没有读取到任何数据行");
        setBusy(false);
        return;
      }
      const result = await importTableRows(rows);
      onDone(result);
    } catch (err) {
      setMsg(err instanceof Error ? err.message : "导入失败");
      setBusy(false);
    }
  };

  return (
    <div className="mask" data-testid="table-import-dialog">
      <div className="dlg" style={{ width: 460 }}>
        <div className="dh">导入表格（csv / xlsx / xls）</div>
        <div className="db">
          <div className="hint" style={{ marginBottom: 10 }}>
            支持本应用导出的表格，也支持外部表格。导入时会自动识别「链接」列并生成对应场次；模组按名称复用，不会重复创建。
          </div>
          <button className="btn" data-testid="table-template" onClick={() => downloadTableCsv([], [])}>
            另存空白模板
          </button>
          <div style={{ height: 10 }} />
          <input
            ref={inputRef}
            type="file"
            accept=".csv,.xlsx,.xls"
            data-testid="table-import-file"
            style={{ display: "block" }}
            disabled={busy}
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) void handleFile(f);
            }}
          />
          {msg ? (
            <div className="hint" style={{ marginTop: 8 }}>
              {msg}
            </div>
          ) : null}
        </div>
        <div className="dfoot">
          <button className="btn" data-testid="table-import-cancel" onClick={onCancel} disabled={busy}>
            关闭
          </button>
        </div>
      </div>
    </div>
  );
}
