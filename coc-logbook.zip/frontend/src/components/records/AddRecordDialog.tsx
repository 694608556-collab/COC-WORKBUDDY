import { useEffect, useState } from "react";

export type RecordForm = {
  name: string;
  link: string;
  manualText: string;
  playDate: string;
};

type Props = {
  open: boolean;
  mode: "new" | "edit";
  moduleName: string;
  /** 新增时的默认名称提示，例：暗影循迹第三场 */
  autoNameHint: string;
  initial?: RecordForm;
  onCancel: () => void;
  onSave: (form: RecordForm) => void;
};

export function AddRecordDialog({
  open,
  mode,
  moduleName,
  autoNameHint,
  initial,
  onCancel,
  onSave,
}: Props) {
  const [form, setForm] = useState<RecordForm>({ name: "", link: "", manualText: "", playDate: "" });
  const [pasteOpen, setPasteOpen] = useState(false);

  useEffect(() => {
    if (!open) return;
    setForm(initial ?? { name: "", link: "", manualText: "", playDate: "" });
    setPasteOpen(Boolean(initial?.manualText));
  }, [open, initial]);

  if (!open) return null;

  return (
    <div className="mask" data-testid="record-dialog">
      <div className="dlg">
        <div className="dh">{mode === "new" ? "新增场次" : "编辑场次"}</div>
        <div className="db">
          <div className="field">
            <label className="lb">所属模组</label>
            <input className="inp" data-testid="record-module" value={moduleName} readOnly />
          </div>

          <div className="field">
            <label className="lb">名称</label>
            <input
              className="inp"
              data-testid="record-name"
              value={form.name}
              placeholder={autoNameHint}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
            />
            <div className="hint">留空则按「{autoNameHint}」自动生成</div>
          </div>

          <div className="field">
            <label className="lb">跑团链接</label>
            <input
              className="inp"
              data-testid="record-link"
              value={form.link}
              placeholder="https://log.weizaima.com/?key=xxxx#123456"
              onChange={(e) => setForm({ ...form, link: e.target.value })}
            />
          </div>

          <div className="field">
            <label className="lb">跑团日期</label>
            <input
              className="inp"
              data-testid="record-date"
              value={form.playDate}
              placeholder="留空则检测时自动填入"
              onChange={(e) => setForm({ ...form, playDate: e.target.value })}
            />
            <div className="hint">
              检测时会自动取自记录首页第一行的时间；抓不到可以自己填，格式 2026-09-04
            </div>
          </div>

          <button className="lnk" data-testid="record-paste-toggle" onClick={() => setPasteOpen((v) => !v)}>
            链接抓取失败？可 手动粘贴记录文本
          </button>
          {pasteOpen ? (
            <div className="field" style={{ marginTop: 8 }}>
              <textarea
                className="ta"
                data-testid="record-paste"
                rows={6}
                style={{ width: "100%" }}
                placeholder="把海豹日志页面里的记录文本整段粘贴进来"
                value={form.manualText}
                onChange={(e) => setForm({ ...form, manualText: e.target.value })}
              />
            </div>
          ) : null}
        </div>

        <div className="dfoot">
          <button className="btn" data-testid="record-cancel" style={{ marginLeft: "auto" }} onClick={onCancel}>
            取消
          </button>
          <button
            className="btn primary"
            data-testid="record-save"
            onClick={() => onSave({ ...form })}
          >
            保存
          </button>
        </div>
      </div>
    </div>
  );
}
