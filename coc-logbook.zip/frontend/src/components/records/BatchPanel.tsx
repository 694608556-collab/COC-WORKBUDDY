import { useState } from "react";
import type { DownloadKind } from "../../lib/export";
import { DOWNLOAD_LABELS } from "../../lib/export";

const KINDS: DownloadKind[] = ["raw", "imagedoc", "dialog", "docx", "txt", "pdf"];

type Props = {
  open: boolean;
  /** 已勾选的记录条数 */
  count: number;
  onClose: () => void;
  onRun: (kind: DownloadKind) => void;
};

/** 批量下载：六项单选，确认后对勾选的记录逐条生成 */
export function BatchPanel({ open, count, onClose, onRun }: Props) {
  const [kind, setKind] = useState<DownloadKind>("docx");

  if (!open) return null;

  return (
    <div className="mask" data-testid="batch-panel">
      <div className="dlg" style={{ width: 420 }}>
        <div className="dh">批量下载 · 选择格式</div>
        <div className="db">
          <div className="hint" style={{ marginBottom: 10 }}>
            {count > 0
              ? `已勾选 ${count} 条记录，勾选一种格式后确认，逐条生成对应文件并归档。`
              : "还没勾选记录：先在表格里勾选要下载的记录，再打开这个面板。"}
          </div>
          <div className="batch-list">
            {KINDS.map((k) => (
              <label className="batch-item" key={k} data-testid={`batch-${k}`}>
                <input
                  type="radio"
                  name="batch-kind"
                  checked={kind === k}
                  onChange={() => setKind(k)}
                />
                <span>{DOWNLOAD_LABELS[k]}</span>
              </label>
            ))}
          </div>
        </div>
        <div className="dfoot">
          <button className="btn" data-testid="batch-cancel" onClick={onClose}>
            取消
          </button>
          <button
            className="btn primary"
            data-testid="batch-run"
            onClick={() => {
              onClose();
              onRun(kind);
            }}
          >
            确认批量生成
          </button>
        </div>
      </div>
    </div>
  );
}
