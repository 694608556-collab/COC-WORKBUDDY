import { useEffect, useState } from "react";
import type { Edition, Module } from "../../lib/types";

type Props = {
  open: boolean;
  modules: Module[];
  onCancel: () => void;
  onConfirm: (moduleId: string | null, edition: Edition) => void;
};

export function NewCardDialog({ open, modules, onCancel, onConfirm }: Props) {
  const [moduleId, setModuleId] = useState<string | null>(null);
  const [edition, setEdition] = useState<Edition>(7);

  useEffect(() => {
    if (open) {
      setModuleId(modules[0]?.id ?? null);
      setEdition(7);
    }
  }, [open, modules]);

  if (!open) return null;

  return (
    <div className="mask" data-testid="new-card-dialog">
      <div className="dlg" style={{ width: 400 }}>
        <div className="dh">新建角色卡</div>
        <div className="db">
          <div className="field">
            <label className="lb">所属模组（可选）</label>
            <select className="inp" data-testid="new-card-module" value={moduleId ?? ""} onChange={(e) => setModuleId(e.target.value || null)}>
              <option value="">不关联模组</option>
              {modules.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name}
                </option>
              ))}
            </select>
          </div>
          <div className="field">
            <label className="lb">规则版本</label>
            <div className="seg" data-testid="new-card-edition">
              <span className={edition === 7 ? "on" : ""} data-testid="new-card-7" onClick={() => setEdition(7)}>
                第七版
              </span>
              <span className={edition === 6 ? "on" : ""} data-testid="new-card-6" onClick={() => setEdition(6)}>
                第六版
              </span>
            </div>
          </div>
        </div>
        <div className="dfoot">
          <button className="btn" data-testid="new-card-cancel" onClick={onCancel}>
            取消
          </button>
          <button className="btn primary" data-testid="new-card-confirm" onClick={() => onConfirm(moduleId, edition)}>
            下一步
          </button>
        </div>
      </div>
    </div>
  );
}
