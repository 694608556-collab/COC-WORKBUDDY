import { useEffect, useState } from "react";
import type { Character, Edition, Module } from "../../lib/types";
import {
  ATTR_KEYS,
  BG_FIELDS,
  derive,
  emptyCharacter,
  rollLuck,
  WEAPON_KEYS,
} from "../../lib/character";

type Props = {
  open: boolean;
  mode: "new" | "edit";
  modules: Module[];
  initial?: Character;
  onCancel: () => void;
  onSave: (card: Character) => void;
  onDelete?: () => void;
};

const WEAPON_LABELS: Record<string, string> = {
  name: "名称",
  hit: "命中",
  damage: "伤害",
  range: "射程",
  times: "次数",
  ammo: "装弹",
  durability: "耐久",
};

const ATTR_LABELS: Record<string, string> = {
  STR: "力量",
  CON: "体质",
  SIZ: "体型",
  DEX: "敏捷",
  APP: "外貌",
  INT: "智力",
  POW: "意志",
  EDU: "教育",
};

export function CharacterEditor({ open, mode, modules, initial, onCancel, onSave, onDelete }: Props) {
  // 首帧直接用传入的卡渲染，避免先显示一张空卡再被填充
  const [card, setCard] = useState<Character>(() =>
    initial ? structuredClone(initial) : emptyCharacter(null, 7),
  );

  useEffect(() => {
    if (!open) return;
    setCard(initial ? structuredClone(initial) : emptyCharacter(null, 7));
  }, [open, initial]);

  if (!open) return null;

  const derived = derive(card.edition, card.attrs, card.luck);

  const setAttr = (k: keyof Character["attrs"], v: string) =>
    setCard({ ...card, attrs: { ...card.attrs, [k]: Number(v) || 0 } });
  const setBasic = (k: keyof Character["basic"], v: string) =>
    setCard({ ...card, basic: { ...card.basic, [k]: v } });
  const setBg = (k: keyof Character["background"], v: string) =>
    setCard({ ...card, background: { ...card.background, [k]: v } });

  const switchEdition = () =>
    setCard({ ...card, edition: (card.edition === 7 ? 6 : 7) as Edition });

  const submit = () =>
    onSave({
      ...card,
      basic: {
        ...card.basic,
        name: card.basic.name.trim() || "未命名调查员",
        job: card.basic.job.trim(),
      },
    });

  return (
    <div className="mask" data-testid="char-editor">
      <div className="dlg" style={{ width: 720, maxWidth: "calc(100vw - 40px)" }}>
        <div className="dh">
          调查员角色卡
          <button
            className="seg"
            style={{ marginLeft: "auto" }}
            data-testid="edition-switch"
            onClick={switchEdition}
          >
            <span className={card.edition === 7 ? "on" : ""}>第七版</span>
            <span className={card.edition === 6 ? "on" : ""}>第六版</span>
          </button>
        </div>
        <div className="db" style={{ maxHeight: "70vh", overflow: "auto" }}>
          {/* 基本信息 */}
          <Section title="基本信息">
            <div className="g2">
              <div className="f">
                <label>模组</label>
                <select
                  className="inp"
                  data-testid="char-module"
                  value={card.moduleId ?? ""}
                  onChange={(e) => setCard({ ...card, moduleId: e.target.value || null })}
                >
                  <option value="">未关联模组</option>
                  {modules.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name}
                    </option>
                  ))}
                </select>
              </div>
              <div className="f">
                <label>角色名</label>
                <input className="inp" data-testid="char-basic-name" value={card.basic.name} onChange={(e) => setBasic("name", e.target.value)} />
              </div>
              <div className="f">
                <label>职业</label>
                <input className="inp" data-testid="char-basic-job" value={card.basic.job} onChange={(e) => setBasic("job", e.target.value)} />
              </div>
              <div className="f">
                <label>年龄</label>
                <input className="inp" data-testid="char-basic-age" value={card.basic.age} onChange={(e) => setBasic("age", e.target.value)} />
              </div>
              <div className="f">
                <label>性别</label>
                <input className="inp" data-testid="char-basic-gender" value={card.basic.gender} onChange={(e) => setBasic("gender", e.target.value)} />
              </div>
              <div className="f">
                <label>出生地</label>
                <input className="inp" data-testid="char-basic-birth" value={card.basic.birthplace} onChange={(e) => setBasic("birthplace", e.target.value)} />
              </div>
              <div className="f">
                <label>居住地</label>
                <input className="inp" data-testid="char-basic-res" value={card.basic.residence} onChange={(e) => setBasic("residence", e.target.value)} />
              </div>
            </div>
          </Section>

          {/* 属性 */}
          <Section title="属性">
            <div className="g8">
              {ATTR_KEYS.map((k) => (
                <div className={`f${k === "INT" || k === "EDU" ? " hl" : ""}`} key={k}>
                  <label>{ATTR_LABELS[k]}</label>
                  <div className="v">
                    <input
                      type="number"
                      className="num"
                      data-testid={`attr-${k}`}
                      value={card.attrs[k]}
                      onChange={(e) => setAttr(k, e.target.value)}
                    />
                  </div>
                </div>
              ))}
            </div>
            <div className="derived" data-testid="derived">
              <span>
                生命 <b data-testid="derived-hp">{derived.hp}</b>
              </span>
              <span>
                魔法 <b data-testid="derived-mp">{derived.mp}</b>
              </span>
              <span>
                理智 <b data-testid="derived-san">{derived.san}</b>
              </span>
              <span>
                幸运{" "}
                {card.edition === 7 ? (
                  <>
                    <input
                      type="number"
                      className="num"
                      data-testid="luck-input"
                      value={card.luck ?? derived.luck}
                      onChange={(e) =>
                        setCard({ ...card, luck: Number(e.target.value) || 0 })
                      }
                    />
                    <button
                      className="lnk"
                      data-testid="luck-roll"
                      title="掷 3D6 × 5"
                      onClick={() => setCard({ ...card, luck: rollLuck() })}
                    >
                      掷 3D6
                    </button>
                  </>
                ) : (
                  <b data-testid="derived-luck">{derived.luck}</b>
                )}
              </span>
              <span>
                伤害加值 <b data-testid="derived-db">{derived.db}</b>
              </span>
            </div>
          </Section>

          {/* 派生与技能上限 */}
          <Section title="技能点数上限">
            <div className="g2">
              <div className="f">
                <label>职业技能（EDU × 4）</label>
                <div className="v" data-testid="occ-cap">{derived.occCap}</div>
              </div>
              <div className="f">
                <label>个人兴趣（INT × 2）</label>
                <div className="v" data-testid="int-cap">{derived.intCap}</div>
              </div>
            </div>
          </Section>

          {/* 武器战斗表 */}
          <Section title="武器战斗表">
            {card.weapons.map((w, i) => (
              <div className="g8 weapon-row" key={i} data-testid={`weapon-${i}`}>
                {WEAPON_KEYS.map((k) => (
                  <div className="f" key={k}>
                    <label>{WEAPON_LABELS[k]}</label>
                    <input
                      className="inp"
                      data-testid={`wp-${k}-${i}`}
                      value={(w as any)[k]}
                      onChange={(e) =>
                        setCard({
                          ...card,
                          weapons: card.weapons.map((x, j) =>
                            j === i ? { ...x, [k]: e.target.value } : x,
                          ),
                        })
                      }
                    />
                  </div>
                ))}
                <button className="lnk" data-testid={`weapon-del-${i}`} onClick={() => setCard({ ...card, weapons: card.weapons.filter((_, j) => j !== i) })}>
                  删除
                </button>
              </div>
            ))}
            <button className="add" data-testid="weapon-add" onClick={() => setCard({ ...card, weapons: [...card.weapons, { name: "", hit: "", damage: "", range: "", times: "", ammo: "", durability: "" }] })}>
              + 添加武器
            </button>
          </Section>

          {/* 财产与装备（左） + 背景详情（右）：左右分列两栏 */}
          <div className="csec-row">
            <Section title="财产与装备">
              <div className="items" data-testid="items">
                {card.items.map((it, i) => (
                  <div className="item-row" key={i} data-testid={`item-${i}`}>
                    <input
                      className="inp"
                      data-testid={`item-input-${i}`}
                      value={it}
                      placeholder="一个物品一行"
                      onChange={(e) =>
                        setCard({ ...card, items: card.items.map((x, j) => (j === i ? e.target.value : x)) })
                      }
                    />
                    <button className="lnk" data-testid={`item-del-${i}`} onClick={() => setCard({ ...card, items: card.items.filter((_, j) => j !== i) })}>
                      删除
                    </button>
                  </div>
                ))}
                {card.items.length === 0 ? <div className="hint">还没有财产与装备</div> : null}
              </div>
              <button className="add" data-testid="item-add" onClick={() => setCard({ ...card, items: [...card.items, ""] })}>
                + 添加物品
              </button>
            </Section>

            <Section title="背景详情">
              <div className="gbg">
                {BG_FIELDS.map((f) => (
                  <div className="f" key={f.key}>
                    <label>{f.label}</label>
                    <input className="inp" data-testid={`bg-${f.key}`} value={(card.background as any)[f.key]} onChange={(e) => setBg(f.key, e.target.value)} />
                  </div>
                ))}
              </div>
            </Section>
          </div>

          {/* 背景故事 */}
          <Section title="背景故事">
            <textarea className="ta" data-testid="story" rows={5} style={{ width: "100%" }} value={card.story} onChange={(e) => setCard({ ...card, story: e.target.value })} />
          </Section>
        </div>

        <div className="dfoot">
          {mode === "edit" && onDelete ? (
            <button className="danger-link" data-testid="char-delete" onClick={onDelete}>
              删除角色卡
            </button>
          ) : null}
          <button className="btn" data-testid="char-cancel" style={{ marginLeft: mode === "edit" ? 0 : "auto" }} onClick={onCancel}>
            取消
          </button>
          <button className="btn primary" data-testid="char-save" onClick={submit}>
            保存
          </button>
        </div>
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="csec">
      <div className="csec-h">{title}</div>
      <div className="csec-b">{children}</div>
    </div>
  );
}
