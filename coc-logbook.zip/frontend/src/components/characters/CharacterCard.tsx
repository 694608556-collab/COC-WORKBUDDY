import type { Character, Module } from "../../lib/types";

type Props = {
  character: Character;
  module?: Module;
  active: boolean;
  onSelect: () => void;
  onDelete: () => void;
};

export function CharacterCard({ character, module, active, onSelect, onDelete }: Props) {
  const editionText = character.edition === 7 ? "第七版" : "第六版";
  return (
    <div
      className={`pcard${active ? " on" : ""}`}
      data-testid={`char-${character.id}`}
      onClick={onSelect}
    >
      <div className="pmod" data-testid={`char-mod-${character.id}`}>
        {module?.name ?? "未关联模组"}
      </div>
      <div className="pname" data-testid={`char-name-${character.id}`}>
        {character.basic.name || "未命名调查员"}
      </div>
      <div className="pmeta" data-testid={`char-meta-${character.id}`}>
        {character.basic.job || "无职业"} · {editionText}
      </div>
      <button
        className="lnk"
        data-testid={`char-del-${character.id}`}
        onClick={(e) => {
          e.stopPropagation();
          onDelete();
        }}
        style={{ position: "absolute", right: 8, top: 6 }}
      >
        删除
      </button>
    </div>
  );
}
