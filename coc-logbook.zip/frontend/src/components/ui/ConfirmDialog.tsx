import { useEffect, useState } from "react";

type Props = {
  open: boolean;
  title: string;
  text: string;
  okText?: string;
  onCancel: () => void;
  onOk: () => void;
};

export function ConfirmDialog({ open, title, text, okText = "确认删除", onCancel, onOk }: Props) {
  const [v, setV] = useState({ t: "", x: "" });
  useEffect(() => {
    if (open) setV({ t: title, x: text });
  }, [open, title, text]);
  if (!open) return null;
  return (
    <div className="mask" data-testid="confirm-dialog">
      <div className="dlg" style={{ width: 380 }}>
        <div className="dh">{v.t}</div>
        <div className="db">
          <div className="hint" data-testid="confirm-text">
            {v.x}
          </div>
        </div>
        <div className="dfoot">
          <button
            className="btn"
            data-testid="confirm-cancel"
            style={{ marginLeft: "auto" }}
            onClick={onCancel}
          >
            取消
          </button>
          <button className="btn danger" data-testid="confirm-ok" onClick={onOk}>
            {okText}
          </button>
        </div>
      </div>
    </div>
  );
}
