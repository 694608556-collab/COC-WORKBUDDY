type Props = { size?: number };

/** 通用文件夹图标：归档目录入口统一用它，避免 emoji 在部分环境显示成方框 */
export function FolderIcon({ size = 15 }: Props) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" aria-hidden="true">
      <path
        d="M1.5 4.2c0-.64.52-1.16 1.16-1.16h2.7c.36 0 .7.16.92.44l.66.86h5.9c.64 0 1.16.52 1.16 1.16v6.34c0 .64-.52 1.16-1.16 1.16H2.66c-.64 0-1.16-.52-1.16-1.16V4.2Z"
        stroke="currentColor"
        strokeWidth="1.1"
        strokeLinejoin="round"
      />
    </svg>
  );
}
