import { useToast } from "../../store/useToast";

export function ToastHost() {
  const items = useToast((s) => s.items);
  const close = useToast((s) => s.close);
  if (!items.length) return null;
  return (
    <div className="toast-wrap" data-testid="toast-host">
      {items.map((t) => (
        <div className="toast" key={t.id} data-testid="toast" onClick={() => close(t.id)}>
          <div>{t.title}</div>
          {t.desc ? <div className="sub2">{t.desc}</div> : null}
        </div>
      ))}
    </div>
  );
}
