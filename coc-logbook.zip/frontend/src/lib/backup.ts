import {
  clearAll,
  listBackupMeta,
  putBackupMeta,
  deleteBackupMeta,
  readAll,
  getSettings,
  putModule,
  putRecord,
  putCharacter,
  saveSettings,
  type BackupMeta,
} from "./db";
import { SCHEMA_VERSION, type BackupFile } from "./types";
import { writeFile, writeBackupFile, removeBackupFile } from "./archive";
import type { BackupTiming } from "./types";

export function backupFileName(d: Date = new Date()): string {
  const p = (n: number) => String(n).padStart(2, "0");
  return `coc-backup-${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(
    d.getMinutes(),
  )}.json`;
}

export async function buildBackup(): Promise<BackupFile> {
  const all = await readAll();
  return {
    schemaVersion: SCHEMA_VERSION,
    exportedAt: new Date().toISOString(),
    modules: all.modules,
    records: all.records,
    characters: all.characters,
    settings: all.settings,
  };
}

/** 估算占用空间（字符串长度，单位字节） */
export function estimateSize(): Promise<number> {
  return readAll().then((a) => {
    const json = JSON.stringify({
      modules: a.modules,
      records: a.records,
      characters: a.characters,
    });
    return new Blob([json]).size;
  });
}

export async function downloadBackup(): Promise<string> {
  const data = await buildBackup();
  const name = backupFileName();
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  await writeFile("备份", name, blob);
  return name;
}

export type RestoreResult = { ok: boolean; reason?: string };

export type ParsedBackup =
  | { ok: true; data: BackupFile }
  | { ok: false; reason: string };

/** 解析并校验备份文件：结构不对或版本过新时给出明确原因，不静默失败 */
export function parseBackupFile(text: string): ParsedBackup {
  let data: BackupFile;
  try {
    data = JSON.parse(text) as BackupFile;
  } catch {
    return { ok: false, reason: "文件不是合法的 JSON" };
  }
  if (!data || typeof data !== "object" || !Array.isArray(data.modules)) {
    return { ok: false, reason: "备份文件结构不正确" };
  }
  if (typeof data.schemaVersion !== "number" || data.schemaVersion > SCHEMA_VERSION) {
    return {
      ok: false,
      reason: `版本不兼容（文件 v${data.schemaVersion ?? "未知"}，当前 v${SCHEMA_VERSION}）`,
    };
  }
  return { ok: true, data };
}

/** 备份内容摘要：恢复前给用户看清楚要覆盖成什么 */
export function backupSummary(data: BackupFile): string {
  const time = data.exportedAt ? new Date(data.exportedAt).toLocaleString("zh-CN") : "未知时间";
  return `备份时间 ${time} · 模组 ${data.modules?.length ?? 0} · 场次 ${data.records?.length ?? 0} · 角色卡 ${data.characters?.length ?? 0}`;
}

export async function restoreBackup(text: string): Promise<RestoreResult> {
  const parsed = parseBackupFile(text);
  if (!parsed.ok) return { ok: false, reason: parsed.reason };
  const data = parsed.data;
  await clearAll();
  for (const m of data.modules) await putModule(m);
  for (const r of data.records) await putRecord(r);
  for (const c of data.characters) await putCharacter(c);
  if (data.settings) await saveSettings(data.settings);
  return { ok: true };
}

export function pruneHistory(list: BackupMeta[], keepCount: number): BackupMeta[] {
  if (keepCount <= 0) keepCount = 1;
  const sorted = [...list].sort((a, b) => a.at - b.at);
  return sorted.slice(-keepCount);
}

function dayKey(t: number): string {
  const d = new Date(t);
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

/** ISO 周：同一周返回同一个 key */
function weekKey(t: number): string {
  const d = new Date(t);
  const day = (d.getDay() + 6) % 7; // 周一 = 0
  d.setDate(d.getDate() - day + 3); // 取该周周四，保证跨年正确
  const firstThursday = new Date(d.getFullYear(), 0, 4);
  const fday = (firstThursday.getDay() + 6) % 7;
  firstThursday.setDate(firstThursday.getDate() - fday + 3);
  const week = 1 + Math.round((d.getTime() - firstThursday.getTime()) / (7 * 24 * 3600 * 1000));
  return `${d.getFullYear()}-W${week}`;
}

/** 是否该跑一次自动备份：关闭时每次都跑；每天 / 每周按自然日 / 自然周判定 */
export function shouldAutoBackup(
  timing: BackupTiming,
  lastAt: number | null,
  now: number = Date.now(),
): boolean {
  if (timing === "onClose") return true;
  if (!lastAt) return true;
  if (timing === "daily") return dayKey(lastAt) !== dayKey(now);
  return weekKey(lastAt) !== weekKey(now);
}

/** 自动备份：写一份备份 → 记录历史 → 按保留份数删掉最旧的文件 → 记下上次备份时间 */
export async function runAutoBackup(now: number = Date.now()): Promise<string | null> {
  const data = await buildBackup();
  const name = backupFileName(new Date(now));
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  await writeBackupFile(name, blob);

  const history = await listBackupMeta();
  history.push({ id: `bk-${now}`, file: name, at: now });
  const keep = Math.max(1, data.settings?.autoBackup?.keepCount ?? 10);
  const kept = pruneHistory(history, keep);
  const removed = history.filter((h) => !kept.some((k) => k.id === h.id));
  for (const r of removed) {
    await removeBackupFile(r.file);
    await deleteBackupMeta(r.id);
  }
  for (const k of kept) await putBackupMeta(k);

  const cur = await getSettings();
  await saveSettings({ autoBackup: { ...cur.autoBackup, lastAt: now } });
  return name;
}
