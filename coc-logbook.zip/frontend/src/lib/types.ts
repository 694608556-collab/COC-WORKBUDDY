/** 全部实体类型，与 PRD 4.1 数据模型一致 */

export type Theme = "light" | "dark";

/** 角色 / 玩家配对：PC1 ↔ PL1 */
export type ParticipantPair = {
  pc: string;
  pl: string;
};

export type Module = {
  id: string;
  name: string;
  /** 守密人名单 */
  kps: string[];
  /** 角色 / 玩家配对 */
  pairs: ParticipantPair[];
  collapsed: boolean;
  createdAt: number;
  order: number;
};

export type RecordStatus = "unknown" | "valid" | "dead";

/** 日志条目：由后端解析后的统一结构 */
export type LogEntry = {
  id: number;
  nickname: string;
  /** 平台账号，形如 QQ:3593972548 */
  account: string;
  /** Unix 秒 */
  time: number;
  message: string;
  isDice: boolean;
  /** dialog | dice | ooc | image | system */
  kind: "dialog" | "dice" | "ooc" | "image" | "system";
  images: string[];
};

export type LogMeta = {
  name: string;
  createdAt: string;
  updatedAt: string;
  version: number;
};

export type LogPayload = {
  meta: LogMeta;
  entries: LogEntry[];
};

export type RecordItem = {
  id: string;
  moduleId: string;
  name: string;
  link: string;
  status: RecordStatus;
  /** 跑团日期 YYYY-MM-DD */
  playDate: string | null;
  fetchedAt: number | null;
  /** 抓取到的结构化内容缓存 */
  content: LogPayload | null;
  /** 链接抓取失败时手动粘贴的记录原文 */
  manualText?: string | null;
  order: number;
};

export type Edition = 6 | 7;

export type Character = {
  id: string;
  moduleId: string | null;
  edition: Edition;
  basic: {
    name: string;
    job: string;
    age: string;
    gender: string;
    birthplace: string;
    residence: string;
  };
  attrs: {
    STR: number;
    CON: number;
    SIZ: number;
    DEX: number;
    APP: number;
    INT: number;
    POW: number;
    EDU: number;
  };
  weapons: {
    name: string;
    hit: string;
    damage: string;
    range: string;
    times: string;
    ammo: string;
    durability: string;
  }[];
  skills: { name: string; value: number; type: "job" | "interest" }[];
  items: string[];
  background: {
    description: string;
    belief: string;
    importantPerson: string;
    significantPlace: string;
    treasure: string;
    trait: string;
    secret: string;
    wound: string;
    phobia: string;
  };
  story: string;
  /** 第七版幸运（3D6 × 5）可手动填；留空按 POW × 5 计算 */
  luck?: number | null;
  createdAt: number;
};

/** 海豹日志页面自带的 8 项过滤选项 */
export type ExportOptions = {
  filterDice: boolean;
  filterImage: boolean;
  filterOoc: boolean;
  filterTime: boolean;
  hideAccount: boolean;
  hideDate: boolean;
  indentFirstLine: boolean;
  darkMode: boolean;
};

export type BackupTiming = "onClose" | "daily" | "weekly";

export type Settings = {
  theme: Theme;
  downloadDir: string;
  autoBackup: {
    enabled: boolean;
    timing: BackupTiming;
    keepCount: number;
    dir: string;
    lastAt: number | null;
  };
  exportOptions: ExportOptions;
};

/** 8 项过滤选项的默认值：平台账号隐藏、年月日不展示默认开启 */
export const DEFAULT_EXPORT_OPTIONS: ExportOptions = {
  filterDice: false,
  filterImage: false,
  filterOoc: false,
  filterTime: false,
  hideAccount: true,
  hideDate: true,
  indentFirstLine: false,
  darkMode: false,
};

export const DEFAULT_SETTINGS: Settings = {
  theme: "light",
  downloadDir: "",
  autoBackup: {
    enabled: true,
    timing: "onClose",
    keepCount: 10,
    dir: "",
    lastAt: null,
  },
  exportOptions: { ...DEFAULT_EXPORT_OPTIONS },
};

/** 备份文件结构 */
export type BackupFile = {
  schemaVersion: number;
  exportedAt: string;
  modules: Module[];
  records: RecordItem[];
  characters: Character[];
  settings: Settings;
};

export const SCHEMA_VERSION = 1;
