import * as XLSX from "xlsx";
import type { LogPayload, Module, RecordItem, RecordStatus } from "./types";
import { useData } from "../store/useData";
import { parseCsv } from "./character";

/** 导出表格的列顺序：模组名 / 场次名称 / 跑团日期 / 状态 / 链接 / 缓存正文(JSON) */
export const TABLE_HEADERS = [
  "模组名",
  "场次名称",
  "跑团日期",
  "状态",
  "链接",
  "内容(JSON)",
];

export type TableRow = Record<string, string>;

/** CSV 单元格转义：含逗号 / 引号 / 换行时整体用引号包裹，引号翻倍 */
function csvCell(v: unknown): string {
  const s = v == null ? "" : String(v);
  if (/[",\n\r]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

/** 把当前所有模组与场次导出为 CSV 文本（含已抓取的正文，便于离线再导入） */
export function buildTableCsv(modules: Module[], records: RecordItem[]): string {
  const lines = [TABLE_HEADERS.join(",")];
  for (const r of records) {
    const mod = modules.find((m) => m.id === r.moduleId);
    lines.push(
      [
        mod?.name ?? "",
        r.name,
        r.playDate ?? "",
        r.status,
        r.link,
        r.content ? JSON.stringify(r.content) : "",
      ]
        .map(csvCell)
        .join(","),
    );
  }
  return lines.join("\n");
}

/** 解析 CSV 文本为行对象（复用角色卡导入的稳健解析器） */
export function parseTableCsv(text: string): TableRow[] {
  return parseCsv(text);
}

/** 解析 xlsx / xls 文件为行对象（只取第一张表） */
export async function parseTableXlsx(file: File): Promise<TableRow[]> {
  const buf = await file.arrayBuffer();
  const data = new Uint8Array(buf);
  const wb = XLSX.read(data, { type: "array" });
  const ws = wb.Sheets[wb.SheetNames[0]];
  return XLSX.utils.sheet_to_json<TableRow>(ws, { defval: "" });
}

export type ColumnMap = {
  module: string | null;
  name: string | null;
  date: string | null;
  status: string | null;
  link: string | null;
  content: string | null;
};

function pickHeader(headers: string[], re: RegExp): string | null {
  return headers.find((h) => re.test(h)) ?? null;
}

/** 在若干列里自动找出「看起来像海豹链接」的那一列（值里含 http / weizaima / key=） */
function autoDetectLink(headers: string[], rows: TableRow[]): string | null {
  let best: string | null = null;
  let bestScore = 0;
  for (const h of headers) {
    let score = 0;
    for (const r of rows) {
      const v = (r[h] ?? "").trim();
      if (/^https?:\/\//i.test(v) || /weizaima/i.test(v) || /key=/i.test(v)) score++;
    }
    if (score > bestScore) {
      bestScore = score;
      best = h;
    }
  }
  return bestScore > 0 ? best : null;
}

/** 根据表头自动识别各列含义；链接列识别不到时用值扫描兜底 */
export function detectColumns(rows: TableRow[]): ColumnMap {
  const headers = rows.length ? Object.keys(rows[0]) : [];
  let module = pickHeader(headers, /模组|模块|团名|campaign|module/i);
  let name =
    pickHeader(headers, /场次|记录名称|场次名称/i) ??
    pickHeader(headers, /名称|name|title/i);
  const date = pickHeader(headers, /跑团日期|日期|date/i);
  const status = pickHeader(headers, /状态|status/i);
  const content = pickHeader(headers, /内容|content/i);
  let link = pickHeader(headers, /链接|link|url|网址|weizaima/i);
  if (!link) link = autoDetectLink(headers, rows);
  return { module, name, date, status, link, content };
}

function normalizeStatus(s: string): RecordStatus {
  const v = s.trim();
  if (/valid|有效/i.test(v)) return "valid";
  if (/dead|失效|无效|打不开/i.test(v)) return "dead";
  return "unknown";
}

export type ImportResult = {
  modules: number;
  records: number;
  skipped: number;
};

/**
 * 把解析出来的行写入本机数据库：
 * - 模组按名称去重（已有则复用，没有则新建）
 * - 自动识别链接列生成场次；有正文缓存则一并恢复
 */
export async function importTableRows(rows: TableRow[]): Promise<ImportResult> {
  const result: ImportResult = { modules: 0, records: 0, skipped: 0 };
  if (!rows.length) return result;

  const cols = detectColumns(rows);
  const store = useData.getState();
  const existing = new Map<string, Module>(
    store.modules.map((m) => [m.name.trim().toLowerCase(), m]),
  );

  for (const row of rows) {
    const moduleName = (cols.module ? row[cols.module] : "").trim() || "未分组";
    let mod = existing.get(moduleName.toLowerCase());
    if (!mod) {
      mod = await store.addModule({ name: moduleName, kps: [], pairs: [] });
      existing.set(moduleName.toLowerCase(), mod);
      result.modules++;
    }

    const nameVal = (cols.name ? row[cols.name] : "").trim();
    const link = (cols.link ? row[cols.link] : "").trim();
    const playDate = (cols.date ? row[cols.date] : "").trim() || null;
    const status = normalizeStatus(cols.status ? row[cols.status] : "");

    if (!nameVal && !link) {
      result.skipped++;
      continue;
    }

    const rec = await store.addRecord({
      moduleId: mod.id,
      name: nameVal || undefined,
      link,
      manualText: undefined,
      playDate,
    });
    result.records++;

    const contentRaw = cols.content ? row[cols.content] : "";
    let content: LogPayload | null = null;
    if (contentRaw) {
      try {
        content = JSON.parse(contentRaw) as LogPayload;
      } catch {
        content = null;
      }
    }

    if (content || status !== "unknown") {
      await store.updateRecord(rec.id, {
        status: content ? "valid" : status,
        playDate: rec.playDate ?? playDate,
        content: content ?? rec.content,
        fetchedAt: content ? Date.now() : rec.fetchedAt,
      });
    }
  }

  return result;
}

/** 浏览器端触发下载（CSV） */
export function downloadTableCsv(modules: Module[], records: RecordItem[]) {
  const blob = new Blob([buildTableCsv(modules, records)], {
    type: "text/csv;charset=utf-8",
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "coc-跑团记录表.csv";
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/** 浏览器端触发下载（Excel） */
export function downloadTableXlsx(modules: Module[], records: RecordItem[]) {
  const aoa: string[][] = [TABLE_HEADERS];
  for (const r of records) {
    const mod = modules.find((m) => m.id === r.moduleId);
    aoa.push([
      mod?.name ?? "",
      r.name,
      r.playDate ?? "",
      r.status,
      r.link,
      r.content ? JSON.stringify(r.content) : "",
    ]);
  }
  const ws = XLSX.utils.aoa_to_sheet(aoa);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "跑团记录");
  XLSX.writeFile(wb, "coc-跑团记录表.xlsx");
}
