import type { Character, Edition } from "./types";

export type Derived = {
  hp: number;
  mp: number;
  san: number;
  luck: number;
  /** 伤害加值 DB：以字符串显示（-1 / 0 / +1d4 …） */
  db: string;
  /** 职业技能点数上限 */
  occCap: number;
  /** 个人兴趣技能点数上限 */
  intCap: number;
};

const roundUp = (n: number) => Math.ceil(n);
const roundDown = (n: number) => Math.floor(n);

/** 伤害加值：按 STR + SIZ 查表 */
export function damageBonus(edition: Edition, attrs: Character["attrs"]): string {
  const sum = attrs.STR + attrs.SIZ;
  void edition;
  if (sum <= 64) return "-2";
  if (sum <= 84) return "-1";
  if (sum <= 124) return "0";
  if (sum <= 164) return "+1d4";
  if (sum <= 204) return "+1d6";
  return "+2d6";
}

/** 派生值：按版本公式重算（两版都不含成功线） */
export function derive(
  edition: Edition,
  attrs: Character["attrs"],
  luckOverride?: number | null,
): Derived {
  const sum = attrs.CON + attrs.SIZ;
  const hp = roundUp(sum / 10);
  const san = attrs.POW;
  // 第六版：幸运 = POW × 5；第七版：3D6 × 5，可手动填
  const luck = edition === 7 && luckOverride != null ? luckOverride : attrs.POW * 5;
  const mp = edition === 7 ? roundDown(attrs.POW / 5) : roundUp(attrs.POW / 4);
  const db = damageBonus(edition, attrs);
  const occCap = attrs.EDU * 4;
  const intCap = attrs.INT * 2;
  return { hp, mp, san, luck, db, occCap, intCap };
}

/** 第七版幸运：3D6 × 5 */
export function rollLuck(): number {
  const d6 = () => 1 + Math.floor(Math.random() * 6);
  return (d6() + d6() + d6()) * 5;
}

export const ATTR_KEYS: (keyof Character["attrs"])[] = [
  "STR",
  "CON",
  "SIZ",
  "DEX",
  "APP",
  "INT",
  "POW",
  "EDU",
];

export const SKILL_TYPES: ("job" | "interest")[] = ["job", "interest"];

export const BG_FIELDS: { key: keyof Character["background"]; label: string }[] = [
  { key: "description", label: "个人描述" },
  { key: "belief", label: "思想与信念" },
  { key: "importantPerson", label: "重要之人" },
  { key: "significantPlace", label: "意义非凡之地" },
  { key: "treasure", label: "宝贵之物" },
  { key: "trait", label: "特质" },
  { key: "secret", label: "难言之隐" },
  { key: "wound", label: "伤口和疤痕" },
  { key: "phobia", label: "恐惧症 / 狂躁症" },
];

export const WEAPON_KEYS: (keyof Character["weapons"][number])[] = [
  "name",
  "hit",
  "damage",
  "range",
  "times",
  "ammo",
  "durability",
];

export function emptyCharacter(moduleId: string | null, edition: Edition): Character {
  return {
    id: "",
    moduleId,
    edition,
    basic: { name: "", job: "", age: "", gender: "", birthplace: "", residence: "" },
    attrs: { STR: 0, CON: 0, SIZ: 0, DEX: 0, APP: 0, INT: 0, POW: 0, EDU: 0 },
    weapons: [],
    skills: [],
    items: [],
    background: {
      description: "",
      belief: "",
      importantPerson: "",
      significantPlace: "",
      treasure: "",
      trait: "",
      secret: "",
      wound: "",
      phobia: "",
    },
    story: "",
    createdAt: Date.now(),
  };
}

/** 标准空白模板的表头与示例行（CSV / XLSX 共用） */
export const TEMPLATE_HEADERS = [
  "角色名",
  "职业",
  "年龄",
  "性别",
  "出生地",
  "居住地",
  "STR",
  "CON",
  "SIZ",
  "DEX",
  "APP",
  "INT",
  "POW",
  "EDU",
  "财产与装备（每行一个）",
  "背景故事",
];

export function buildTemplateCsv(): string {
  const sample = [
    "艾伦·韦斯特",
    "记者",
    "29",
    "男",
    "伦敦",
    "上海",
    "60",
    "70",
    "65",
    "65",
    "70",
    "75",
    "65",
    "80",
    "笔记本与钢笔",
    "一名奔波于真相与谎言之间的记者。",
  ];
  return [TEMPLATE_HEADERS.join(","), sample.join(",")].join("\n");
}

/** 把一行（对象）映射到角色卡，缺字段补默认 */
export function rowToCharacter(
  row: Record<string, string>,
  moduleId: string | null,
  edition: Edition,
): Character {
  const num = (k: string) => {
    const v = Number(row[k]);
    return Number.isFinite(v) ? v : 0;
  };
  const c = emptyCharacter(moduleId, edition);
  c.basic = {
    name: (row["角色名"] ?? "").trim(),
    job: (row["职业"] ?? "").trim(),
    age: (row["年龄"] ?? "").trim(),
    gender: (row["性别"] ?? "").trim(),
    birthplace: (row["出生地"] ?? "").trim(),
    residence: (row["居住地"] ?? "").trim(),
  };
  c.attrs = {
    STR: num("STR"),
    CON: num("CON"),
    SIZ: num("SIZ"),
    DEX: num("DEX"),
    APP: num("APP"),
    INT: num("INT"),
    POW: num("POW"),
    EDU: num("EDU"),
  };
  const itemsRaw = row["财产与装备（每行一个）"] ?? "";
  c.items = itemsRaw
    .split("\n")
    .map((s) => s.trim())
    .filter(Boolean);
  c.story = (row["背景故事"] ?? "").trim();
  return c;
}

/** 简易 CSV 解析（支持中文表头，引号可选） */
export function parseCsv(text: string): Record<string, string>[] {
  const lines = text.replace(/\r\n?/g, "\n").split("\n").filter((l) => l.trim() !== "");
  if (lines.length < 2) return [];
  const headers = splitCsvLine(lines[0]);
  return lines.slice(1).map((line) => {
    const cells = splitCsvLine(line);
    const obj: Record<string, string> = {};
    headers.forEach((h, i) => (obj[h.trim()] = cells[i] ?? ""));
    return obj;
  });
}

function splitCsvLine(line: string): string[] {
  const out: string[] = [];
  let cur = "";
  let q = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (q && line[i + 1] === '"') {
        cur += '"';
        i++;
      } else q = !q;
    } else if (ch === "," && !q) {
      out.push(cur);
      cur = "";
    } else cur += ch;
  }
  out.push(cur);
  return out;
}
