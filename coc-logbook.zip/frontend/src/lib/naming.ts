const CN = ["零", "一", "二", "三", "四", "五", "六", "七", "八", "九"];

/** 1 → 一，10 → 十，11 → 十一，25 → 二十五 */
export function cnNumber(n: number): string {
  if (n <= 0) return "零";
  if (n < 10) return CN[n];
  if (n === 10) return "十";
  if (n < 20) return `十${CN[n - 10]}`;
  if (n < 100) {
    const tens = Math.floor(n / 10);
    const ones = n % 10;
    return `${CN[tens]}十${ones ? CN[ones] : ""}`;
  }
  return String(n);
}

/** 场次默认名：模组名第X场，例：暗影循迹第一场 */
export function defaultRecordName(moduleName: string, index: number): string {
  return `${moduleName}第${cnNumber(index)}场`;
}

/** 下载文件名：{跑团日期年月日}{模组名}{场次名}.{扩展名} */
export function buildFileName(
  playDate: string | null,
  moduleName: string,
  recordName: string,
  ext: string,
): string {
  const date = playDate ? playDate.replace(/-/g, "") : "";
  const safe = (s: string) => s.replace(/[\\/:*?"<>|]/g, "_").trim();
  return `${date}${safe(moduleName)}${safe(recordName)}.${ext}`;
}

/** 从海豹链接中取出 key 与 password（# 后面那段） */
export function parseSealLink(link: string): { key: string; password: string } | null {
  try {
    const u = new URL(link);
    const key = u.searchParams.get("key") || "";
    const password = u.hash.replace(/^#/, "");
    if (!key) return null;
    return { key, password };
  } catch {
    return null;
  }
}
