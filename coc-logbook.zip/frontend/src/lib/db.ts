import { openDB, type DBSchema, type IDBPDatabase } from "idb";
import {
  DEFAULT_SETTINGS,
  type Character,
  type Module,
  type RecordItem,
  type Settings,
} from "./types";

interface CocDB extends DBSchema {
  modules: {
    key: string;
    value: Module;
    indexes: { "by-order": number };
  };
  records: {
    key: string;
    value: RecordItem;
    indexes: { "by-module": string };
  };
  characters: { key: string; value: Character };
  settings: { key: "app"; value: Settings };
  backups: { key: string; value: BackupMeta };
  /** 目录句柄（File System Access），授权一次后长期复用 */
  handles: { key: string; value: unknown };
}

const DB_NAME = "coc-trpg-logbook";
const DB_VERSION = 2;

let dbPromise: Promise<IDBPDatabase<CocDB>> | null = null;

export function getDB(): Promise<IDBPDatabase<CocDB>> {
  if (!dbPromise) {
    dbPromise = openDB<CocDB>(DB_NAME, DB_VERSION, {
      upgrade(db) {
        if (!db.objectStoreNames.contains("modules")) {
          const s = db.createObjectStore("modules", { keyPath: "id" });
          s.createIndex("by-order", "order");
        }
        if (!db.objectStoreNames.contains("records")) {
          const s = db.createObjectStore("records", { keyPath: "id" });
          s.createIndex("by-module", "moduleId");
        }
  if (!db.objectStoreNames.contains("characters")) {
      db.createObjectStore("characters", { keyPath: "id" });
    }
    if (!db.objectStoreNames.contains("backups")) {
      db.createObjectStore("backups", { keyPath: "id" });
    }
    if (!db.objectStoreNames.contains("settings")) {
      db.createObjectStore("settings");
    }
        if (!db.objectStoreNames.contains("handles")) {
          db.createObjectStore("handles");
        }
      },
    });
  }
  return dbPromise;
}

/** 测试用：重置数据库连接（仅测试环境调用） */
export function __resetDBForTest() {
  dbPromise = null;
}

export const uid = () =>
  `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;

/* ------------------------------ 设置 ------------------------------ */

export async function getSettings(): Promise<Settings> {
  const db = await getDB();
  const s = await db.get("settings", "app");
  if (!s) return { ...DEFAULT_SETTINGS };
  return {
    ...DEFAULT_SETTINGS,
    ...s,
    autoBackup: { ...DEFAULT_SETTINGS.autoBackup, ...(s.autoBackup ?? {}) },
    exportOptions: {
      ...DEFAULT_SETTINGS.exportOptions,
      ...(s.exportOptions ?? {}),
    },
  };
}

export async function saveSettings(patch: Partial<Settings>): Promise<Settings> {
  const db = await getDB();
  const cur = await getSettings();
  const next: Settings = { ...cur, ...patch };
  await db.put("settings", next, "app");
  return next;
}

/* ------------------------------ 模组 ------------------------------ */

export async function listModules(): Promise<Module[]> {
  const db = await getDB();
  const all = await db.getAll("modules");
  return all.sort((a, b) => a.order - b.order);
}

export async function putModule(m: Module): Promise<void> {
  const db = await getDB();
  await db.put("modules", m);
}

export async function deleteModule(id: string): Promise<void> {
  const db = await getDB();
  await db.delete("modules", id);
  const recs = await db.getAllFromIndex("records", "by-module", id);
  const tx = db.transaction("records", "readwrite");
  for (const r of recs) await tx.store.delete(r.id);
  await tx.done;
}

/** 删除模组时保留角色卡，只把它们的所属模组清空（PRD 4.3） */
export async function detachCharactersFromModule(moduleId: string): Promise<void> {
  const db = await getDB();
  const all = await db.getAll("characters");
  const hit = all.filter((c) => c.moduleId === moduleId);
  if (!hit.length) return;
  const tx = db.transaction("characters", "readwrite");
  for (const c of hit) await tx.store.put({ ...c, moduleId: null });
  await tx.done;
}

/* ------------------------------ 场次 ------------------------------ */

export async function listRecords(moduleId?: string): Promise<RecordItem[]> {
  const db = await getDB();
  const all = moduleId
    ? await db.getAllFromIndex("records", "by-module", moduleId)
    : await db.getAll("records");
  return all.sort((a, b) => a.order - b.order);
}

export async function putRecord(r: RecordItem): Promise<void> {
  const db = await getDB();
  await db.put("records", r);
}

export async function deleteRecord(id: string): Promise<void> {
  const db = await getDB();
  await db.delete("records", id);
}

/* ------------------------------ 角色卡 ------------------------------ */

export async function listCharacters(): Promise<Character[]> {
  const db = await getDB();
  return (await db.getAll("characters")).sort((a, b) => a.createdAt - b.createdAt);
}

export async function putCharacter(c: Character): Promise<void> {
  const db = await getDB();
  await db.put("characters", c);
}

export async function deleteCharacter(id: string): Promise<void> {
  const db = await getDB();
  await db.delete("characters", id);
}

/* ------------------------------ 备份记录 ------------------------------ */

export type BackupMeta = {
  id: string;
  file: string;
  at: number;
};

export async function putBackupMeta(m: BackupMeta): Promise<void> {
  const db = await getDB();
  await db.put("backups", m);
}

export async function listBackupMeta(): Promise<BackupMeta[]> {
  const db = await getDB();
  return (await db.getAll("backups")).sort((a, b) => a.at - b.at);
}

export async function deleteBackupMeta(id: string): Promise<void> {
  const db = await getDB();
  await db.delete("backups", id);
}

/* ------------------------------ 目录句柄 ------------------------------ */

export async function getHandle(key: string): Promise<unknown | null> {
  const db = await getDB();
  return (await db.get("handles", key)) ?? null;
}

export async function putHandle(key: string, handle: unknown): Promise<void> {
  const db = await getDB();
  await db.put("handles", handle, key);
}

export async function deleteHandle(key: string): Promise<void> {
  const db = await getDB();
  await db.delete("handles", key);
}

/* ------------------------------ 全量 ------------------------------ */

export async function readAll() {
  return {
    modules: await listModules(),
    records: await listRecords(),
    characters: await listCharacters(),
    settings: await getSettings(),
  };
}

export async function clearAll(): Promise<void> {
  const db = await getDB();
  const tx = db.transaction(["modules", "records", "characters", "settings"], "readwrite");
  await Promise.all([
    tx.objectStore("modules").clear(),
    tx.objectStore("records").clear(),
    tx.objectStore("characters").clear(),
    tx.objectStore("settings").clear(),
  ]);
  await tx.done;
}
