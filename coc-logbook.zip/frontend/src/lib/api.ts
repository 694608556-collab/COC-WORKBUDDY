import type { LogPayload } from "./types";

export type SealStatus = "valid" | "dead" | "offline";

export type CheckResult = {
  status: SealStatus;
  playDate: string | null;
  count: number;
  message: string | null;
};

export type FetchResult = {
  status: SealStatus;
  playDate: string | null;
  count: number;
  message: string | null;
  payload: LogPayload | null;
};

export class ApiError extends Error {
  constructor(
    public kind: "offline" | "error",
    message: string,
  ) {
    super(message);
    this.name = "ApiError";
  }
}

export const OFFLINE_MSG = "本机服务未启动或网络不可用；已保存的数据不受影响";

async function postJSON<T>(path: string, body: unknown): Promise<T> {
  let res: Response;
  try {
    res = await fetch(path, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
  } catch {
    throw new ApiError("offline", OFFLINE_MSG);
  }
  if (!res.ok) {
    let message = `请求失败（HTTP ${res.status}）`;
    try {
      const j = (await res.json()) as { message?: string };
      if (j?.message) message = j.message;
    } catch {
      /* 忽略 */
    }
    throw new ApiError("error", message);
  }
  return (await res.json()) as T;
}

/** 检测链接：只取状态与跑团日期 */
export function sealCheck(link: string): Promise<CheckResult> {
  return postJSON<CheckResult>("/api/seal/check", { link });
}

/** 抓取正文：下载与转换前调用 */
export function sealFetch(link: string): Promise<FetchResult> {
  return postJSON<FetchResult>("/api/seal/fetch", { link });
}

/** 手动粘贴的记录文本：解析出日期与正文 */
export function parseText(text: string): Promise<FetchResult> {
  return postJSON<FetchResult>("/api/seal/parse-text", { text });
}

export type ExportType = "raw" | "txt" | "docx" | "pdf";

export type ExportResult = {
  status: "ok" | "error";
  data: string;
  mime: string;
  ext: string;
  message?: string;
};

/** 把结构化正文渲染成 raw / txt / docx / pdf（base64 返回） */
export function sealExport(
  entries: unknown[],
  type: ExportType,
  options: unknown,
  embedImages = false,
): Promise<ExportResult> {
  return postJSON<ExportResult>("/api/seal/export", { type, entries, options, embedImages });
}
