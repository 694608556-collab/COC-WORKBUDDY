import type { ExportOptions, LogEntry, LogPayload, RecordItem } from "./types";
import { buildFileName } from "./naming";
import { sealExport } from "./api";
import { writeFile } from "./archive";

/** 海豹页面自带的四种下载方式 + 本机转换的 TXT / PDF，共六项 */
export type DownloadKind = "raw" | "imagedoc" | "dialog" | "docx" | "txt" | "pdf";

export const DOWNLOAD_LABELS: Record<DownloadKind, string> = {
  raw: "下载原始文件",
  imagedoc: "下载带图doc",
  dialog: "下载对话doc",
  docx: "下载docx",
  txt: "TXT",
  pdf: "PDF",
};

/** 把下载方式换算成具体的过滤选项 */
export function optionsForKind(kind: DownloadKind, preset: ExportOptions): ExportOptions {
  switch (kind) {
    case "raw":
      // 原始文件：完全不过滤
      return {
        filterDice: false,
        filterImage: false,
        filterOoc: false,
        filterTime: false,
        hideAccount: false,
        hideDate: false,
        indentFirstLine: false,
        darkMode: false,
      };
    case "imagedoc":
      // 带图 doc：保留图片标记，过滤掉骰子与场外，其余跟随预设
      return { ...preset, filterDice: true, filterOoc: true, filterImage: false };
    case "dialog":
      // 对话 doc：只留对话，去掉骰子 / 图片 / 场外
      return { ...preset, filterDice: true, filterImage: true, filterOoc: true };
    case "docx":
    case "txt":
    case "pdf":
    default:
      // 按当前选项预设
      return { ...preset };
  }
}

function kindToType(kind: DownloadKind): "raw" | "txt" | "docx" | "pdf" {
  if (kind === "raw") return "raw";
  if (kind === "txt") return "txt";
  if (kind === "pdf") return "pdf";
  return "docx";
}

/** 抓正文 → 渲染 → 写到归档目录，返回最终文件名 */
export async function downloadOne(
  record: RecordItem,
  moduleName: string,
  kind: DownloadKind,
  preset: ExportOptions,
  ensureContent: (id: string) => Promise<LogPayload | null>,
): Promise<string> {
  const payload = await ensureContent(record.id);
  if (!payload || !payload.entries.length) {
    throw new Error("没有可导出的正文，请先检测 / 抓取这条记录");
  }
  const options = optionsForKind(kind, preset);
  const type = kindToType(kind);
  const res = await sealExport(payload.entries as LogEntry[], type, options, kind === "imagedoc");
  const fileName = buildFileName(record.playDate, moduleName, record.name, res.ext);
  const blob = base64ToBlob(res.data, res.mime);
  await writeFile(moduleName, fileName, blob);
  return fileName;
}

export function base64ToBlob(b64: string, mime: string): Blob {
  const bin = atob(b64);
  const len = bin.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) bytes[i] = bin.charCodeAt(i);
  return new Blob([bytes], { type: mime });
}
