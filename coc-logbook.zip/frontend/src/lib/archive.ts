/** 本地归档：用 File System Access API 把文件写进「归档目录 / 模组名」子目录。
 *  首次使用时授权一次目录句柄并记在本机，之后所有下载、备份静默写入；
 *  浏览器不支持或用户拒绝授权时，回退到普通下载，不抛错。 */

import { deleteHandle, getHandle, putHandle } from "./db";

export type ArchiveWriter = (
  moduleName: string,
  fileName: string,
  blob: Blob,
) => Promise<void>;

/** 写入结果：dir = 写进了归档目录；download = 走了浏览器下载兜底 */
export type WriteResult = "dir" | "download";

type Writable = {
  write(data: Blob): Promise<void>;
  close(): Promise<void>;
};

/** 目录句柄的最小接口（与浏览器 FileSystemDirectoryHandle 兼容） */
export type DirHandleLike = {
  name?: string;
  getDirectoryHandle(name: string, opts?: { create?: boolean }): Promise<DirHandleLike>;
  getFileHandle(
    name: string,
    opts?: { create?: boolean },
  ): Promise<{ createWritable(): Promise<Writable> }>;
  removeEntry?(name: string, opts?: { recursive?: boolean }): Promise<void>;
  queryPermission?(desc?: { mode?: string }): Promise<PermissionState>;
  requestPermission?(desc?: { mode?: string }): Promise<PermissionState>;
};

type ShowDirectoryPicker = (opts?: {
  id?: string;
  mode?: string;
  startIn?: unknown;
}) => Promise<DirHandleLike>;

export const ARCHIVE_KEY = "archive-root";
export const BACKUP_KEY = "backup-root";
export type HandleKey = typeof ARCHIVE_KEY | typeof BACKUP_KEY;

let injected: ArchiveWriter | null = null;
let fallback: ((blob: Blob, fileName: string) => void) | null = null;
/** 内存缓存，避免每次写入都读一次 IndexedDB */
const memory = new Map<string, DirHandleLike>();

/** 测试用：注入一个内存 writer，便于断言写出的文件名与内容 */
export function __setArchiveWriter(w: ArchiveWriter | null) {
  injected = w;
}

/** 测试用：注入兜底下载，便于断言不支持时的降级行为 */
export function __setFallback(fn: ((blob: Blob, fileName: string) => void) | null) {
  fallback = fn;
}

/** 测试用：清掉内存里的句柄缓存 */
export function __resetArchiveHandles() {
  memory.clear();
}

export function hasArchiveDir(): boolean {
  return typeof (globalThis as { showDirectoryPicker?: unknown }).showDirectoryPicker ===
    "function";
}

function picker(): ShowDirectoryPicker | null {
  const fn = (globalThis as { showDirectoryPicker?: ShowDirectoryPicker }).showDirectoryPicker;
  return typeof fn === "function" ? fn : null;
}

/* ------------------------------ 句柄读写 ------------------------------ */

async function readHandle(key: HandleKey): Promise<DirHandleLike | null> {
  const cached = memory.get(key);
  if (cached) return cached;
  const h = (await getHandle(key)) as DirHandleLike | null;
  if (h) memory.set(key, h);
  return h ?? null;
}

async function storeHandle(key: HandleKey, h: DirHandleLike): Promise<void> {
  memory.set(key, h);
  try {
    await putHandle(key, h);
  } catch {
    // 少数环境下句柄不能被结构化克隆入库：至少本次会话内可复用，不阻断写入
  }
}

export async function forgetHandle(key: HandleKey): Promise<void> {
  memory.delete(key);
  await deleteHandle(key);
}

async function ensurePermission(
  h: DirHandleLike,
  mode: "read" | "readwrite",
): Promise<boolean> {
  // 句柄没实现权限接口（旧浏览器 / 测试替身）时视为可用
  if (!h.queryPermission || !h.requestPermission) return true;
  if ((await h.queryPermission({ mode })) === "granted") return true;
  return (await h.requestPermission({ mode })) === "granted";
}

/** 弹出一次文件夹选择，授权后记住；返回句柄，用户取消或不支持时返回 null */
export async function pickDir(
  key: HandleKey = ARCHIVE_KEY,
  startIn?: unknown,
): Promise<DirHandleLike | null> {
  const fn = picker();
  if (!fn) return null;
  try {
    const h = await fn({
      id: key === BACKUP_KEY ? "coc-backup-dir" : "coc-archive-dir",
      mode: "readwrite",
      startIn,
    });
    if (h) await storeHandle(key, h);
    return h ?? null;
  } catch {
    // 用户取消选择
    return null;
  }
}

/** 取可用的归档根：已授权就直接返回，未授权则弹一次选择器 */
export async function getArchiveRoot(): Promise<DirHandleLike | null> {
  const stored = await readHandle(ARCHIVE_KEY);
  if (stored && (await ensurePermission(stored, "readwrite"))) return stored;
  const picked = await pickDir(ARCHIVE_KEY, stored ?? undefined);
  if (picked && (await ensurePermission(picked, "readwrite"))) return picked;
  return null;
}

/** 已授权目录的文件夹名，用于设置页展示；未设置时为空 */
export async function handleName(key: HandleKey): Promise<string> {
  const h = await readHandle(key);
  return h?.name ?? "";
}

export async function archiveDirName(): Promise<string> {
  return handleName(ARCHIVE_KEY);
}

export async function hasAuthorizedDir(): Promise<boolean> {
  return (await readHandle(ARCHIVE_KEY)) !== null;
}

/* ------------------------------ 写文件 ------------------------------ */

function doFallback(blob: Blob, fileName: string) {
  if (fallback) {
    fallback(blob, fileName);
    return;
  }
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function writeInto(
  root: DirHandleLike,
  sub: string,
  fileName: string,
  blob: Blob,
): Promise<void> {
  const dir = sub ? await root.getDirectoryHandle(sub, { create: true }) : root;
  const file = await dir.getFileHandle(fileName, { create: true });
  const w = await file.createWritable();
  await w.write(blob);
  await w.close();
}

/** 按模组名建子目录写入文件；没授权就先授权一次，实在不行走浏览器下载 */
export async function writeFile(
  moduleName: string,
  fileName: string,
  blob: Blob,
): Promise<WriteResult> {
  if (injected) {
    await injected(moduleName, fileName, blob);
    return "dir";
  }
  const root = await getArchiveRoot();
  if (!root) {
    doFallback(blob, fileName);
    return "download";
  }
  await writeInto(root, moduleName || "未分类", fileName, blob);
  return "dir";
}

/** 备份文件写入：优先用户指定的备份目录，否则写到「归档目录 / 自动备份」 */
export async function writeBackupFile(
  fileName: string,
  blob: Blob,
): Promise<WriteResult> {
  if (injected) {
    await injected("自动备份", fileName, blob);
    return "dir";
  }
  const custom = await readHandle(BACKUP_KEY);
  if (custom && (await ensurePermission(custom, "readwrite"))) {
    await writeInto(custom, "", fileName, blob);
    return "dir";
  }
  const root = await getArchiveRoot();
  if (!root) {
    doFallback(blob, fileName);
    return "download";
  }
  await writeInto(root, "自动备份", fileName, blob);
  return "dir";
}

/** 裁剪旧备份：删掉最旧的文件，删不掉也不影响主流程 */
export async function removeBackupFile(fileName: string): Promise<void> {
  const custom = await readHandle(BACKUP_KEY);
  const targets: DirHandleLike[] = [];
  if (custom && (await ensurePermission(custom, "readwrite"))) targets.push(custom);
  const root = await readHandle(ARCHIVE_KEY);
  if (root && (await ensurePermission(root, "readwrite"))) {
    try {
      targets.push(await root.getDirectoryHandle("自动备份", { create: false }));
    } catch {
      // 目录还没建过，忽略
    }
  }
  for (const t of targets) {
    if (!t.removeEntry) continue;
    try {
      await t.removeEntry(fileName);
    } catch {
      // 文件已不存在或权限不足
    }
  }
}

/* ------------------------------ 打开目录 ------------------------------ */

export type OpenResult = "ok" | "no-support" | "no-auth" | "denied";

/** 打开归档目录：浏览器无法直接唤起文件管理器，改为把选择框直接定位到该目录 */
export async function openArchiveDir(sub?: string): Promise<OpenResult> {
  const fn = picker();
  if (!fn) return "no-support";
  let root = await readHandle(ARCHIVE_KEY);
  if (!root) root = await pickDir(ARCHIVE_KEY);
  if (!root) return "no-auth";
  if (!(await ensurePermission(root, "read"))) return "denied";
  let target = root;
  if (sub) {
    try {
      target = await root.getDirectoryHandle(sub, { create: false });
    } catch {
      target = root;
    }
  }
  await fn({ id: "coc-open-archive", mode: "read", startIn: target });
  return "ok";
}
