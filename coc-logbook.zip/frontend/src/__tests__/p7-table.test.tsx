import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { render, screen, waitFor, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import App from "../App";
import {
  __resetDBForTest,
  clearAll,
  listModules,
  listRecords,
  putModule,
  putRecord,
} from "../lib/db";
import { useData } from "../store/useData";
import {
  buildTableCsv,
  detectColumns,
  importTableRows,
  parseTableCsv,
  type TableRow,
} from "../lib/table";
import { __setArchiveWriter, type ArchiveWriter } from "../lib/archive";
import type { LogPayload, Module } from "../lib/types";

async function renderAt(path: string) {
  window.history.pushState({}, "", path);
  render(<App />);
  await waitFor(() =>
    expect(screen.getByTestId("app-shell")).toHaveAttribute("data-ready", "1"),
  );
}

const SAMPLE_PAYLOAD: LogPayload = {
  meta: { name: "t", createdAt: "", updatedAt: "", version: 1 },
  entries: [
    {
      id: 1,
      nickname: "甲",
      account: "QQ:1",
      time: 0,
      message: "你好",
      isDice: false,
      kind: "dialog",
      images: [],
    },
  ],
};

let captured: { moduleName: string; fileName: string; size: number }[] = [];

beforeEach(async () => {
  cleanup();
  __resetDBForTest();
  await clearAll();
  useData.setState({ modules: [], records: [], loaded: false });
  captured = [];
  const writer: ArchiveWriter = async (moduleName, fileName, blob) => {
    captured.push({ moduleName, fileName, size: blob.size });
  };
  __setArchiveWriter(writer);
  vi.stubGlobal(
    "fetch",
    vi.fn(async (url: string, opts?: { body?: string }) => {
      if (String(url).includes("/api/seal/export")) {
        const body = opts?.body ? JSON.parse(opts.body) : {};
        const ext = body.type === "pdf" ? "pdf" : body.type === "txt" ? "txt" : "docx";
        const mime =
          ext === "pdf"
            ? "application/pdf"
            : "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
        return {
          ok: true,
          json: async () => ({ status: "ok", data: btoa("merged-doc"), mime, ext }),
        };
      }
      return { ok: false, json: async () => ({}) };
    }),
  );
});

afterEach(() => {
  __setArchiveWriter(null);
  vi.unstubAllGlobals();
});

describe("P7 · #12 导出表格后再导入，数量与内容不变", () => {
  it("CSV 往返后模组 / 场次数量一致，正文内容还原", async () => {
    const mod: Module = {
      id: "m1",
      name: "暗影循迹",
      kps: ["张三"],
      pairs: [{ pc: "艾伦", pl: "李四" }],
      collapsed: false,
      createdAt: Date.now(),
      order: 0,
    };
    await putModule(mod);
    await putRecord({
      id: "r1",
      moduleId: "m1",
      name: "暗影循迹第一场",
      link: "https://log.weizaima.com/?key=jmyh#201454",
      status: "valid",
      playDate: "2025-03-08",
      fetchedAt: Date.now(),
      content: SAMPLE_PAYLOAD,
      manualText: null,
      order: 0,
    });

    const modules = await listModules();
    const records = await listRecords();
    const csv = buildTableCsv(modules, records);

    // 清空后重新导入，模拟「导出 → 导入」闭环
    await clearAll();
    useData.setState({ modules: [], records: [], loaded: false });
    const rows = parseTableCsv(csv);
    const result = await importTableRows(rows);

    expect(result.modules).toBe(1);
    expect(result.records).toBe(1);

    const after = await listRecords();
    expect(after).toHaveLength(1);
    expect(after[0].name).toBe("暗影循迹第一场");
    expect(after[0].link).toBe("https://log.weizaima.com/?key=jmyh#201454");
    expect(after[0].playDate).toBe("2025-03-08");
    expect(after[0].status).toBe("valid");
    // 正文内容（含对话条目）原样还原
    expect(JSON.stringify(after[0].content)).toBe(JSON.stringify(SAMPLE_PAYLOAD));
  });
});

describe("P7 · #13 导入外部表格自动识别链接列并生成记录", () => {
  it("纯表头无「链接」字样时，扫描值自动定位链接列", () => {
    const rows: TableRow[] = [
      { 团名: "暗影循迹", 场次: "第一场", 日志地址: "https://log.weizaima.com/?key=jmyh#201454" },
    ];
    const cols = detectColumns(rows);
    expect(cols.module).toBe("团名");
    expect(cols.name).toBe("场次");
    expect(cols.link).toBe("日志地址");
  });

  it("根据链接列生成对应场次", async () => {
    const csv = [
      "团名,场次,链接",
      "暗影循迹,第一场,https://log.weizaima.com/?key=jmyh#201454",
      "沙逐,序章,https://log.weizaima.com/?key=abc#999",
    ].join("\n");
    const result = await importTableRows(parseTableCsv(csv));
    expect(result.modules).toBe(2);
    expect(result.records).toBe(2);

    const recs = await listRecords();
    const first = recs.find((r) => r.name === "第一场");
    const second = recs.find((r) => r.name === "序章");
    expect(first?.link).toBe("https://log.weizaima.com/?key=jmyh#201454");
    expect(second?.name).toBe("序章");
  });

  it("通过界面导入 CSV 后页面出现模组与场次", async () => {
    await renderAt("/records");
    await userEvent.click(screen.getByTestId("table-import-open"));
    expect(screen.getByTestId("table-import-dialog")).toBeTruthy();

    const csv = "团名,场次,链接\n暗影循迹,第一场,https://log.weizaima.com/?key=jmyh#201454\n";
    const file = new File([csv], "t.csv", { type: "text/csv" });
    await userEvent.upload(screen.getByTestId("table-import-file"), file);

    await waitFor(() => expect(screen.queryByTestId("table-import-dialog")).toBeNull());
    await waitFor(() => expect(screen.getByText("暗影循迹")).toBeTruthy());
    await waitFor(() => expect(screen.getByText("第一场")).toBeTruthy());
  });
});

describe("P7 · #11 批量合成生成合并文档", () => {
  it("把已抓取场次的正文合并成一份文档并归档", async () => {
    await putModule({
      id: "m1",
      name: "暗影循迹",
      kps: [],
      pairs: [],
      collapsed: false,
      createdAt: Date.now(),
      order: 0,
    });
    await putRecord({
      id: "r1",
      moduleId: "m1",
      name: "第一场",
      link: "https://log.weizaima.com/?key=a#1",
      status: "valid",
      playDate: "2025-03-08",
      fetchedAt: Date.now(),
      content: SAMPLE_PAYLOAD,
      manualText: null,
      order: 0,
    });
    await putRecord({
      id: "r2",
      moduleId: "m1",
      name: "第二场",
      link: "https://log.weizaima.com/?key=b#2",
      status: "valid",
      playDate: "2025-03-09",
      fetchedAt: Date.now(),
      content: SAMPLE_PAYLOAD,
      manualText: null,
      order: 1,
    });

    await renderAt("/records");
    // 批量合成只处理勾选的记录：这里两条都勾上
    await userEvent.click(screen.getByTestId("rec-select-r1"));
    await userEvent.click(screen.getByTestId("rec-select-r2"));
    await userEvent.click(screen.getByTestId("merge-open"));
    expect(screen.getByTestId("merge-dialog")).toBeTruthy();
    await userEvent.click(screen.getByTestId("merge-docx"));
    await userEvent.click(screen.getByTestId("merge-confirm"));

    await waitFor(() => expect(captured.length).toBeGreaterThan(0));
    expect(captured[0].moduleName).toBe("跑团记录汇总");
    expect(captured[0].fileName).toBe("跑团记录汇总合并.docx");
    expect(captured[0].size).toBeGreaterThan(0);
  });
});
