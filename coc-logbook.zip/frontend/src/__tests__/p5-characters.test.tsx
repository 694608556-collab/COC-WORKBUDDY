import { beforeEach, describe, expect, it } from "vitest";
import { render, screen, waitFor, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import App from "../App";
import { __resetDBForTest, clearAll, listCharacters, listModules } from "../lib/db";
import { useCharacters } from "../store/useCharacters";
import { useData } from "../store/useData";
import { useToast } from "../store/useToast";
import { derive } from "../lib/character";

async function renderAt(path: string) {
  cleanup();
  window.history.pushState({}, "", path);
  render(<App />);
  await waitFor(() => expect(screen.getByTestId("app-shell")).toHaveAttribute("data-ready", "1"));
}

async function createModule(name: string) {
  await userEvent.click(screen.getByTestId("module-new"));
  await userEvent.type(screen.getByTestId("module-name"), name);
  await userEvent.click(screen.getByTestId("module-save"));
  await waitFor(() => expect(screen.queryByTestId("module-dialog")).toBeNull());
}

beforeEach(async () => {
  cleanup();
  __resetDBForTest();
  await clearAll();
  useData.setState({ modules: [], records: [], loaded: false });
  useCharacters.setState({ characters: [], loaded: false });
  useToast.setState({ items: [] });
});

describe("P5 · 派生值公式", () => {
  it("18 切到第六版，幸运 = POW × 5", () => {
    expect(derive(6, { STR: 0, CON: 0, SIZ: 0, DEX: 0, APP: 0, INT: 0, POW: 70, EDU: 0 }).luck).toBe(350);
    expect(derive(7, { STR: 0, CON: 0, SIZ: 0, DEX: 0, APP: 0, INT: 0, POW: 70, EDU: 0 }).luck).toBe(350);
  });

  it("19 切换版本后魔法值按公式重算（六版 ≠ 七版）", () => {
    const a = { STR: 0, CON: 0, SIZ: 0, DEX: 0, APP: 0, INT: 0, POW: 50, EDU: 0 };
    expect(derive(7, a).mp).toBe(10);
    expect(derive(6, a).mp).toBe(13);
  });

  it("24 技能上限：职业技能 EDU×4，个人兴趣 INT×2", () => {
    const d = derive(7, { STR: 0, CON: 0, SIZ: 0, DEX: 0, APP: 0, INT: 80, POW: 0, EDU: 90 });
    expect(d.occCap).toBe(360);
    expect(d.intCap).toBe(160);
  });
});

describe("P5 · 角色卡页面", () => {
  it("空状态引导", async () => {
    await renderAt("/characters");
    expect(screen.getByTestId("chars-empty")).toHaveTextContent("还没有角色卡");
  });

  it("17 新建时可选择第六版 / 第七版并带模组", async () => {
    await renderAt("/records");
    await createModule("暗影循迹");
    await renderAt("/characters");

    await userEvent.click(screen.getByTestId("char-new"));
    await userEvent.selectOptions(screen.getByTestId("new-card-module"), await firstModuleId());
    await userEvent.click(screen.getByTestId("new-card-6"));
    await userEvent.click(screen.getByTestId("new-card-confirm"));

    expect(screen.getByTestId("char-editor")).toBeTruthy();
    await userEvent.type(screen.getByTestId("char-basic-name"), "艾伦·韦斯特");
    await userEvent.type(screen.getByTestId("char-basic-job"), "记者");
    await userEvent.click(screen.getByTestId("char-save"));

    await waitFor(() => expect(screen.queryByTestId("char-editor")).toBeNull());
    const chars = await listCharacters();
    expect(chars).toHaveLength(1);
    expect(chars[0].edition).toBe(6);
    expect(chars[0].basic.name).toBe("艾伦·韦斯特");
    expect(chars[0].moduleId).toBe(await firstModuleId());
  });

  it("24.1 小卡三行：模组名 → 角色名 → 职业 · 版本", async () => {
    await renderAt("/records");
    await createModule("暗影循迹");
    await renderAt("/characters");
    await newCard("第七版", "艾伦·韦斯特", "记者");

    expect(screen.getByTestId("card-list")).toBeTruthy();
    const chars = await listCharacters();
    const cid = chars[0].id;
    expect(screen.getByTestId(`char-mod-${cid}`)).toHaveTextContent("暗影循迹");
    expect(screen.getByTestId(`char-name-${cid}`)).toHaveTextContent("艾伦·韦斯特");
    expect(screen.getByTestId(`char-meta-${cid}`)).toHaveTextContent("记者 · 第七版");
  });

  it("20 INT / EDU 高亮", async () => {
    await renderAt("/characters");
    const id = await newCard("第七版", "艾", "记者");
    await openCard(id);
    const intField = screen.getByTestId("attr-INT").closest(".f")!;
    const eduField = screen.getByTestId("attr-EDU").closest(".f")!;
    const strField = screen.getByTestId("attr-STR").closest(".f")!;
    expect(intField.className).toContain("hl");
    expect(eduField.className).toContain("hl");
    expect(strField.className).not.toContain("hl");
  });

  it("20/22 卡面不显示成功线（常规 / 困难 / 极难）", async () => {
    await renderAt("/characters");
    const id = await newCard("第七版", "艾", "记者");
    await openCard(id);
    const editor = screen.getByTestId("char-editor");
    expect(editor.textContent).not.toContain("常规");
    expect(editor.textContent).not.toContain("困难");
    expect(editor.textContent).not.toContain("极难");
  });

  it("19 切换版本按钮即时重算派生值", async () => {
    await renderAt("/characters");
    const id = await newCard("第七版", "艾", "记者");
    await openCard(id);
    await userEvent.type(screen.getByTestId("attr-POW"), "50");
    // 七版 MP = 10
    expect(screen.getByTestId("derived").textContent).toContain("魔法 10");
    await userEvent.click(screen.getByTestId("edition-switch"));
    // 六版 MP = 13
    await waitFor(() => expect(screen.getByTestId("derived").textContent).toContain("魔法 13"));
  });

  it("23 多张卡可切换，当前卡高亮", async () => {
    await renderAt("/records");
    await createModule("暗影循迹");
    await renderAt("/characters");
    const id1 = await newCard("第七版", "艾伦", "记者");
    const id2 = await newCard("第七版", "贝拉", "记者");

    const first = screen.getByTestId(`char-${id1}`);
    const second = screen.getByTestId(`char-${id2}`);
    expect(first.className).not.toContain("on");
    await userEvent.click(second);
    expect(second.className).toContain("on");
  });

  it("19/24.3 财产与装备左右两栏、一个物品一行", async () => {
    await renderAt("/characters");
    const id = await newCard("第七版", "艾", "记者");
    await openCard(id);
    await userEvent.click(screen.getByTestId("item-add"));
    await userEvent.click(screen.getByTestId("item-add"));
    await userEvent.type(screen.getByTestId("item-input-0"), "笔记本与钢笔");
    await userEvent.type(screen.getByTestId("item-input-1"), "袖珍相机");
    await userEvent.click(screen.getByTestId("char-save"));
    await waitFor(() => expect(screen.queryByTestId("char-editor")).toBeNull());
    const chars = await listCharacters();
    expect(chars[0].items).toEqual(["笔记本与钢笔", "袖珍相机"]);
  });

  it("19 背景详情 9 项与背景故事均可填写", async () => {
    await renderAt("/characters");
    const id = await newCard("第七版", "艾", "记者");
    await openCard(id);
    await userEvent.type(screen.getByTestId("bg-description"), "一名记者");
    await userEvent.type(screen.getByTestId("bg-phobia"), "怕黑");
    await userEvent.type(screen.getByTestId("story"), "故事内容");
    await userEvent.click(screen.getByTestId("char-save"));
    await waitFor(() => expect(screen.queryByTestId("char-editor")).toBeNull());
    const chars = await listCharacters();
    expect(chars[0].background.description).toBe("一名记者");
    expect(chars[0].background.phobia).toBe("怕黑");
    expect(chars[0].story).toBe("故事内容");
  });

  it("21/22 手动录入：各字段可填写并落库", async () => {
    await renderAt("/records");
    await createModule("暗影循迹");
    await renderAt("/characters");
    const id = await newCard("第七版", "艾伦·韦斯特", "记者");
    await openCard(id);
    await userEvent.type(screen.getByTestId("attr-EDU"), "80");
    await userEvent.type(screen.getByTestId("char-basic-age"), "28");
    await userEvent.type(screen.getByTestId("bg-description"), "一名记者");
    await userEvent.click(screen.getByTestId("char-save"));
    await waitFor(() => expect(screen.queryByTestId("char-editor")).toBeNull());
    const chars = await listCharacters();
    expect(chars[0].basic.name).toBe("艾伦·韦斯特");
    expect(chars[0].basic.job).toBe("记者");
    expect(chars[0].attrs.EDU).toBe(80);
    expect(chars[0].basic.age).toBe("28");
    expect(chars[0].background.description).toBe("一名记者");
  });
});

async function firstModuleId(): Promise<string> {
  const m = (await listModules())[0];
  return m.id;
}

async function newCard(edition: "第六版" | "第七版", name: string, job: string) {
  await userEvent.click(screen.getByTestId("char-new"));
  if (edition === "第六版") await userEvent.click(screen.getByTestId("new-card-6"));
  await userEvent.click(screen.getByTestId("new-card-confirm"));
  await userEvent.type(screen.getByTestId("char-basic-name"), name);
  await userEvent.type(screen.getByTestId("char-basic-job"), job);
  await userEvent.click(screen.getByTestId("char-save"));
  await waitFor(() => expect(screen.queryByTestId("char-editor")).toBeNull());
  return (await listCharacters()).slice(-1)[0].id;
}

async function openCard(id: string) {
  await userEvent.click(screen.getByTestId(`char-${id}`));
  await waitFor(() => expect(screen.getByTestId("char-editor")).toBeTruthy());
}
