import { beforeEach, describe, expect, it } from "vitest";
import { render, screen, waitFor, cleanup, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import App from "../App";
import { __resetDBForTest, getSettings, saveSettings } from "../lib/db";
import { applyTheme } from "../store/useSettings";

function goto(path: string) {
  window.history.pushState({}, "", path);
}

async function renderAt(path: string) {
  goto(path);
  const utils = render(<App />);
  await waitFor(() =>
    expect(screen.getByTestId("app-shell")).toHaveAttribute("data-ready", "1"),
  );
  return utils;
}

beforeEach(async () => {
  __resetDBForTest();
  await saveSettings({ theme: "light" });
  document.documentElement.dataset.theme = "light";
});

describe("P1 主题切换", () => {
  it("默认是浅色", async () => {
    await renderAt("/records");
    expect(document.documentElement.dataset.theme).toBe("light");
  });

  it("点「浅/深」切到深色，并写回本地存储", async () => {
    await renderAt("/records");
    await userEvent.click(screen.getByTestId("theme-toggle"));
    await waitFor(() => expect(document.documentElement.dataset.theme).toBe("dark"));
    await waitFor(async () => expect((await getSettings()).theme).toBe("dark"));
  });

  it("再点一次切回浅色", async () => {
    await renderAt("/records");
    const btn = screen.getByTestId("theme-toggle");
    await userEvent.click(btn);
    await waitFor(() => expect(document.documentElement.dataset.theme).toBe("dark"));
    await userEvent.click(btn);
    await waitFor(() => expect(document.documentElement.dataset.theme).toBe("light"));
  });

  it("重新打开应用后仍是上次选择的主题", async () => {
    await saveSettings({ theme: "dark" });
    applyTheme("light"); // 模拟刚启动、还没读到设置
    await renderAt("/records");
    await waitFor(() => expect(document.documentElement.dataset.theme).toBe("dark"));
  });

  it("按钮文案固定为「浅/深」", async () => {
    await renderAt("/records");
    expect(screen.getByTestId("theme-toggle")).toHaveTextContent("浅/深");
  });
});

describe("P1 应用骨架", () => {
  it("标题栏：应用名纯文字，无图标色块，右侧三个圆点", async () => {
    await renderAt("/records");
    expect(screen.getByTestId("brand")).toHaveTextContent("COC 跑团记录簿");
    expect(screen.queryByTestId("brand-mark")).toBeNull();
    expect(screen.getByTestId("wb-min")).toBeInTheDocument();
    expect(screen.getByTestId("wb-max")).toBeInTheDocument();
    expect(screen.getByTestId("wb-close")).toBeInTheDocument();
  });

  it("侧边导航：当前模块前的圆点是高亮的，其他不是", async () => {
    await renderAt("/characters");
    const dots = screen.getByTestId("nav-characters").querySelector(".dot");
    expect(dots).toHaveAttribute("data-active", "true");
    expect(screen.getByTestId("nav-records").querySelector(".dot")).toHaveAttribute(
      "data-active",
      "false",
    );
    expect(screen.getByTestId("nav-settings").querySelector(".dot")).toHaveAttribute(
      "data-active",
      "false",
    );
  });

  it("模块一标题栏 54px", async () => {
    await renderAt("/records");
    expect(screen.getByTestId("module-top")).toHaveAttribute("data-height", "54px");
    expect(within(screen.getByTestId("module-top")).getByText("跑团记录汇总")).toBeInTheDocument();
  });

  it("模块二标题栏 72px", async () => {
    await renderAt("/characters");
    expect(screen.getByTestId("module-top")).toHaveAttribute("data-height", "72px");
    expect(within(screen.getByTestId("module-top")).getByText("调查员角色卡")).toBeInTheDocument();
  });

  it("模块三标题栏 72px", async () => {
    await renderAt("/settings");
    expect(screen.getByTestId("module-top")).toHaveAttribute("data-height", "72px");
    expect(within(screen.getByTestId("module-top")).getByText("数据与设置")).toBeInTheDocument();
    expect(within(screen.getByTestId("module-top")).getByText("全部数据仅保存在本机")).toBeInTheDocument();
  });

  it("三个模块标题栏都带「浅/深」按钮", async () => {
    for (const p of ["/records", "/characters", "/settings"]) {
      cleanup();
      await renderAt(p);
      expect(screen.getByTestId("theme-toggle")).toBeInTheDocument();
    }
  });
});
