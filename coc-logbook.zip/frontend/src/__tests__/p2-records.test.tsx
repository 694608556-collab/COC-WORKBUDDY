import { beforeEach, describe, expect, it } from "vitest";
import { render, screen, waitFor, cleanup, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import App from "../App";
import { __resetDBForTest, clearAll, listModules, listRecords } from "../lib/db";
import { useData } from "../store/useData";
import {
  buildFileName,
  cnNumber,
  defaultRecordName,
  parseSealLink,
} from "../lib/naming";

async function renderAt(path: string) {
  window.history.pushState({}, "", path);
  render(<App />);
  await waitFor(() =>
    expect(screen.getByTestId("app-shell")).toHaveAttribute("data-ready", "1"),
  );
}

/** 重新挂载一次，模拟关掉页面再打开 */
async function reopen() {
  cleanup();
  useData.setState({ modules: [], records: [], loaded: false });
  await renderAt("/records");
}

function currentModuleId() {
  const m = useData.getState().modules[0];
  if (!m) throw new Error("还没有模组");
  return m.id;
}

async function createModule(name: string) {
  await userEvent.click(screen.getByTestId("module-new"));
  await userEvent.type(screen.getByTestId("module-name"), name);
  await userEvent.click(screen.getByTestId("module-save"));
  await waitFor(() => expect(screen.queryByTestId("module-dialog")).toBeNull());
}

async function addRecord(link: string) {
  const id = currentModuleId();
  await userEvent.click(screen.getByTestId(`add-${id}`));
  await userEvent.type(screen.getByTestId("record-link"), link);
  await userEvent.click(screen.getByTestId("record-save"));
  await waitFor(() => expect(screen.queryByTestId("record-dialog")).toBeNull());
}

beforeEach(async () => {
  cleanup();
  __resetDBForTest();
  await clearAll();
  useData.setState({ modules: [], records: [], loaded: false });
});

describe("P2 · 命名工具", () => {
  it("中文数字：1 一 / 10 十 / 11 十一 / 25 二十五", () => {
    expect(cnNumber(1)).toBe("一");
    expect(cnNumber(10)).toBe("十");
    expect(cnNumber(11)).toBe("十一");
    expect(cnNumber(25)).toBe("二十五");
  });

  it("场次默认名为「模组名第X场」", () => {
    expect(defaultRecordName("暗影循迹", 1)).toBe("暗影循迹第一场");
    expect(defaultRecordName("暗影循迹", 3)).toBe("暗影循迹第三场");
  });

  it("下载文件名为「年月日 + 模组名 + 场次名」", () => {
    expect(buildFileName("2025-03-08", "暗影循迹", "暗影循迹第一场", "docx")).toBe(
      "20250308暗影循迹暗影循迹第一场.docx",
    );
  });

  it("从海豹链接中取到 key 与 # 后面的密码", () => {
    expect(parseSealLink("https://log.weizaima.com/?key=jmyh#201454")).toEqual({
      key: "jmyh",
      password: "201454",
    });
    expect(parseSealLink("https://log.weizaima.com/?key=jmyh")).toEqual({
      key: "jmyh",
      password: "",
    });
    expect(parseSealLink("不是链接")).toBeNull();
  });
});

describe("P2 · 模块一 模组与场次", () => {
  it("空状态下给出引导文案", async () => {
    await renderAt("/records");
    expect(screen.getByTestId("records-empty")).toHaveTextContent("还没有模组");
  });

  it("① 新建模组后出现在列表中，顶部「模组数」+1", async () => {
    await renderAt("/records");
    expect(within(screen.getByTestId("module-top")).getByText(/模组 0 · 场次 0/)).toBeTruthy();

    await createModule("测试模组");

    expect(within(screen.getByTestId("module-top")).getByText(/模组 1 · 场次 0/)).toBeTruthy();
    expect(screen.getByTestId(`gname-${currentModuleId()}`)).toHaveTextContent("测试模组");
    expect(await listModules()).toHaveLength(1);
  });

  it("② 新增场次时名称自动生成「模组名第X场」", async () => {
    await renderAt("/records");
    await createModule("测试模组");
    await addRecord("https://log.weizaima.com/?key=jmyh#201454");

    const r = (await listRecords())[0];
    expect(r.name).toBe("测试模组第一场");
    expect(screen.getByTestId(`rec-name-${r.id}`)).toHaveTextContent("测试模组第一场");

    await addRecord("https://log.weizaima.com/?key=jmyh#201454");
    const all = await listRecords();
    expect(all[1].name).toBe("测试模组第二场");
    expect(within(screen.getByTestId("module-top")).getByText(/模组 1 · 场次 2/)).toBeTruthy();
  });

  it("新增场次时可以自己填名称，填了就用填写的", async () => {
    await renderAt("/records");
    await createModule("测试模组");
    const id = currentModuleId();
    await userEvent.click(screen.getByTestId(`add-${id}`));
    await userEvent.type(screen.getByTestId("record-name"), "序章 · 雨夜");
    await userEvent.click(screen.getByTestId("record-save"));
    await waitFor(() => expect(screen.queryByTestId("record-dialog")).toBeNull());
    expect((await listRecords())[0].name).toBe("序章 · 雨夜");
  });

  it("2.1 参与者按 KP / PC / PL 分栏保存，重新打开仍一致", async () => {
    await renderAt("/records");
    await createModule("测试模组");
    const id = currentModuleId();

    await userEvent.click(screen.getByTestId(`gname-${id}`));
    await userEvent.type(screen.getByTestId("kp-input-0"), "张三");
    await userEvent.type(screen.getByTestId("pc-input-0"), "艾伦");
    await userEvent.type(screen.getByTestId("pl-input-0"), "李四");
    await userEvent.click(screen.getByTestId("module-save"));
    await waitFor(() => expect(screen.queryByTestId("module-dialog")).toBeNull());

    const saved = (await listModules())[0];
    expect(saved.kps).toEqual(["张三"]);
    expect(saved.pairs).toEqual([{ pc: "艾伦", pl: "李四" }]);

    await userEvent.click(screen.getByTestId(`gname-${id}`));
    expect(screen.getByTestId("kp-input-0")).toHaveValue("张三");
    expect(screen.getByTestId("pc-tag-0")).toHaveTextContent("PC1");
    expect(screen.getByTestId("pc-input-0")).toHaveValue("艾伦");
    expect(screen.getByTestId("pl-tag-0")).toHaveTextContent("PL1");
    expect(screen.getByTestId("pl-input-0")).toHaveValue("李四");
  });

  it("2.2 删除中间一对 PC / PL 后，后面的编号自动重排", async () => {
    await renderAt("/records");
    await createModule("测试模组");
    const id = currentModuleId();

    await userEvent.click(screen.getByTestId(`gname-${id}`));
    for (const [i, pc, pl] of [
      [0, "甲", "玩家甲"],
      [1, "乙", "玩家乙"],
      [2, "丙", "玩家丙"],
    ] as const) {
      if (i > 0) await userEvent.click(screen.getByTestId("pair-add"));
      await userEvent.type(screen.getByTestId(`pc-input-${i}`), pc);
      await userEvent.type(screen.getByTestId(`pl-input-${i}`), pl);
    }
    expect(screen.getByTestId("pc-tag-2")).toHaveTextContent("PC3");

    await userEvent.click(screen.getByTestId("pair-del-1"));

    expect(screen.queryByTestId("pc-input-2")).toBeNull();
    expect(screen.getByTestId("pc-tag-1")).toHaveTextContent("PC2");
    expect(screen.getByTestId("pc-input-1")).toHaveValue("丙");
    expect(screen.getByTestId("pl-input-1")).toHaveValue("玩家丙");

    await userEvent.click(screen.getByTestId("module-save"));
    await waitFor(() => expect(screen.queryByTestId("module-dialog")).toBeNull());
    expect((await listModules())[0].pairs).toEqual([
      { pc: "甲", pl: "玩家甲" },
      { pc: "丙", pl: "玩家丙" },
    ]);
  });

  it("③ 点折叠按钮，该模组的表格消失，按钮由 ▾ 变 ▸", async () => {
    await renderAt("/records");
    await createModule("测试模组");
    await addRecord("https://log.weizaima.com/?key=jmyh#201454");
    const id = currentModuleId();
    const rid = (await listRecords())[0].id;

    expect(screen.getByTestId(`fold-${id}`)).toHaveTextContent("▾");
    expect(screen.getByTestId(`rec-row-${rid}`)).toBeTruthy();

    await userEvent.click(screen.getByTestId(`fold-${id}`));

    await waitFor(() => expect(screen.getByTestId(`fold-${id}`)).toHaveTextContent("▸"));
    expect(screen.queryByTestId(`rec-row-${rid}`)).toBeNull();
    expect(screen.getByTestId(`module-${id}`)).toHaveAttribute("data-collapsed", "1");
    expect(screen.getByTestId(`gname-${id}`)).toHaveTextContent("测试模组");
  });

  it("④ 折叠状态重新打开页面后仍然保持", async () => {
    await renderAt("/records");
    await createModule("测试模组");
    await addRecord("https://log.weizaima.com/?key=jmyh#201454");
    const id = currentModuleId();
    await userEvent.click(screen.getByTestId(`fold-${id}`));
    await waitFor(() => expect(screen.getByTestId(`fold-${id}`)).toHaveTextContent("▸"));

    await reopen();

    await waitFor(() => expect(screen.getByTestId(`fold-${id}`)).toHaveTextContent("▸"));
    expect(screen.getByTestId(`module-${id}`)).toHaveAttribute("data-collapsed", "1");
  });

  it("重新打开页面后模组与场次都还在", async () => {
    await renderAt("/records");
    await createModule("暗影循迹");
    await addRecord("https://log.weizaima.com/?key=jmyh#201454");

    await reopen();

    await waitFor(() => expect(screen.getByTestId(`gname-${currentModuleId()}`)).toBeTruthy());
    expect(screen.getByTestId(`gname-${currentModuleId()}`)).toHaveTextContent("暗影循迹");
    expect(within(screen.getByTestId("module-top")).getByText(/模组 1 · 场次 1/)).toBeTruthy();
  });

  it("删除模组要二次确认，确认后连同场次一起删除", async () => {
    await renderAt("/records");
    await createModule("测试模组");
    await addRecord("https://log.weizaima.com/?key=jmyh#201454");
    const id = currentModuleId();

    await userEvent.click(screen.getByTestId(`gname-${id}`));
    await userEvent.click(screen.getByTestId("module-delete"));
    expect(screen.getByTestId("confirm-text")).toHaveTextContent("测试模组");
    await userEvent.click(screen.getByTestId("confirm-ok"));

    await waitFor(() => expect(screen.getByTestId("records-empty")).toBeTruthy());
    expect(await listModules()).toHaveLength(0);
    expect(await listRecords()).toHaveLength(0);
  });

  it("删除单条场次只删这一条，模组还在", async () => {
    await renderAt("/records");
    await createModule("测试模组");
    await addRecord("https://log.weizaima.com/?key=a#1");
    await addRecord("https://log.weizaima.com/?key=b#2");
    const all = await listRecords();

    await userEvent.click(screen.getByTestId(`rec-del-${all[0].id}`));
    await userEvent.click(screen.getByTestId("confirm-ok"));

    await waitFor(() => expect(screen.queryByTestId(`rec-row-${all[0].id}`)).toBeNull());
    expect(screen.getByTestId(`rec-row-${all[1].id}`)).toBeTruthy();
    expect(await listRecords()).toHaveLength(1);
    expect(await listModules()).toHaveLength(1);
  });

  it("编辑场次可以改名称和链接", async () => {
    await renderAt("/records");
    await createModule("测试模组");
    await addRecord("https://log.weizaima.com/?key=a#1");
    const rid = (await listRecords())[0].id;

    await userEvent.click(screen.getByTestId(`rec-edit-${rid}`));
    const name = screen.getByTestId("record-name");
    await userEvent.clear(name);
    await userEvent.type(name, "终章");
    await userEvent.click(screen.getByTestId("record-save"));
    await waitFor(() => expect(screen.queryByTestId("record-dialog")).toBeNull());

    expect((await listRecords())[0].name).toBe("终章");
  });

  it("模组名旁有文件夹图标", async () => {
    await renderAt("/records");
    await createModule("测试模组");
    expect(screen.getByTestId(`folder-${currentModuleId()}`)).toBeTruthy();
  });
});
