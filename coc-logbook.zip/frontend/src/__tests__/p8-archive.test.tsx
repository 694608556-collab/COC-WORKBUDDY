import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { render, screen, waitFor, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import App from "../App";
import { __resetDBForTest, clearAll, deleteHandle, getSettings, saveSettings } from "../lib/db";
import { useData } from "../store/useData";
import { useSettings } from "../store/useSettings";
import { useToast } from "../store/useToast";
import {
  __resetArchiveHandles,
  __setArchiveWriter,
  __setFallback,
  ARCHIVE_KEY,
  BACKUP_KEY,
  archiveDirName,
  getArchiveRoot,
  openArchiveDir,
  writeFile,
  type DirHandleLike,
} from "../lib/archive";
import { DEFAULT_EXPORT_OPTIONS } from "../lib/types";

type PickCall = { id?: string; mode?: string; startIn?: DirHandleLike };

class FakeDir implements DirHandleLike {
  name: string;
  dirs = new Map<string, FakeDir>();
  files = new Map<string, Blob>();
  permission: PermissionState = "prompt";
  requests = 0;
  removed: string[] = [];
  constructor(name: string) {
    this.name = name;
  }
  async getDirectoryHandle(name: string, opts?: { create?: boolean }): Promise<DirHandleLike> {
    if (!this.dirs.has(name)) {
      if (opts?.create === false) throw new Error(`NotFoundError: ${name}`);
      this.dirs.set(name, new FakeDir(name));
    }
    return this.dirs.get(name)!;
  }
  async getFileHandle(name: string, opts?: { create?: boolean }) {
    if (!this.files.has(name)) {
      if (opts?.create === false) throw new Error(`NotFoundError: ${name}`);
      this.files.set(name, new Blob([""]));
    }
    const self = this;
    return {
      async createWritable() {
        return {
          async write(b: Blob) {
            self.files.set(name, b);
          },
          async close() {},
        };
      },
    };
  }
  async removeEntry(name: string) {
    if (!this.files.has(name)) throw new Error("not found");
    this.files.delete(name);
    this.removed.push(name);
  }
  async queryPermission() {
    return this.permission;
  }
  async requestPermission() {
    this.requests++;
    if (this.permission === "prompt") this.permission = "granted";
    return this.permission;
  }
}

let root: FakeDir;
let picks: PickCall[] = [];

function installPicker() {
  (globalThis as any).showDirectoryPicker = async (opts?: PickCall) => {
    picks.push(opts ?? {});
    return root as unknown as DirHandleLike;
  };
}

function lastPick(): PickCall {
  return picks[picks.length - 1];
}

async function renderAt(path: string) {
  window.history.pushState({}, "", path);
  render(<App />);
  await waitFor(() => expect(screen.getByTestId("app-shell")).toHaveAttribute("data-ready", "1"));
}

beforeEach(async () => {
  cleanup();
  __resetDBForTest();
  __resetArchiveHandles();
  await clearAll();
  await deleteHandle(ARCHIVE_KEY);
  await deleteHandle(BACKUP_KEY);
  await saveSettings({ exportOptions: { ...DEFAULT_EXPORT_OPTIONS } });
  useData.setState({ modules: [], records: [], loaded: false });
  useSettings.setState({
    settings: { ...useSettings.getState().settings, downloadDir: "", exportOptions: { ...DEFAULT_EXPORT_OPTIONS } },
    loaded: true,
  });
  useToast.setState({ items: [] });
  __setArchiveWriter(null);
  __setFallback(null);
  picks = [];
  root = new FakeDir("COC跑团记录");
  installPicker();
});

afterEach(() => {
  delete (globalThis as any).showDirectoryPicker;
  __setArchiveWriter(null);
  __setFallback(null);
});

describe("P1 · 归档目录一次授权", () => {
  it("首次写入时授权一次，之后静默复用同一个目录句柄", async () => {
    await writeFile("暗影循迹", "20260904暗影循迹第一场.txt", new Blob(["A"]));
    await writeFile("暗影循迹", "20260905暗影循迹第二场.docx", new Blob(["BC"]));
    await writeFile("克苏鲁的呼唤", "20261001克苏鲁的呼唤第一场.pdf", new Blob(["D"]));

    expect(picks.length).toBe(1);
    expect(await archiveDirName()).toBe("COC跑团记录");
    expect(root.dirs.has("暗影循迹")).toBe(true);
    expect(root.dirs.has("克苏鲁的呼唤")).toBe(true);
    const dir = root.dirs.get("暗影循迹")!;
    expect([...dir.files.keys()]).toEqual([
      "20260904暗影循迹第一场.txt",
      "20260905暗影循迹第二场.docx",
    ]);
    expect((await dir.files.get("20260904暗影循迹第一场.txt")!.text())).toBe("A");
    expect((await dir.files.get("20260905暗影循迹第二场.docx")!.text())).toBe("BC");
  });

  it("权限过期时自动重新申请，申请成功后继续写入", async () => {
    await writeFile("暗影循迹", "a.txt", new Blob(["A"]));
    const before = root.requests;
    root.permission = "prompt"; // 模拟浏览器重启后权限过期
    const r = await writeFile("暗影循迹", "b.txt", new Blob(["B"]));
    expect(r).toBe("dir");
    expect(root.requests).toBe(before + 1);
    expect(root.dirs.get("暗影循迹")!.files.has("b.txt")).toBe(true);
  });

  it("用户拒绝授权时回退到浏览器下载，不抛错", async () => {
    root.permission = "denied";
    const fallen: string[] = [];
    __setFallback((_blob, fileName) => fallen.push(fileName));
    const r = await writeFile("暗影循迹", "a.txt", new Blob(["A"]));
    expect(r).toBe("download");
    expect(fallen).toEqual(["a.txt"]);
  });

  it("浏览器不支持时回退到浏览器下载", async () => {
    delete (globalThis as any).showDirectoryPicker;
    const fallen: string[] = [];
    __setFallback((_blob, fileName) => fallen.push(fileName));
    const r = await writeFile("暗影循迹", "a.txt", new Blob(["A"]));
    expect(r).toBe("download");
    expect(fallen).toEqual(["a.txt"]);
  });

  it("打开归档目录：定位到根目录；传模组名时定位到该模组子目录", async () => {
    const r1 = await openArchiveDir();
    expect(r1).toBe("ok");
    expect(lastPick().id).toBe("coc-open-archive");
    expect((lastPick().startIn as unknown as FakeDir).name).toBe("COC跑团记录");

    await writeFile("暗影循迹", "a.txt", new Blob(["A"])); // 建出模组子目录
    const r2 = await openArchiveDir("暗影循迹");
    expect(r2).toBe("ok");
    expect((lastPick().startIn as unknown as FakeDir).name).toBe("暗影循迹");
  });

  it("未授权时点打开目录会先弹一次选择，用户取消则给出 no-auth", async () => {
    delete (globalThis as any).showDirectoryPicker;
    (globalThis as any).showDirectoryPicker = async () => {
      throw new Error("aborted");
    };
    expect(await openArchiveDir()).toBe("no-auth");
  });
});

describe("P1 · 设置页下载归档位置", () => {
  it("点文件夹图标选择归档位置后，目录名写入设置并展示", async () => {
    await renderAt("/settings");
    await userEvent.click(screen.getByTestId("download-dir-pick"));
    await waitFor(async () => {
      expect((await getSettings()).downloadDir).toBe("COC跑团记录");
    });
    expect((screen.getByTestId("download-dir") as HTMLInputElement).value).toBe("COC跑团记录");
    expect(screen.getByText(/已授权：COC跑团记录/)).toBeTruthy();
  });

  it("点标签旁的图标会打开（定位到）当前归档目录", async () => {
    await renderAt("/settings");
    await userEvent.click(screen.getByTestId("download-dir-pick"));
    await waitFor(() => expect(screen.getByText(/已授权：/)).toBeTruthy());
    picks = [];
    await userEvent.click(screen.getByTestId("download-dir-open"));
    await waitFor(() => expect(picks.length).toBe(1));
    expect(lastPick().id).toBe("coc-open-archive");
    expect((lastPick().startIn as unknown as FakeDir).name).toBe("COC跑团记录");
  });
});

describe("P1 · 模块一文件夹图标", () => {
  it("14 点模组文件夹图标，打开的是该模组的归档子目录", async () => {
    // 预建模组子目录，模拟之前下载过
    const r = await getArchiveRoot();
    expect(r).not.toBeNull();
    await r!.getDirectoryHandle("暗影循迹", { create: true });

    await useData.getState().addModule({ name: "暗影循迹", kps: [], pairs: [] });
    const mid = useData.getState().modules[0].id;
    await renderAt("/records");
    await waitFor(() => expect(screen.getByTestId(`folder-${mid}`)).toBeTruthy());

    picks = [];
    await userEvent.click(screen.getByTestId(`folder-${mid}`));
    await waitFor(() => expect(picks.length).toBe(1));
    expect(lastPick().id).toBe("coc-open-archive");
    expect((lastPick().startIn as unknown as FakeDir).name).toBe("暗影循迹");
  });
});
