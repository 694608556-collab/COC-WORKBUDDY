import { beforeEach, describe, expect, it } from "vitest";
import { render, screen, waitFor, cleanup, fireEvent } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import App from "../App";
import { __resetDBForTest, clearAll, listModules, listRecords } from "../lib/db";
import { useData } from "../store/useData";
import { useCharacters } from "../store/useCharacters";
import { useToast } from "../store/useToast";
import { __setArchiveWriter } from "../lib/archive";
import {
  backupFileName,
  buildBackup,
  restoreBackup,
  pruneHistory,
  runAutoBackup,
} from "../lib/backup";

async function renderAt(path: string) {
  cleanup();
  window.history.pushState({}, "", path);
  render(<App />);
  await waitFor(() => expect(screen.getByTestId("app-shell")).toHaveAttribute("data-ready", "1"));
}

async function seed() {
  await useData.getState().addModule({ name: "暗影循迹", kps: ["张三"], pairs: [{ pc: "艾伦", pl: "李四" }] });
  const m = (await listModules())[0];
  await useData.getState().addRecord({ moduleId: m.id, name: "第一场", link: "https://log.weizaima.com/?key=jmyh#201454" });
  await useCharacters.getState().add({
    moduleId: m.id,
    edition: 7,
    card: {
      id: "",
      moduleId: m.id,
      edition: 7,
      basic: { name: "艾伦", job: "记者", age: "", gender: "", birthplace: "", residence: "" },
      attrs: { STR: 0, CON: 0, SIZ: 0, DEX: 0, APP: 0, INT: 0, POW: 0, EDU: 0 },
      weapons: [],
      skills: [],
      items: [],
      background: {
        description: "", belief: "", importantPerson: "", significantPlace: "", treasure: "", trait: "", secret: "", wound: "", phobia: "",
      },
      story: "",
      createdAt: Date.now(),
    },
  });
}

beforeEach(async () => {
  cleanup();
  __resetDBForTest();
  await clearAll();
  useData.setState({ modules: [], records: [], loaded: false });
  useCharacters.setState({ characters: [], loaded: false });
  useToast.setState({ items: [] });
  __setArchiveWriter(null);
});

describe("P6 · 数据与设置", () => {
  it("25 概览数字与实际一致", async () => {
    await seed();
    await renderAt("/settings");
    await waitFor(() => expect(screen.getByTestId("stat-modules")).toHaveTextContent("1"));
    expect(screen.getByTestId("stat-records")).toHaveTextContent("1");
    expect(screen.getByTestId("stat-chars")).toHaveTextContent("1");
  });

  it("26 导出备份文件名形如 coc-backup-YYYYMMDD-HHmm.json", () => {
    const name = backupFileName(new Date(2026, 2, 8, 9, 5));
    expect(name).toBe("coc-backup-20260308-0905.json");
  });

  it("26 点导出后归档目录出现备份文件", async () => {
    const written: string[] = [];
    __setArchiveWriter(async (_m, fileName) => {
      written.push(fileName);
    });
    await renderAt("/settings");
    await userEvent.click(screen.getByTestId("export-backup"));
    await waitFor(() => expect(written.length).toBe(1));
    expect(written[0]).toMatch(/^coc-backup-\d{8}-\d{4}\.json$/);
  });

  it("27 备份 → 清空 → 恢复，模组 / 记录 / 角色卡全部回来", async () => {
    await seed();
    const backup = await buildBackup();
    await clearAll();
    expect(await listModules()).toHaveLength(0);
    const res = await restoreBackup(JSON.stringify(backup));
    expect(res.ok).toBe(true);
    expect(await listModules()).toHaveLength(1);
    expect((await listRecords()).length).toBe(1);
    expect((await useCharacters.getState().characters).length).toBe(1);
  });

  it("27 版本不匹配的备份被拒绝", async () => {
    const res = await restoreBackup(JSON.stringify({ schemaVersion: 999, modules: [], records: [], characters: [] }));
    expect(res.ok).toBe(false);
  });

  it("29 保留份数裁剪：生成 11 份后最旧那份被自动删除", async () => {
    // 模拟历史
    const { listBackupMeta, putBackupMeta, deleteBackupMeta } = await import("../lib/db");
    for (let i = 0; i < 11; i++) {
      await putBackupMeta({ id: `bk-${i}`, file: `f${i}.json`, at: 1000 + i });
    }
    const history = await listBackupMeta();
    const kept = pruneHistory(history, 10);
    for (const r of history.filter((h) => !kept.includes(h))) await deleteBackupMeta(r.id);
    const after = await listBackupMeta();
    expect(after.length).toBe(10);
    expect(after[0].id).toBe("bk-1"); // 最旧的 bk-0 被删
  });

  it("28 自动备份：开启后运行一次会写入备份", async () => {
    await seed();
    const written: string[] = [];
    __setArchiveWriter(async (_m, fileName) => {
      written.push(fileName);
    });
    const name = await runAutoBackup();
    expect(name).toMatch(/^coc-backup-\d{8}-\d{4}\.json$/);
    expect(written[0]).toBe(name);
  });

  it("30 切换浅 / 深色后刷新保持上次选择", async () => {
    await renderAt("/records");
    await userEvent.click(screen.getByTestId("theme-toggle"));
    await waitFor(() => expect(document.documentElement.dataset.theme).toBe("dark"));
    await renderAt("/settings");
    expect(document.documentElement.dataset.theme).toBe("dark");
  });

  it("31 更改下载归档位置后设置被保存", async () => {
    await renderAt("/settings");
    const input = screen.getByTestId("download-dir") as HTMLInputElement;
    fireEvent.change(input, { target: { value: "我的COC存档" } });
    const { getSettings } = await import("../lib/db");
    await waitFor(async () => {
      expect((await getSettings()).downloadDir).toBe("我的COC存档");
    });
  });

  it("32 清空全部数据有二次确认，确认后概览归零", async () => {
    await seed();
    await renderAt("/settings");
    await waitFor(() => expect(screen.getByTestId("stat-modules")).toHaveTextContent("1"));
    await userEvent.click(screen.getByTestId("clear-open"));
    expect(screen.getByTestId("confirm-dialog")).toBeTruthy();
    await userEvent.click(screen.getByTestId("confirm-ok"));
    await waitFor(() => expect(screen.getByTestId("stat-modules")).toHaveTextContent("0"));
    expect(await listModules()).toHaveLength(0);
  });
});
