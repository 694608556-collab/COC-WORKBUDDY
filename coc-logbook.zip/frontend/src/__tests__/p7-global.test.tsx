import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { render, screen, waitFor, cleanup, within } from "@testing-library/react";
import { readFileSync } from "fs";
import App from "../App";
import { __resetDBForTest, clearAll } from "../lib/db";
import { useData } from "../store/useData";

async function renderAt(path: string) {
  window.history.pushState({}, "", path);
  render(<App />);
  await waitFor(() =>
    expect(screen.getByTestId("app-shell")).toHaveAttribute("data-ready", "1"),
  );
}

const PAGES = [
  { path: "/records", title: "跑团记录汇总" },
  { path: "/characters", title: "调查员角色卡" },
  { path: "/settings", title: "数据与设置" },
];

beforeEach(async () => {
  cleanup();
  __resetDBForTest();
  await clearAll();
  useData.setState({ modules: [], records: [], loaded: false });
});

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("P7 · #33 三个模块标题栏都有应用名 + 三个圆点控件", () => {
  for (const p of PAGES) {
    it(`${p.title}：标题栏含应用名与三个窗口圆点`, async () => {
      await renderAt(p.path);
      const brand = screen.getByTestId("brand");
      expect(brand.textContent).toContain("COC 跑团记录簿");
      // 标题栏三个圆点（最小 / 最大 / 关闭）
      expect(screen.getByTestId("wb-min")).toBeTruthy();
      expect(screen.getByTestId("wb-max")).toBeTruthy();
      expect(screen.getByTestId("wb-close")).toBeTruthy();
      // 模块标题存在
      const top = screen.getByTestId("module-top");
      expect(within(top).getByText(p.title)).toBeTruthy();
    });
  }
});

describe("P7 · #34 侧边导航当前模块前有高亮圆点", () => {
  it("进入某模块时，只有该模块导航项处于激活态", async () => {
    await renderAt("/characters");
    expect(screen.getByTestId("nav-characters").className).toContain("on");
    expect(screen.getByTestId("nav-records").className).not.toContain("on");
    expect(screen.getByTestId("nav-settings").className).not.toContain("on");

    // 激活项的圆点 data-active 为 true，且全局仅一个激活
    const active = screen.getByTestId("nav-characters");
    const dot = active.querySelector(".dot");
    expect(dot?.getAttribute("data-active")).toBe("true");
    expect(document.querySelectorAll(".nav.on").length).toBe(1);
  });
});

describe("P7 · #35 所有表单控件字体统一", () => {
  it("设计令牌定义了统一字体栈，且表单控件强制继承", () => {
    const tokens = readFileSync("src/styles/tokens.css", "utf8");
    const app = readFileSync("src/styles/app.css", "utf8");
    expect(tokens).toMatch(/--ui-font\s*:/);
    // 按钮 / 输入框 / 下拉 / 文本域 / 标签 统一继承字体栈
    expect(app).toMatch(
      /button,\s*input,\s*select,\s*textarea,\s*label\s*\{[^}]*font-family:\s*inherit/,
    );
    // 根节点把字体栈挂到 --ui-font 上
    expect(tokens).toMatch(/--ui-font:\s*-apple-system/);
  });
});

describe("P7 · #36 浅色版文字与背景对比清晰", () => {
  it("默认主题为浅色，且浅色令牌里文字深、背景浅", async () => {
    await renderAt("/records");
    // 默认浅色
    expect(document.documentElement.dataset.theme).toBe("light");

    const tokens = readFileSync("src/styles/tokens.css", "utf8");
    const lightBlock = tokens.match(/:root\[data-theme="light"\]\s*\{([^}]*)\}/);
    expect(lightBlock).toBeTruthy();
    const text = lightBlock![1].match(/--text:\s*(#[0-9a-fA-F]+)/);
    const bg = lightBlock![1].match(/--bg:\s*(#[0-9a-fA-F]+)/);
    expect(text).toBeTruthy();
    expect(bg).toBeTruthy();
    // 文字为深色（#1 开头），背景为浅色（#e 开头），形成清晰对比
    expect(text![1].toLowerCase().startsWith("#1")).toBe(true);
    expect(bg![1].toLowerCase().startsWith("#e")).toBe(true);
  });
});

describe("P7 · #37 全程不出现登录页，断网也能打开使用", () => {
  it("每个模块都不含登录 / 账号输入框", async () => {
    for (const p of PAGES) {
      await renderAt(p.path);
      expect(screen.queryByText(/登录|注册账号|输入账号/)).toBeNull();
      expect(document.querySelector('input[type="password"]')).toBeNull();
      expect(screen.getByTestId("module-top")).toBeTruthy();
      cleanup();
    }
  });

  it("断网时模块一仍可正常展示（除检测 / 下载外）", async () => {
    // 不注入任何 fetch，模拟断网；展示层不应崩溃
    await renderAt("/records");
    expect(screen.getByTestId("module-top")).toBeTruthy();
    // 空状态引导文案可见
    expect(screen.getByTestId("records-empty")).toBeTruthy();
  });
});
