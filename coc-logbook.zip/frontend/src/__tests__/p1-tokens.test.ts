import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const tokens = readFileSync("src/styles/tokens.css", "utf8");
const app = readFileSync("src/styles/app.css", "utf8");

/** 取出某个选择器块内的文本 */
function block(css: string, selector: string): string {
  const i = css.indexOf(selector);
  if (i < 0) throw new Error(`找不到选择器 ${selector}`);
  const start = css.indexOf("{", i);
  let depth = 0;
  for (let j = start; j < css.length; j++) {
    if (css[j] === "{") depth++;
    if (css[j] === "}") {
      depth--;
      if (depth === 0) return css.slice(start + 1, j);
    }
  }
  throw new Error("CSS 括号不匹配");
}

function valueOf(css: string, selector: string, name: string): string {
  const b = block(css, selector);
  const m = b.match(new RegExp(`${name}\\s*:\\s*([^;]+);`));
  if (!m) throw new Error(`${selector} 里没有 ${name}`);
  return m[1].trim();
}

const LIGHT = ':root[data-theme="light"]';
const DARK = ':root[data-theme="dark"]';

describe("P1 设计令牌", () => {
  it("字体栈为 SF Pro / 苹方", () => {
    const font = valueOf(tokens, ":root", "--ui-font");
    expect(font).toContain("SF Pro Text");
    expect(font).toContain("PingFang SC");
  });

  it("关键尺寸：标题栏 46px、侧栏 184px、模块顶栏 54 / 72 / 72", () => {
    expect(valueOf(tokens, ":root", "--winbar-h")).toBe("46px");
    expect(valueOf(tokens, ":root", "--side-w")).toBe("184px");
    expect(valueOf(tokens, ":root", "--top-h-m1")).toBe("54px");
    expect(valueOf(tokens, ":root", "--top-h-m2")).toBe("72px");
    expect(valueOf(tokens, ":root", "--top-h-m3")).toBe("72px");
  });

  it("浅色令牌齐全且取值正确", () => {
    expect(valueOf(tokens, LIGHT, "--bg")).toBe("#e6e8ec");
    expect(valueOf(tokens, LIGHT, "--panel")).toBe("#ffffff");
    expect(valueOf(tokens, LIGHT, "--panel2")).toBe("#eef0f4");
    expect(valueOf(tokens, LIGHT, "--line")).toBe("#d3d7de");
    expect(valueOf(tokens, LIGHT, "--text")).toBe("#14161a");
    expect(valueOf(tokens, LIGHT, "--muted")).toBe("#545b66");
    expect(valueOf(tokens, LIGHT, "--accent")).toBe("#6d45f5");
    expect(valueOf(tokens, LIGHT, "--ok")).toBe("#1a7f37");
    expect(valueOf(tokens, LIGHT, "--bad")).toBe("#cf222e");
    expect(valueOf(tokens, LIGHT, "--warn")).toBe("#9a6700");
  });

  it("深色令牌齐全且取值正确", () => {
    expect(valueOf(tokens, DARK, "--bg")).toBe("#0f1115");
    expect(valueOf(tokens, DARK, "--panel")).toBe("#171a21");
    expect(valueOf(tokens, DARK, "--panel2")).toBe("#1f2330");
    expect(valueOf(tokens, DARK, "--line")).toBe("#2a2f3a");
    expect(valueOf(tokens, DARK, "--text")).toBe("#e6e8ec");
    expect(valueOf(tokens, DARK, "--muted")).toBe("#9aa3b2");
    expect(valueOf(tokens, DARK, "--accent")).toBe("#7c5cff");
    expect(valueOf(tokens, DARK, "--ok")).toBe("#3fb950");
    expect(valueOf(tokens, DARK, "--bad")).toBe("#f85149");
    expect(valueOf(tokens, DARK, "--warn")).toBe("#d29922");
  });

  it("深色文字与背景对比度高于 4.5:1", () => {
    // 对比度粗算：相对亮度公式
    const lum = (hex: string) => {
      const v = hex.replace("#", "");
      const c = [0, 2, 4].map((i) => parseInt(v.slice(i, i + 2), 16) / 255);
      const f = c.map((x) => (x <= 0.03928 ? x / 12.92 : ((x + 0.055) / 1.055) ** 2.4));
      return 0.2126 * f[0] + 0.7152 * f[1] + 0.0722 * f[2];
    };
    const ratio = (a: string, b: string) => {
      const [l1, l2] = [lum(a), lum(b)].sort((x, y) => y - x);
      return (l1 + 0.05) / (l2 + 0.05);
    };
    expect(ratio(valueOf(tokens, DARK, "--text"), valueOf(tokens, DARK, "--bg"))).toBeGreaterThan(4.5);
    expect(ratio(valueOf(tokens, DARK, "--muted"), valueOf(tokens, DARK, "--panel"))).toBeGreaterThan(4.5);
    expect(ratio(valueOf(tokens, LIGHT, "--text"), valueOf(tokens, LIGHT, "--bg"))).toBeGreaterThan(4.5);
    expect(ratio(valueOf(tokens, LIGHT, "--muted"), valueOf(tokens, LIGHT, "--panel"))).toBeGreaterThan(4.5);
  });

  it("表单控件强制继承字体", () => {
    expect(app).toMatch(/button,\s*input,\s*select,\s*textarea,\s*label\s*\{[^}]*font-family:\s*inherit/s);
  });
});
