import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { render, screen, waitFor, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import App, { maybeAutoBackupOnStart } from "../App";
import { __resetDBForTest, clearAll, deleteHandle, listBackupMeta, saveSettings } from "../lib/db";
import { useData } from "../store/useData";
import { useSettings } from "../store/useSettings";
import { useCharacters } from "../store/useCharacters";
import { useToast } from "../store/useToast";
import {
  __resetArchiveHandles,
  __setArchiveWriter,
  ARCHIVE_KEY,
  BACKUP_KEY,
  pickDir,
  type DirHandleLike,
} from "../lib/archive";
import { runAutoBackup, shouldAutoBackup } from "../lib/backup";
import { DEFAULT_SETTINGS, DEFAULT_EXPORT_OPTIONS, type BackupTiming } from "../lib/types";

class FakeDir implements DirHandleLike {
  name: string;
  dirs = new Map<string, FakeDir>();
  files = new Map<string, Blob>();
  removed: string[] = [];
  constructor(name: string) {
    this.name = name;
  }
  async getDirectoryHandle(name: string, opts?: { create?: boolean }): Promise<DirHandleLike> {
    if (!this.dirs.has(name)) {
      if (opts?.create === false) throw new Error(`NotFoundError: ${name}`);
      this.dirs.set(name, new FakeDir(name));
    }
    return this.dirs.get(name)!;
  }
  async getFileHandle(name: string, opts?: { create?: boolean }) {
    if (!this.files.has(name)) {
      if (opts?.create === false) throw new Error(`NotFoundError: ${name}`);
      this.files.set(name, new Blob([""]));
    }
    const self = this;
    return {
      async createWritable() {
        return {
          async write(b: Blob) {
            self.files.set(name, b);
          },
          async close() {},
        };
      },
    };
  }
  async removeEntry(name: string) {
    if (!this.files.has(name)) throw new Error("not found");
    this.files.delete(name);
    this.removed.push(name);
  }
}

let root: FakeDir;
let backupRoot: FakeDir;

function installPicker() {
  (globalThis as any).showDirectoryPicker = async (opts?: { id?: string }) => {
    return (opts?.id === "coc-backup-dir" ? backupRoot : root) as unknown as DirHandleLike;
  };
}

async function renderAt(path: string) {
  window.history.pushState({}, "", path);
  render(<App />);
  await waitFor(() => expect(screen.getByTestId("app-shell")).toHaveAttribute("data-ready", "1"));
}

function setAutoBackup(patch: Partial<typeof DEFAULT_SETTINGS.autoBackup>) {
  const autoBackup = { ...DEFAULT_SETTINGS.autoBackup, ...patch };
  useSettings.setState({
    loaded: true,
    settings: {
      ...DEFAULT_SETTINGS,
      exportOptions: { ...DEFAULT_EXPORT_OPTIONS },
      autoBackup,
    },
  });
  // 写进库，保证应用启动从库里读到的也是这套设置
  return saveSettings({ autoBackup });
}

beforeEach(async () => {
  cleanup();
  __resetDBForTest();
  __resetArchiveHandles();
  await clearAll();
  await deleteHandle(ARCHIVE_KEY);
  await deleteHandle(BACKUP_KEY);
  useData.setState({ modules: [], records: [], loaded: true });
  useCharacters.setState({ characters: [], loaded: true });
  useToast.setState({ items: [] });
  __setArchiveWriter(null);
  // 备份历史不在 clearAll 范围内，测试之间手动清空
  for (const m of await listBackupMeta()) {
    const { deleteBackupMeta } = await import("../lib/db");
    await deleteBackupMeta(m.id);
  }
  root = new FakeDir("COC跑团记录");
  backupRoot = new FakeDir("我的备份");
  installPicker();
});

afterEach(() => {
  delete (globalThis as any).showDirectoryPicker;
  __setArchiveWriter(null);
});

describe("P2 · 自动备份时机判定", () => {
  it("关闭窗口时：每次都该备份", () => {
    const now = new Date(2026, 8, 11, 10, 0).getTime();
    expect(shouldAutoBackup("onClose", null, now)).toBe(true);
    expect(shouldAutoBackup("onClose", now - 1000, now)).toBe(true);
  });

  it("每天：同一天只备份一次，跨天再备份", () => {
    const d1 = new Date(2026, 8, 11, 9, 0).getTime();
    const d1later = new Date(2026, 8, 11, 22, 0).getTime();
    const d2 = new Date(2026, 8, 12, 8, 0).getTime();
    expect(shouldAutoBackup("daily", d1, d1later)).toBe(false);
    expect(shouldAutoBackup("daily", d1, d2)).toBe(true);
    expect(shouldAutoBackup("daily", null, d1)).toBe(true);
  });

  it("每周：同一周只备份一次，跨周再备份", () => {
    const mon = new Date(2026, 8, 7, 9, 0).getTime(); // 周一
    const fri = new Date(2026, 8, 11, 9, 0).getTime(); // 同一周周五
    const nextMon = new Date(2026, 8, 14, 9, 0).getTime(); // 下周一
    expect(shouldAutoBackup("weekly", mon, fri)).toBe(false);
    expect(shouldAutoBackup("weekly", mon, nextMon)).toBe(true);
    expect(shouldAutoBackup("weekly", null, mon)).toBe(true);
  });
});

describe("P2 · 自动备份落盘与裁剪", () => {
  it("28 自动备份写入「归档目录 / 自动备份」子目录", async () => {
    const name = await runAutoBackup();
    expect(name).toMatch(/^coc-backup-\d{8}-\d{4}\.json$/);
    const dir = root.dirs.get("自动备份");
    expect(dir).toBeTruthy();
    expect([...dir!.files.keys()]).toEqual([name!]);
  });

  it("29 保留份数之外的最旧备份文件被真实删除", async () => {
    await saveSettings({ autoBackup: { ...DEFAULT_SETTINGS.autoBackup, keepCount: 2 } });
    const base = new Date(2026, 8, 11, 8, 0).getTime();
    const names: (string | null)[] = [];
    for (let i = 0; i < 3; i++) names.push(await runAutoBackup(base + i * 3600_000));

    const dir = root.dirs.get("自动备份")!;
    const left = [...dir.files.keys()].sort();
    expect(left.length).toBe(2);
    expect(left).not.toContain(names[0]!);
    expect(dir.removed).toEqual([names[0]!]);
    expect(await listBackupMeta()).toHaveLength(2);
  });

  it("指定了独立备份目录时，备份写到那个目录", async () => {
    // 模拟用户已授权过独立的备份目录
    await pickDir(BACKUP_KEY);

    const name = await runAutoBackup();
    expect([...backupRoot.files.keys()]).toEqual([name!]);
    expect(root.dirs.has("自动备份")).toBe(false);
  });
});

describe("P2 · 自动备份真正自动", () => {
  it("28 启动时到了该备份的那天会自动补跑一次，同一天不重复", async () => {
    setAutoBackup({ enabled: true, timing: "daily", lastAt: null, keepCount: 10 });
    await new Promise((r) => setTimeout(r, 0));
    const now = new Date(2026, 8, 11, 10, 0).getTime();
    const first = await maybeAutoBackupOnStart(now);
    expect(first).toMatch(/^coc-backup-\d{8}-\d{4}\.json$/);
    expect(root.dirs.get("自动备份")!.files.size).toBe(1);

    const second = await maybeAutoBackupOnStart(new Date(2026, 8, 11, 23, 0).getTime());
    expect(second).toBeNull();
    expect(root.dirs.get("自动备份")!.files.size).toBe(1);

    const third = await maybeAutoBackupOnStart(new Date(2026, 8, 12, 9, 0).getTime());
    expect(third).toMatch(/^coc-backup-\d{8}-\d{4}\.json$/);
  });

  it("28 关闭窗口时自动备份一次", async () => {
    await setAutoBackup({ enabled: true, timing: "onClose", lastAt: null, keepCount: 10 });
    await renderAt("/records");
    window.dispatchEvent(new Event("beforeunload"));
    await waitFor(() => {
      expect(root.dirs.get("自动备份")?.files.size ?? 0).toBe(1);
    });
  });

  it("关闭自动备份后，关闭窗口不再写备份", async () => {
    await setAutoBackup({ enabled: false, timing: "onClose", lastAt: null });
    await renderAt("/records");
    window.dispatchEvent(new Event("beforeunload"));
    await new Promise((r) => setTimeout(r, 50));
    expect(root.dirs.has("自动备份")).toBe(false);
  });
});

describe("P2 · 设置页自动备份位置", () => {
  it("选择独立备份目录后，立即备份一次写进该目录", async () => {
    await setAutoBackup({ enabled: true, timing: "onClose", lastAt: null, keepCount: 5, dir: "" });
    await renderAt("/settings");
    await userEvent.click(screen.getByTestId("autobackup-dir-pick"));
    await waitFor(() => expect(screen.getByText(/已设置备份位置/)).toBeTruthy());
    expect((screen.getByTestId("autobackup-dir") as HTMLInputElement).value).toBe("我的备份");

    await userEvent.click(screen.getByTestId("autobackup-run"));
    await waitFor(() => expect(backupRoot.files.size).toBe(1));
    // 备份时间提示在写盘完成后异步刷新
    await waitFor(() => expect(screen.getByText(/上次备份：/)).toBeTruthy());
  });
});

describe("P2 · 备份时机设置项", () => {
  it("28 时机与保留份数的选择会被保存", async () => {
    const { getSettings } = await import("../lib/db");
    await renderAt("/settings");
    const sel = screen.getByTestId("autobackup-timing") as HTMLSelectElement;
    await userEvent.selectOptions(sel, "weekly");
    await waitFor(async () => {
      expect((await getSettings()).autoBackup.timing as BackupTiming).toBe("weekly");
    });
  });
});
