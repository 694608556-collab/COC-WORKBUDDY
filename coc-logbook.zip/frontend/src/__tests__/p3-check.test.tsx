import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { render, screen, waitFor, cleanup, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import App from "../App";
import { __resetDBForTest, clearAll, listRecords } from "../lib/db";
import { useData } from "../store/useData";
import { useToast } from "../store/useToast";

const realFetch = globalThis.fetch;

async function renderAt(path: string) {
  window.history.pushState({}, "", path);
  render(<App />);
  await waitFor(() =>
    expect(screen.getByTestId("app-shell")).toHaveAttribute("data-ready", "1"),
  );
}

function mockApi(handler: (path: string, body: Record<string, unknown>) => unknown) {
  globalThis.fetch = vi.fn(async (url: unknown, init?: { body?: string }) => {
    const path = String(url);
    const body = init?.body ? (JSON.parse(init.body) as Record<string, unknown>) : {};
    const out = handler(path, body);
    return {
      ok: true,
      status: 200,
      json: async () => out,
    } as unknown as Response;
  }) as unknown as typeof globalThis.fetch;
}

function mockOffline() {
  globalThis.fetch = vi.fn(async () => {
    throw new Error("Failed to fetch");
  }) as unknown as typeof globalThis.fetch;
}

async function createModule(name: string) {
  await userEvent.click(screen.getByTestId("module-new"));
  await userEvent.type(screen.getByTestId("module-name"), name);
  await userEvent.click(screen.getByTestId("module-save"));
  await waitFor(() => expect(screen.queryByTestId("module-dialog")).toBeNull());
  return useData.getState().modules[0].id;
}

async function addRecord(fill: { link?: string; name?: string; date?: string; paste?: string }) {
  const id = useData.getState().modules[0].id;
  await userEvent.click(screen.getByTestId(`add-${id}`));
  if (fill.name) await userEvent.type(screen.getByTestId("record-name"), fill.name);
  if (fill.link) await userEvent.type(screen.getByTestId("record-link"), fill.link);
  if (fill.date) await userEvent.type(screen.getByTestId("record-date"), fill.date);
  if (fill.paste) {
    await userEvent.click(screen.getByTestId("record-paste-toggle"));
    await userEvent.type(screen.getByTestId("record-paste"), fill.paste);
  }
  await userEvent.click(screen.getByTestId("record-save"));
  await waitFor(() => expect(screen.queryByTestId("record-dialog")).toBeNull());
  return (await listRecords())[0];
}

async function waitToast(text: string) {
  await waitFor(() =>
    expect(within(screen.getByTestId("toast-host")).getAllByText(text).length).toBeGreaterThan(0),
  );
}

beforeEach(async () => {
  cleanup();
  __resetDBForTest();
  await clearAll();
  useData.setState({ modules: [], records: [], loaded: false });
  useToast.setState({ items: [] });
});

afterEach(() => {
  globalThis.fetch = realFetch;
});

describe("P3 · 链接检测", () => {
  it("⑤ 有效链接：状态变「有效」，跑团日期自动填上", async () => {
    mockApi((path) => {
      if (path.includes("/seal/check")) {
        return { status: "valid", playDate: "2026-09-04", count: 180, message: null };
      }
      return {};
    });

    await renderAt("/records");
    await createModule("假面之夜");
    const rec = await addRecord({ link: "https://log.weizaima.com/?key=jmyh#201454" });

    await userEvent.click(screen.getByTestId(`check-${rec.id}`));

    await waitFor(() => expect(screen.getByTestId(`rec-status-${rec.id}`)).toHaveTextContent("有效"));
    expect(screen.getByTestId(`rec-date-${rec.id}`)).toHaveTextContent("2026-09-04");
    expect((await listRecords())[0].playDate).toBe("2026-09-04");
    expect((await listRecords())[0].status).toBe("valid");
  });

  it("⑥ 跑团日期取自记录首页第一行的时间（后端返回什么就填什么）", async () => {
    mockApi(() => ({ status: "valid", playDate: "2026-09-04", count: 180, message: null }));
    await renderAt("/records");
    await createModule("假面之夜");
    const rec = await addRecord({ link: "https://log.weizaima.com/?key=jmyh#201454" });
    await userEvent.click(screen.getByTestId(`check-${rec.id}`));
    await waitFor(() => expect(screen.getByTestId(`rec-date-${rec.id}`)).toHaveTextContent("2026-09-04"));
  });

  it("⑦ 无效链接：状态变「失效」并提示", async () => {
    mockApi(() => ({ status: "dead", playDate: null, count: 0, message: "链接无效或已失效（HTTP 404）" }));
    await renderAt("/records");
    await createModule("假面之夜");
    const rec = await addRecord({ link: "https://log.weizaima.com/?key=nope#1" });

    await userEvent.click(screen.getByTestId(`check-${rec.id}`));

    await waitFor(() => expect(screen.getByTestId(`rec-status-${rec.id}`)).toHaveTextContent("失效"));
    await waitToast("链接失效");
  });

  it("⑯ 断网时点检测给出明确提示，不白屏、状态保持不变", async () => {
    mockOffline();
    await renderAt("/records");
    await createModule("假面之夜");
    const rec = await addRecord({ link: "https://log.weizaima.com/?key=jmyh#201454" });

    await userEvent.click(screen.getByTestId(`check-${rec.id}`));

    await waitToast("暂时连不上网络");
    expect(screen.getByTestId(`rec-status-${rec.id}`)).toHaveTextContent("待检测");
    expect(screen.getByTestId("module-top")).toBeTruthy();
    expect(screen.getByTestId(`rec-row-${rec.id}`)).toBeTruthy();
    expect((await listRecords())[0].status).toBe("unknown");
  });

  it("链接格式不对时判为失效", async () => {
    mockApi(() => ({ status: "valid", playDate: "2026-09-04", count: 1, message: null }));
    await renderAt("/records");
    await createModule("假面之夜");
    const rec = await addRecord({ name: "手滑填错", link: "不是链接" });

    await userEvent.click(screen.getByTestId(`check-${rec.id}`));

    await waitFor(() => expect(screen.getByTestId(`rec-status-${rec.id}`)).toHaveTextContent("失效"));
  });

  it("手动粘贴的记录文本：检测后跑团日期被填上", async () => {
    mockApi((path) => {
      if (path.includes("/seal/parse-text")) {
        return { status: "valid", playDate: "2026-09-04", count: 3, message: null };
      }
      return {};
    });
    await renderAt("/records");
    await createModule("假面之夜");
    const rec = await addRecord({ name: "手抄的一场", paste: "2026-09-04 20:14 夏恩: 开始了" });

    await userEvent.click(screen.getByTestId(`check-${rec.id}`));

    await waitFor(() => expect(screen.getByTestId(`rec-status-${rec.id}`)).toHaveTextContent("有效"));
    expect(screen.getByTestId(`rec-date-${rec.id}`)).toHaveTextContent("2026-09-04");
  });

  it("抓不到日期时可以自己填", async () => {
    mockApi(() => ({ status: "valid", playDate: null, count: 10, message: null }));
    await renderAt("/records");
    await createModule("假面之夜");
    const rec = await addRecord({ link: "https://log.weizaima.com/?key=jmyh#201454", date: "2026-09-04" });

    expect((await listRecords())[0].playDate).toBe("2026-09-04");
    expect(screen.getByTestId(`rec-date-${rec.id}`)).toHaveTextContent("2026-09-04");

    // 检测没抓到日期时，保留手动填的
    await userEvent.click(screen.getByTestId(`check-${rec.id}`));
    await waitFor(() => expect(screen.getByTestId(`rec-status-${rec.id}`)).toHaveTextContent("有效"));
    expect(screen.getByTestId(`rec-date-${rec.id}`)).toHaveTextContent("2026-09-04");
  });

  it("检测中按钮显示进度，避免重复点击", async () => {
    const gate: { release: (() => void) | null } = { release: null };
    globalThis.fetch = vi.fn(
      () =>
        new Promise((resolve) => {
          gate.release = () =>
            resolve({
              ok: true,
              status: 200,
              json: async () => ({ status: "valid", playDate: "2026-09-04", count: 1, message: null }),
            } as unknown as Response);
        }),
    ) as unknown as typeof globalThis.fetch;

    await renderAt("/records");
    await createModule("假面之夜");
    const rec = await addRecord({ link: "https://log.weizaima.com/?key=jmyh#201454" });

    await userEvent.click(screen.getByTestId(`check-${rec.id}`));
    expect(screen.getByTestId(`check-${rec.id}`)).toHaveTextContent("检测中…");
    expect(screen.getByTestId(`check-${rec.id}`)).toBeDisabled();

    gate.release?.();
    await waitFor(() => expect(screen.getByTestId(`rec-status-${rec.id}`)).toHaveTextContent("有效"));
  });

  it("顶部总览不受检测影响", async () => {
    mockApi(() => ({ status: "valid", playDate: "2026-09-04", count: 1, message: null }));
    await renderAt("/records");
    await createModule("假面之夜");
    await addRecord({ link: "https://log.weizaima.com/?key=jmyh#201454" });
    const rec = (await listRecords())[0];
    await userEvent.click(screen.getByTestId(`check-${rec.id}`));
    await waitFor(() => expect(screen.getByTestId(`rec-status-${rec.id}`)).toHaveTextContent("有效"));
    expect(within(screen.getByTestId("module-top")).getByText(/模组 1 · 场次 1/)).toBeTruthy();
  });
});
