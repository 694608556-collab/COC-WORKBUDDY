import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { render, screen, waitFor, cleanup, act } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import App from "../App";
import { __resetDBForTest, clearAll, listRecords, saveSettings } from "../lib/db";
import { useData } from "../store/useData";
import { useSettings } from "../store/useSettings";
import { useToast } from "../store/useToast";
import { __setArchiveWriter } from "../lib/archive";
import { optionsForKind } from "../lib/export";
import { DEFAULT_EXPORT_OPTIONS } from "../lib/types";
import type { LogPayload } from "../lib/types";

const realFetch = globalThis.fetch;

async function renderAt(path: string) {
  window.history.pushState({}, "", path);
  render(<App />);
  await waitFor(() => expect(screen.getByTestId("app-shell")).toHaveAttribute("data-ready", "1"));
}

function mockExport(handler: (body: any) => { data: string; mime: string; ext: string }) {
  return vi.fn(async (_url: unknown, init?: { body?: string }) => {
    const body = init?.body ? JSON.parse(init.body) : {};
    const out = handler(body);
    return {
      ok: true,
      status: 200,
      json: async () => ({ status: "ok", ...out }),
    } as unknown as Response;
  }) as unknown as typeof globalThis.fetch;
}

function stubContent(): LogPayload {
  return {
    meta: { name: "", createdAt: "", updatedAt: "", version: 0 },
    entries: [
      { id: 1, nickname: "夏恩", account: "QQ:3593972548", time: 1788520826, message: "我们走进屋子", isDice: false, kind: "dialog", images: [] },
      { id: 2, nickname: "骰子", account: "QQ:1", time: 1788520900, message: ".r 1d100=80", isDice: true, kind: "dice", images: [] },
      { id: 3, nickname: "艾伦", account: "QQ:2", time: 1788521000, message: "[CQ:image,url=http://x/y.jpg]", isDice: false, kind: "image", images: ["http://x/y.jpg"] },
      { id: 4, nickname: "贝拉", account: "QQ:3", time: 1788521100, message: "（我去倒杯水）", isDice: false, kind: "ooc", images: [] },
    ],
  };
}

async function createModuleAndRecord() {
  await userEvent.click(screen.getByTestId("module-new"));
  await userEvent.type(screen.getByTestId("module-name"), "暗影循迹");
  await userEvent.click(screen.getByTestId("module-save"));
  await waitFor(() => expect(screen.queryByTestId("module-dialog")).toBeNull());
  const mid = useData.getState().modules[0].id;
  await userEvent.click(screen.getByTestId(`add-${mid}`));
  await userEvent.type(screen.getByTestId("record-link"), "https://log.weizaima.com/?key=jmyh#201454");
  // 手动填日期 + 内容，免去再抓取
  await userEvent.type(screen.getByTestId("record-date"), "2026-09-04");
  await userEvent.click(screen.getByTestId("record-save"));
  await waitFor(() => expect(screen.queryByTestId("record-dialog")).toBeNull());
  const rec = (await listRecords())[0];
  await act(async () => {
    await useData.getState().updateRecord(rec.id, { status: "valid", content: stubContent() });
  });
  return { mid, rid: rec.id };
}

beforeEach(async () => {
  cleanup();
  __resetDBForTest();
  await clearAll();
  await saveSettings({ exportOptions: { ...DEFAULT_EXPORT_OPTIONS } });
  useData.setState({ modules: [], records: [], loaded: false });
  useSettings.setState({ settings: { ...useSettings.getState().settings, exportOptions: { ...DEFAULT_EXPORT_OPTIONS } }, loaded: true });
  useToast.setState({ items: [] });
  __setArchiveWriter(null);
});

afterEach(() => {
  globalThis.fetch = realFetch;
});

describe("P4 · 选项预设（8 项过滤）", () => {
  it("10.1 八项名称与海豹页面一致", async () => {
    await renderAt("/records");
    await userEvent.click(screen.getByTestId("preset-open"));
    expect(screen.getByTestId("preset-panel")).toBeTruthy();
    for (const k of [
      "filterDice",
      "filterImage",
      "filterOoc",
      "filterTime",
      "hideAccount",
      "hideDate",
      "indentFirstLine",
      "darkMode",
    ]) {
      expect(screen.getByTestId(`preset-${k}`)).toBeTruthy();
    }
  });

  it("10.2 首次只有「平台账号隐藏」「年月日不展示」开启", async () => {
    await renderAt("/records");
    await userEvent.click(screen.getByTestId("preset-open"));
    expect(screen.getByTestId("preset-hideAccount")).toHaveAttribute("aria-checked", "true");
    expect(screen.getByTestId("preset-hideDate")).toHaveAttribute("aria-checked", "true");
    expect(screen.getByTestId("preset-filterDice")).toHaveAttribute("aria-checked", "false");
    expect(screen.getByTestId("preset-filterOoc")).toHaveAttribute("aria-checked", "false");
  });

  it("15 勾选状态全局记忆：重开应用仍保留", async () => {
    await renderAt("/records");
    await userEvent.click(screen.getByTestId("preset-open"));
    await userEvent.click(screen.getByTestId("preset-filterDice"));
    await userEvent.click(screen.getByTestId("preset-close"));
    expect((await saveSettings({})).exportOptions.filterDice).toBe(true);

    cleanup();
    useData.setState({ modules: [], records: [], loaded: false });
    await renderAt("/records");
    await userEvent.click(screen.getByTestId("preset-open"));
    expect(screen.getByTestId("preset-filterDice")).toHaveAttribute("aria-checked", "true");
  });

  it("10.3 恢复默认回到只有那两项开启", async () => {
    await renderAt("/records");
    await userEvent.click(screen.getByTestId("preset-open"));
    await userEvent.click(screen.getByTestId("preset-filterTime"));
    expect(screen.getByTestId("preset-filterTime")).toHaveAttribute("aria-checked", "true");
    await userEvent.click(screen.getByTestId("preset-reset"));
    expect(screen.getByTestId("preset-filterTime")).toHaveAttribute("aria-checked", "false");
    expect(screen.getByTestId("preset-hideAccount")).toHaveAttribute("aria-checked", "true");
  });
});

describe("P4 · 下载方式与文件命名", () => {
  it("optionsForKind：原始文件完全不过滤", () => {
    const o = optionsForKind("raw", DEFAULT_EXPORT_OPTIONS);
    expect(o.filterDice).toBe(false);
    expect(o.hideAccount).toBe(false);
    expect(o.hideDate).toBe(false);
  });

  it("optionsForKind：对话 doc 过滤掉骰子 / 图片 / 场外", () => {
    const o = optionsForKind("dialog", DEFAULT_EXPORT_OPTIONS);
    expect(o.filterDice).toBe(true);
    expect(o.filterImage).toBe(true);
    expect(o.filterOoc).toBe(true);
  });

  it("9 文件名格式为「年月日 + 模组名 + 场次名」", async () => {
    const written: { module: string; name: string; size: number }[] = [];
    __setArchiveWriter(async (moduleName, fileName, blob) => {
      written.push({ module: moduleName, name: fileName, size: blob.size });
    });
    let lastBody: any = null;
    globalThis.fetch = mockExport((body) => {
      lastBody = body;
      return { data: btoa("hello"), mime: "text/plain", ext: "txt" };
    });

    await renderAt("/records");
    const { rid } = await createModuleAndRecord();
    await userEvent.click(screen.getByTestId(`txt-${rid}`));

    await waitFor(() => expect(written.length).toBe(1));
    expect(written[0].name).toBe("20260904暗影循迹暗影循迹第一场.txt");
    expect(written[0].module).toBe("暗影循迹");
    expect(lastBody.options.hideAccount).toBe(true);
  });

  it("8 点「下载 ▾」可展开四项并下载 docx", async () => {
    const written: string[] = [];
    __setArchiveWriter(async (_m, fileName) => {
      written.push(fileName);
    });
    globalThis.fetch = mockExport(() => ({ data: btoa("x"), mime: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", ext: "docx" }));

    await renderAt("/records");
    const { rid } = await createModuleAndRecord();
    await userEvent.click(screen.getByTestId(`dl-${rid}`));
    expect(screen.getByTestId(`dl-menu-${rid}`)).toBeTruthy();
    await userEvent.click(screen.getByTestId(`dl-docx-${rid}`));

    await waitFor(() => expect(written[0]).toBe("20260904暗影循迹暗影循迹第一场.docx"));
  });

  it("10.4 切换过滤选项后，发给后端的 options 随之变化", async () => {
    let lastBody: any = null;
    globalThis.fetch = mockExport((body) => {
      lastBody = body;
      return { data: btoa("x"), mime: "application/pdf", ext: "pdf" };
    });
    __setArchiveWriter(async () => {});

    await renderAt("/records");
    const { rid } = await createModuleAndRecord();
    await userEvent.click(screen.getByTestId("preset-open"));
    await userEvent.click(screen.getByTestId("preset-filterDice"));
    await userEvent.click(screen.getByTestId("preset-close"));

    await userEvent.click(screen.getByTestId(`pdf-${rid}`));
    await waitFor(() => expect(lastBody).not.toBeNull());
    expect(lastBody.options.filterDice).toBe(true);
  });

  it("15.1 选项预设只影响导出正文，不影响名称 / 日期", async () => {
    const written: { name: string }[] = [];
    __setArchiveWriter(async (_m, fileName) => {
      written.push({ name: fileName });
    });
    globalThis.fetch = mockExport(() => ({ data: btoa("x"), mime: "text/plain", ext: "txt" }));
    await renderAt("/records");
    const { rid } = await createModuleAndRecord();
    await userEvent.click(screen.getByTestId(`txt-${rid}`));
    await waitFor(() => expect(written.length).toBe(1));
    expect(written[0].name).toContain("20260904");
    expect(written[0].name).toContain("暗影循迹第一场");
  });
});

describe("P4 · 批量下载", () => {
  it("10 勾选后打开面板六项可选，确认后勾选的记录各生成一份", async () => {
    const written: string[] = [];
    __setArchiveWriter(async (_m, fileName) => {
      written.push(fileName);
    });
    globalThis.fetch = mockExport(() => ({ data: btoa("x"), mime: "text/plain", ext: "txt" }));

    await renderAt("/records");
    const { mid } = await createModuleAndRecord();
    // 再加一条记录
    await userEvent.click(screen.getByTestId(`add-${mid}`));
    await userEvent.type(screen.getByTestId("record-link"), "https://log.weizaima.com/?key=b#2");
    await userEvent.type(screen.getByTestId("record-date"), "2026-09-05");
    await userEvent.click(screen.getByTestId("record-save"));
    await waitFor(() => expect(screen.queryByTestId("record-dialog")).toBeNull());
    const recs = await listRecords();
    await act(async () => {
    await useData.getState().updateRecord(recs[1].id, { status: "valid", content: stubContent() });
  });

    // 勾选本模组全部记录
    await userEvent.click(screen.getByTestId(`module-selectall-${mid}`));
    await userEvent.click(screen.getByTestId("batch-open"));
    expect(screen.getByTestId("batch-panel")).toBeTruthy();
    expect(screen.getByTestId("batch-raw")).toBeTruthy();
    expect(screen.getByTestId("batch-pdf")).toBeTruthy();
    await userEvent.click(screen.getByTestId("batch-txt"));
    await userEvent.click(screen.getByTestId("batch-run"));

    await waitFor(() => expect(written.length).toBe(2));
    expect(written.some((n) => n.includes("20260904"))).toBe(true);
    expect(written.some((n) => n.includes("20260905"))).toBe(true);
  });

  it("10.0 一条都没勾选时点批量下载，给出提示且不下载", async () => {
    const written: string[] = [];
    __setArchiveWriter(async (_m, fileName) => {
      written.push(fileName);
    });
    globalThis.fetch = mockExport(() => ({ data: btoa("x"), mime: "text/plain", ext: "txt" }));

    await renderAt("/records");
    await createModuleAndRecord();
    await userEvent.click(screen.getByTestId("batch-open"));
    await userEvent.click(screen.getByTestId("batch-txt"));
    await userEvent.click(screen.getByTestId("batch-run"));

    await waitFor(() => expect(useToast.getState().items.some((i) => i.title === "请先勾选记录")).toBe(true));
    expect(written.length).toBe(0);
  });

  it("10 只下载勾选的那一条，未勾选的不动", async () => {
    const written: string[] = [];
    __setArchiveWriter(async (_m, fileName) => {
      written.push(fileName);
    });
    globalThis.fetch = mockExport(() => ({ data: btoa("x"), mime: "text/plain", ext: "txt" }));

    await renderAt("/records");
    const { mid } = await createModuleAndRecord();
    await userEvent.click(screen.getByTestId(`add-${mid}`));
    await userEvent.type(screen.getByTestId("record-link"), "https://log.weizaima.com/?key=b#2");
    await userEvent.type(screen.getByTestId("record-date"), "2026-09-05");
    await userEvent.click(screen.getByTestId("record-save"));
    await waitFor(() => expect(screen.queryByTestId("record-dialog")).toBeNull());
    const recs = await listRecords();
    await act(async () => {
    await useData.getState().updateRecord(recs[1].id, { status: "valid", content: stubContent() });
  });

    // 只勾第二条
    await userEvent.click(screen.getByTestId(`rec-select-${recs[1].id}`));
    await userEvent.click(screen.getByTestId("batch-open"));
    await userEvent.click(screen.getByTestId("batch-txt"));
    await userEvent.click(screen.getByTestId("batch-run"));

    await waitFor(() => expect(written.length).toBe(1));
    expect(written[0]).toContain("20260905");
  });

  it("11 批量合成只合并勾选的记录，按模组 + 场次顺序", async () => {
    const written: { module: string; name: string }[] = [];
    __setArchiveWriter(async (moduleName, fileName) => {
      written.push({ module: moduleName, name: fileName });
    });
    let lastBody: any = null;
    globalThis.fetch = mockExport((body) => {
      lastBody = body;
      return { data: btoa("x"), mime: "application/pdf", ext: "pdf" };
    });

    await renderAt("/records");
    const { mid } = await createModuleAndRecord();
    await userEvent.click(screen.getByTestId(`add-${mid}`));
    await userEvent.type(screen.getByTestId("record-link"), "https://log.weizaima.com/?key=b#2");
    await userEvent.type(screen.getByTestId("record-date"), "2026-09-05");
    await userEvent.click(screen.getByTestId("record-save"));
    await waitFor(() => expect(screen.queryByTestId("record-dialog")).toBeNull());
    const recs = await listRecords();
    await act(async () => {
    await useData.getState().updateRecord(recs[1].id, { status: "valid", content: stubContent() });
  });

    // 只勾第一条
    await userEvent.click(screen.getByTestId(`rec-select-${recs[0].id}`));
    await userEvent.click(screen.getByTestId("merge-open"));
    await userEvent.click(screen.getByTestId("merge-pdf"));
    await userEvent.click(screen.getByTestId("merge-confirm"));

    await waitFor(() => expect(written.length).toBe(1));
    expect(written[0].name).toMatch(/\.pdf$/);
    // 只合并了一条：条目数为 4（一条记录的正文条目数）
    expect(lastBody.entries.length).toBe(4);
  });

  it("10.7 断网时已抓取过的记录仍能转成 PDF（本机转换）", async () => {
    const written: string[] = [];
    __setArchiveWriter(async (_m, fileName) => {
      written.push(fileName);
    });
    // 海豹抓取走外网（断网失败），本机导出接口照常可用
    globalThis.fetch = vi.fn(async (url: unknown) => {
      if (String(url).includes("/api/seal/export")) {
        return {
          ok: true,
          status: 200,
          json: async () => ({ status: "ok", data: btoa("x"), mime: "application/pdf", ext: "pdf" }),
        } as unknown as Response;
      }
      throw new Error("network down");
    }) as unknown as typeof globalThis.fetch;

    await renderAt("/records");
    const { rid } = await createModuleAndRecord();
    await userEvent.click(screen.getByTestId(`pdf-${rid}`));
    await waitFor(() => expect(written.length).toBe(1));
    expect(written[0]).toMatch(/\.pdf$/);
  });
});
