import { readFileSync } from "node:fs";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import { parseTableCsv, detectColumns } from "../lib/table";
import { parseBackupFile, backupSummary } from "../lib/backup";
import { SCHEMA_VERSION, type LogPayload } from "../lib/types";

const sample = (name: string) =>
  readFileSync(join(process.cwd(), "..", "samples", name), "utf8");

describe("P6 · 交付样例文件可被真实解析", () => {
  it("01 标准表头 CSV：六列全部被识别，正文 JSON 可还原", () => {
    const rows = parseTableCsv(sample("01-导入样例-标准表头.csv"));
    expect(rows).toHaveLength(4);

    const cols = detectColumns(rows);
    expect(cols.module).toBe("模组名");
    expect(cols.name).toBe("场次名称");
    expect(cols.date).toBe("跑团日期");
    expect(cols.status).toBe("状态");
    expect(cols.link).toBe("链接");
    expect(cols.content).toBe("内容(JSON)");

    const withContent = rows.filter((r) => r["内容(JSON)"]);
    expect(withContent).toHaveLength(2);
    const payload = JSON.parse(withContent[0]["内容(JSON)"]) as LogPayload;
    expect(payload.entries).toHaveLength(5);
    expect(payload.entries.some((e) => e.kind === "dice")).toBe(true);
  });

  it("02 外部表格 CSV：表头没有「链接」字样时，靠值扫描定位链接列", () => {
    const rows = parseTableCsv(sample("02-导入样例-外部表格自动识别链接列.csv"));
    expect(rows).toHaveLength(3);

    const cols = detectColumns(rows);
    expect(cols.module).toBe("团名");
    expect(cols.link).toBe("地址"); // 表头不含链接关键词，由值扫描得出
    for (const r of rows) {
      expect(r["地址"]).toMatch(/^https?:\/\//);
    }
  });

  it("03 备份样例：校验通过，摘要与实际内容一致", () => {
    const parsed = parseBackupFile(sample("03-恢复样例-coc-backup-20250308-1200.json"));
    expect(parsed.ok).toBe(true);
    if (!parsed.ok) return;

    expect(parsed.data.schemaVersion).toBe(SCHEMA_VERSION);
    expect(parsed.data.modules).toHaveLength(2);
    expect(parsed.data.records).toHaveLength(3);
    expect(parsed.data.characters).toHaveLength(1);

    const summary = backupSummary(parsed.data);
    expect(summary).toContain("模组 2");
    expect(summary).toContain("场次 3");
    expect(summary).toContain("角色卡 1");

    // 角色卡字段完整，恢复后能直接展示
    const card = parsed.data.characters[0];
    expect(card.basic.name).toBe("艾伦·韦斯特");
    expect(card.attrs.EDU).toBe(90);
    expect(card.items).toEqual(["笔记本", "左轮手枪", "怀表"]);
    expect(Object.values(card.background).filter(Boolean)).toHaveLength(9);
  });

  it("带正文的那条记录恢复后是「有效」，可离线转换", () => {
    const parsed = parseBackupFile(sample("03-恢复样例-coc-backup-20250308-1200.json"));
    if (!parsed.ok) throw new Error("样例备份解析失败");
    const valid = parsed.data.records.filter((r) => r.status === "valid");
    expect(valid).toHaveLength(1);
    expect(valid[0].content?.entries.length).toBeGreaterThan(0);
    expect(valid[0].playDate).toBe("2025-03-08");
  });
});
