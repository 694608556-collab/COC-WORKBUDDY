import { readFileSync } from "node:fs";
import { join } from "node:path";
import { beforeEach, describe, expect, it } from "vitest";
import { render, screen, waitFor, cleanup, fireEvent } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import App from "../App";
import { __resetDBForTest, clearAll, listCharacters, listModules } from "../lib/db";
import { useCharacters } from "../store/useCharacters";
import { useData } from "../store/useData";
import { useToast } from "../store/useToast";
import { __setArchiveWriter } from "../lib/archive";
import { buildBackup, parseBackupFile, backupSummary, restoreBackup } from "../lib/backup";
import { DEFAULT_EXPORT_OPTIONS } from "../lib/types";

async function renderAt(path: string) {
  cleanup();
  window.history.pushState({}, "", path);
  render(<App />);
  await waitFor(() => expect(screen.getByTestId("app-shell")).toHaveAttribute("data-ready", "1"));
}

async function firstModuleId() {
  return (await listModules())[0].id;
}

// 等待角色卡编辑器打开并已填入种子卡（EDU 90 → 职业点上限 360）
async function waitEditor() {
  await waitFor(() => expect(screen.getByTestId("char-editor")).toBeTruthy());
  await waitFor(() => expect(screen.getByTestId("occ-cap").textContent).toBe("360"));
}

async function seedCard(edition: 6 | 7 = 7) {
  await useData.getState().addModule({ name: "暗影循迹", kps: [], pairs: [] });
  const mid = await firstModuleId();
  await useCharacters.getState().add({
    moduleId: mid,
    edition,
    card: {
      id: "",
      moduleId: mid,
      edition,
      basic: { name: "艾伦", job: "记者", age: "29", gender: "男", birthplace: "伦敦", residence: "上海" },
      attrs: { STR: 60, CON: 70, SIZ: 65, DEX: 65, APP: 70, INT: 80, POW: 60, EDU: 90 },
      weapons: [],
      skills: [],
      items: [],
      background: {
        description: "", belief: "", importantPerson: "", significantPlace: "", treasure: "", trait: "", secret: "", wound: "", phobia: "",
      },
      story: "",
      createdAt: Date.now(),
    },
  });
  return mid;
}

beforeEach(async () => {
  cleanup();
  __resetDBForTest();
  await clearAll();
  useData.setState({ modules: [], records: [], loaded: false });
  useCharacters.setState({ characters: [], loaded: false });
  useToast.setState({ items: [] });
  __setArchiveWriter(null);
});

describe("P5 · 角色卡版本规则", () => {
  it("18 第六版幸运 = POW × 5；第七版可手动填 / 掷 3D6", async () => {
    await seedCard(7);
    await renderAt("/characters");
    await waitEditor();

    // 切到第六版：幸运为固定值 POW × 5 = 300
    await userEvent.click(screen.getByTestId("edition-switch"));
    await waitFor(() => expect(screen.getByTestId("derived-luck")).toBeTruthy());
    expect(screen.getByTestId("derived-luck").textContent).toBe("300");

    // 切回第七版：可手填
    await userEvent.click(screen.getByTestId("edition-switch"));
    const luck = screen.getByTestId("luck-input") as HTMLInputElement;
    await userEvent.clear(luck);
    await userEvent.type(luck, "45");
    await userEvent.click(screen.getByTestId("char-save"));
    await waitFor(() => expect(screen.queryByTestId("char-editor")).toBeNull());
    expect((await listCharacters())[0].luck).toBe(45);
  });

  it("18 第七版掷 3D6 得到 15–90 之间的幸运值", async () => {
    await seedCard(7);
    await renderAt("/characters");
    await waitEditor();
    await userEvent.click(screen.getByTestId("luck-roll"));
    const v = Number((screen.getByTestId("luck-input") as HTMLInputElement).value);
    expect(v).toBeGreaterThanOrEqual(15);
    expect(v).toBeLessThanOrEqual(90);
  });

  it("20 第六版与第七版都不显示成功线", async () => {
    await seedCard(7);
    await renderAt("/characters");
    await waitEditor();
    expect(screen.getByTestId("char-editor").textContent).not.toMatch(/常规|困难|极难/);
    await userEvent.click(screen.getByTestId("edition-switch"));
    expect(screen.getByTestId("char-editor").textContent).not.toMatch(/常规|困难|极难/);
  });

  it("24 技能点上限随 EDU / INT 变化，并显示伤害加值", async () => {
    await seedCard(7);
    await renderAt("/characters");
    await waitEditor();

    expect(screen.getByTestId("occ-cap").textContent).toBe("360"); // EDU 90 × 4
    expect(screen.getByTestId("int-cap").textContent).toBe("160"); // INT 80 × 2
    expect(screen.getByTestId("derived-db").textContent).toBe("+1d4"); // STR 60 + SIZ 65 = 125
    expect(screen.getByTestId("derived-hp").textContent).toBe("14"); // (CON 70 + SIZ 65)/10

    const edu = screen.getByTestId("attr-EDU");
    await userEvent.clear(edu);
    await userEvent.type(edu, "50");
    await waitFor(() => expect(screen.getByTestId("occ-cap").textContent).toBe("200"));
  });

  it("删除模组后角色卡保留，所属模组置空", async () => {
    const mid = await seedCard(7);
    await renderAt("/records");
    await waitFor(() => expect(screen.getByTestId(`gname-${mid}`)).toBeTruthy());
    await userEvent.click(screen.getByTestId(`gname-${mid}`));
    await userEvent.click(screen.getByTestId("module-delete"));
    await userEvent.click(screen.getByTestId("confirm-ok"));

    await waitFor(() => expect(useData.getState().modules).toHaveLength(0));
    const chars = await listCharacters();
    expect(chars).toHaveLength(1);
    expect(chars[0].moduleId).toBeNull();
  });
});

describe("P5 · 备份恢复确认", () => {
  it("27 恢复前显示备份摘要并二次确认，确认后数据回来", async () => {
    await seedCard(7);
    const backup = await buildBackup();
    const summary = backupSummary(backup);
    expect(summary).toContain("模组 1");
    expect(summary).toContain("角色卡 1");

    await clearAll();
    await renderAt("/settings");
    await userEvent.click(screen.getByTestId("import-open"));
    const input = screen.getByTestId("import-file");
    const file = new File([JSON.stringify(backup)], "coc-backup.json", { type: "application/json" });
    await waitFor(() => expect(input).toBeTruthy());
    fireEvent.change(input, { target: { files: [file] } });

    await waitFor(() => expect(screen.getByTestId("confirm-text").textContent).toContain("模组 1"));
    await userEvent.click(screen.getByTestId("confirm-ok"));

    await waitFor(async () => expect(await listCharacters()).toHaveLength(1));
    expect(await listModules()).toHaveLength(1);
  });

  it("版本过新的备份被拒绝并给出原因", async () => {
    const parsed = parseBackupFile(JSON.stringify({ schemaVersion: 999, modules: [], records: [], characters: [] }));
    expect(parsed.ok).toBe(false);
    if (!parsed.ok) expect(parsed.reason).toContain("版本不兼容");

    const res = await restoreBackup(JSON.stringify({ schemaVersion: 999, modules: [], records: [], characters: [] }));
    expect(res.ok).toBe(false);
    expect(res.reason).toContain("版本不兼容");
  });

  it("25 数据概览显示占用空间", async () => {
    await seedCard(7);
    await renderAt("/settings");
    await waitFor(() => expect(screen.getByTestId("stat-size").textContent).not.toBe("0 B"));
    expect(screen.getByTestId("stat-modules").textContent).toBe("1");
  });

  it("30 三处主题切换与设置持久", async () => {
    await renderAt("/settings");
    await userEvent.click(screen.getByTestId("theme-toggle-card"));
    await waitFor(() => expect(document.documentElement.dataset.theme).toBe("dark"));
    const { getSettings } = await import("../lib/db");
    await waitFor(async () => expect((await getSettings()).theme).toBe("dark"));
    expect((await getSettings()).exportOptions).toEqual(DEFAULT_EXPORT_OPTIONS);
  });
});

describe("P5 · #24.2 小卡次要文字样式一致", () => {
  const cssOf = (selector: string) => {
    const css = readFileSync(join(process.cwd(), "src/styles/app.css"), "utf8");
    const m = css.match(new RegExp(`\\.${selector}\\s*\\{([^}]*)\\}`));
    if (!m) throw new Error(`找不到 .${selector} 样式`);
    return m[1];
  };
  const valueOf = (block: string, prop: string) => {
    const m = block.match(new RegExp(`${prop}\\s*:\\s*([^;]+);`));
    return m ? m[1].trim() : "";
  };

  it("24.2 模组名与「职业 · 版本」字号、颜色一致", () => {
    const mod = cssOf("pmod");
    const meta = cssOf("pmeta");
    expect(valueOf(mod, "font-size")).toBeTruthy();
    expect(valueOf(mod, "font-size")).toBe(valueOf(meta, "font-size"));
    expect(valueOf(mod, "color")).toBe(valueOf(meta, "color"));
  });
});
