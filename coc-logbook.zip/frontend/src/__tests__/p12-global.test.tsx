import { beforeEach, describe, expect, it, vi } from "vitest";
import { render, screen, waitFor, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import App from "../App";
import { __resetDBForTest, clearAll } from "../lib/db";
import { useData } from "../store/useData";
import { useToast } from "../store/useToast";
import { readFileSync } from "node:fs";
import { join } from "node:path";

// vitest 从 frontend/ 目录启动，样式表按相对根目录读取
const appCss = readFileSync(join(process.cwd(), "src/styles/app.css"), "utf8");
const tokensCss = readFileSync(join(process.cwd(), "src/styles/tokens.css"), "utf8");

const realFetch = globalThis.fetch;

async function renderAt(path: string) {
  cleanup();
  window.history.pushState({}, "", path);
  render(<App />);
  await waitFor(() => expect(screen.getByTestId("app-shell")).toHaveAttribute("data-ready", "1"));
}

beforeEach(async () => {
  cleanup();
  __resetDBForTest();
  await clearAll();
  useData.setState({ modules: [], records: [], loaded: false });
  useToast.setState({ items: [] });
});

describe("P6 · 全局走查", () => {
  it("33 三个模块标题栏都有应用名与右侧三个圆点控件", async () => {
    for (const path of ["/records", "/characters", "/settings"]) {
      await renderAt(path);
      expect(screen.getByTestId("winbar")).toBeTruthy();
      expect(screen.getByTestId("brand").textContent).toContain("COC 跑团记录簿");
      expect(screen.getByTestId("wb-min")).toBeTruthy();
      expect(screen.getByTestId("wb-max")).toBeTruthy();
      expect(screen.getByTestId("wb-close")).toBeTruthy();
    }
  });

  it("34 侧边导航圆点跟随当前模块", async () => {
    await renderAt("/records");
    expect(screen.getByTestId("nav-records").className).toContain("on");
    expect(screen.getByTestId("nav-characters").className).not.toContain("on");
    // 圆点元素存在，不是方块
    const dot = screen.getByTestId("nav-records").querySelector("i.dot");
    expect(dot).toBeTruthy();
    expect(dot).toHaveAttribute("data-active", "true");

    await userEvent.click(screen.getByTestId("nav-characters"));
    await waitFor(() => expect(screen.getByTestId("nav-characters").className).toContain("on"));
    expect(screen.getByTestId("nav-records").className).not.toContain("on");
  });

  it("35 按钮 / 输入框 / 下拉 / 单选统一继承字体", () => {
    expect(appCss).toMatch(/button,\s*input,\s*select,\s*textarea,\s*label\s*\{[^}]*font-family:\s*inherit/);
    expect(tokensCss).toMatch(/--ui-font/);
  });

  it("36 浅色与深色令牌齐全，正文色与背景色不同", () => {
    for (const t of ["--bg", "--panel", "--panel2", "--line", "--text", "--muted", "--accent"]) {
      expect(tokensCss).toContain(t);
    }
    expect(tokensCss).toContain('[data-theme="dark"]');
  });

  it("后端未启动 / 断网时给出明确提示，页面不崩", async () => {
    await useData.getState().addModule({ name: "暗影循迹", kps: [], pairs: [] });
    const mid = useData.getState().modules[0].id;
    await useData.getState().addRecord({ moduleId: mid, name: "第一场", link: "https://log.weizaima.com/?key=a#1" });
    globalThis.fetch = vi.fn(async () => {
      throw new Error("connect ECONNREFUSED");
    }) as unknown as typeof globalThis.fetch;

    await renderAt("/records");
    const rec = useData.getState().records[0];
    await userEvent.click(screen.getByTestId(`check-${rec.id}`));

    await waitFor(() => expect(useToast.getState().items.length).toBeGreaterThan(0));
    const item = useToast.getState().items[0];
    expect(item.title).toBe("暂时连不上网络");
    expect(item.desc ?? "").toContain("已保存的数据不受影响");
    expect(screen.getByTestId("app-shell")).toBeTruthy();
  });
});
