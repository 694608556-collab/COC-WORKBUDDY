import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { render, screen, waitFor, cleanup, within, act } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import App from "../App";
import { __resetDBForTest, clearAll, listRecords, saveSettings } from "../lib/db";
import { useData } from "../store/useData";
import { useSettings } from "../store/useSettings";
import { useToast } from "../store/useToast";
import { __setArchiveWriter } from "../lib/archive";
import { DEFAULT_EXPORT_OPTIONS, type LogPayload } from "../lib/types";

const realFetch = globalThis.fetch;

async function renderAt(path: string) {
  window.history.pushState({}, "", path);
  render(<App />);
  await waitFor(() => expect(screen.getByTestId("app-shell")).toHaveAttribute("data-ready", "1"));
}

function payload(): LogPayload {
  return {
    meta: { name: "", createdAt: "", updatedAt: "", version: 0 },
    entries: [
      { id: 1, nickname: "夏恩", account: "QQ:1", time: 1788520826, message: "我们走进屋子", isDice: false, kind: "dialog", images: [] },
    ],
  };
}

beforeEach(async () => {
  cleanup();
  __resetDBForTest();
  await clearAll();
  await saveSettings({ exportOptions: { ...DEFAULT_EXPORT_OPTIONS } });
  useData.setState({ modules: [], records: [], loaded: false });
  useSettings.setState({
    settings: { ...useSettings.getState().settings, exportOptions: { ...DEFAULT_EXPORT_OPTIONS } },
    loaded: true,
  });
  useToast.setState({ items: [] });
  __setArchiveWriter(null);
});

afterEach(() => {
  globalThis.fetch = realFetch;
  __setArchiveWriter(null);
});

describe("P4 · 模块一收尾", () => {
  it("顶部总览显示模组数与场次总数，模组行显示状态统计", async () => {
    await useData.getState().addModule({ name: "暗影循迹", kps: [], pairs: [] });
    const mid = useData.getState().modules[0].id;
    await useData.getState().addRecord({ moduleId: mid, name: "第一场", link: "https://log.weizaima.com/?key=a#1" });
    await useData.getState().addRecord({ moduleId: mid, name: "第二场", link: "https://log.weizaima.com/?key=b#2" });
    const recs = await listRecords();
    await useData.getState().updateRecord(recs[0].id, { status: "valid" });
    await useData.getState().updateRecord(recs[1].id, { status: "dead" });

    await renderAt("/records");
    await waitFor(() =>
      expect(within(screen.getByTestId("module-top")).getByText(/模组 1 · 场次 2/)).toBeTruthy(),
    );
    const sum = screen.getByTestId(`stsum-${mid}`);
    expect(sum.textContent).toContain("有效 1");
    expect(sum.textContent).toContain("失效 1");
  });

  it("参与者空行不保存：空白的 KP 行与 PC / PL 行落库时被丢弃", async () => {
    await renderAt("/records");
    await userEvent.click(screen.getByTestId("module-new"));
    await userEvent.type(screen.getByTestId("module-name"), "暗影循迹");

    // 填一对有效参与者
    await userEvent.type(screen.getByTestId("kp-input-0"), "张三");
    await userEvent.type(screen.getByTestId("pc-input-0"), "艾伦");
    await userEvent.type(screen.getByTestId("pl-input-0"), "李四");

    // 再各加一行，全部留空
    await userEvent.click(screen.getByTestId("kp-add"));
    await userEvent.click(screen.getByTestId("pair-add"));
    await userEvent.click(screen.getByTestId("module-save"));
    await waitFor(() => expect(screen.queryByTestId("module-dialog")).toBeNull());

    const saved = useData.getState().modules[0];
    expect(saved.kps).toEqual(["张三"]);
    expect(saved.pairs).toEqual([{ pc: "艾伦", pl: "李四" }]);

    // 重新打开编辑弹窗，也不该出现空行
    await userEvent.click(screen.getByTestId(`gname-${saved.id}`));
    await waitFor(() => expect(screen.getByTestId("module-dialog")).toBeTruthy());
    expect(screen.getByTestId("kp-rows").querySelectorAll("input")).toHaveLength(1);
    expect(screen.getByTestId("pair-rows").querySelectorAll("input")).toHaveLength(2);
  });

  it("16 断网点检测：给出明确提示，页面不白屏、数据还在", async () => {
    await useData.getState().addModule({ name: "暗影循迹", kps: [], pairs: [] });
    const mid = useData.getState().modules[0].id;
    await useData.getState().addRecord({ moduleId: mid, name: "第一场", link: "https://log.weizaima.com/?key=a#1" });
    globalThis.fetch = vi.fn(async () => {
      throw new Error("network down");
    }) as unknown as typeof globalThis.fetch;

    await renderAt("/records");
    const rec = (await listRecords())[0];
    await userEvent.click(screen.getByTestId(`check-${rec.id}`));

    await waitFor(() =>
      expect(useToast.getState().items.some((i) => i.title === "暂时连不上网络")).toBe(true),
    );
    // 页面照常可用
    expect(screen.getByTestId("app-shell")).toBeTruthy();
    expect(screen.getByTestId(`gname-${mid}`)).toBeTruthy();
    expect(screen.getByTestId(`rec-status-${rec.id}`).textContent).toBe("待检测");
  });

  it("手动粘贴的记录可保存并导出（无需海豹链接）", async () => {
    const written: string[] = [];
    __setArchiveWriter(async (_m, fileName) => written.push(fileName));
    globalThis.fetch = vi.fn(async (url: unknown) => {
      if (String(url).includes("/api/seal/export")) {
        return {
          ok: true,
          status: 200,
          json: async () => ({ status: "ok", data: btoa("x"), mime: "application/pdf", ext: "pdf" }),
        } as unknown as Response;
      }
      throw new Error("network down");
    }) as unknown as typeof globalThis.fetch;

    await useData.getState().addModule({ name: "暗影循迹", kps: [], pairs: [] });
    const mid = useData.getState().modules[0].id;
    await renderAt("/records");

    await userEvent.click(screen.getByTestId(`add-${mid}`));
    await userEvent.click(screen.getByTestId("record-paste-toggle"));
    await userEvent.type(screen.getByTestId("record-paste"), "2026-09-04 20:00 夏恩: 我们走进屋子");
    await userEvent.click(screen.getByTestId("record-save"));
    await waitFor(() => expect(screen.queryByTestId("record-dialog")).toBeNull());

    const rec = (await listRecords())[0];
    await act(async () => {
      await useData.getState().updateRecord(rec.id, { content: payload() });
    });
    await userEvent.click(screen.getByTestId(`pdf-${rec.id}`));
    await waitFor(() => expect(written.length).toBe(1));
    expect(written[0]).toMatch(/\.pdf$/);
  });

  it("模块一说明文案与 PRD 附录 A 一致", async () => {
    await renderAt("/records");
    const hint = screen.getByTestId("records-hint").textContent ?? "";
    expect(hint).toContain("点击模组名旁的文件夹图标可打开该模组的归档文件夹");
    expect(hint).toContain("跑团日期自动取自海豹链接记录首页第一行的时间");
    expect(hint).toContain("导出内容按「选项预设」的过滤状态");
  });
});
