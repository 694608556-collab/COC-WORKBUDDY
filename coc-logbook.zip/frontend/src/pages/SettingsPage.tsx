import { useEffect, useState } from "react";
import { ModuleTop } from "../components/layout/ModuleTop";
import { ThemeButton } from "../components/layout/ThemeButton";
import { ConfirmDialog } from "../components/ui/ConfirmDialog";
import { useSettings } from "../store/useSettings";
import { useData } from "../store/useData";
import { useCharacters } from "../store/useCharacters";
import { useToast } from "../store/useToast";
import {
  backupFileName,
  backupSummary,
  downloadBackup,
  estimateSize,
  parseBackupFile,
  restoreBackup,
  runAutoBackup,
} from "../lib/backup";
import type { BackupFile, BackupTiming } from "../lib/types";
import { __setArchiveWriter, archiveDirName, handleName, openArchiveDir, pickDir, BACKUP_KEY } from "../lib/archive";
import { FolderIcon } from "../components/ui/FolderIcon";

export default function SettingsPage() {
  const { modules, records } = useData();
  const { characters, loaded: cLoaded, load: loadC } = useCharacters();
  const settings = useSettings((s) => s.settings);
  const patch = useSettings((s) => s.patch);
  const push = useToast((s) => s.push);

  const [size, setSize] = useState(0);
  const [importOpen, setImportOpen] = useState(false);
  const [confirmClear, setConfirmClear] = useState(false);
  const [pendingRestore, setPendingRestore] = useState<BackupFile | null>(null);
  const [dirName, setDirName] = useState("");
  const [backupDirName, setBackupDirName] = useState("");

  useEffect(() => {
    void archiveDirName().then((n) => setDirName(n));
    void handleName(BACKUP_KEY).then((n) => setBackupDirName(n));
  }, []);

  useEffect(() => {
    void estimateSize().then(setSize);
    if (!cLoaded) void loadC();
  }, [cLoaded, loadC, modules, records, characters]);

  const fmtSize = (n: number) => (n < 1024 ? `${n} B` : `${(n / 1024).toFixed(1)} KB`);

  const onExport = async () => {
    const name = await downloadBackup();
    push("已导出备份", name);
  };

  const onImportFile = async (file: File) => {
    const text = await file.text();
    const parsed = parseBackupFile(text);
    if (!parsed.ok) {
      push("恢复失败", parsed.reason);
      return;
    }
    setImportOpen(false);
    setPendingRestore(parsed.data);
  };

  const doRestore = async () => {
    if (!pendingRestore) return;
    const res = await restoreBackup(JSON.stringify(pendingRestore));
    const summary = backupSummary(pendingRestore);
    setPendingRestore(null);
    if (res.ok) {
      push("恢复成功", summary);
      void useData.getState().load();
      void useCharacters.getState().load();
    } else {
      push("恢复失败", res.reason ?? "无法识别的备份文件");
    }
  };

  const onAutoBackup = async () => {
    const name = await runAutoBackup();
    await useSettings.getState().load();
    if (name) push("已自动备份", name);
  };

  const onPickBackupDir = async () => {
    const h = await pickDir(BACKUP_KEY);
    if (!h) {
      push("没能选择文件夹", "请用 Chrome / Edge 打开，才能指定备份目录");
      return;
    }
    const name = h.name ?? "自动备份";
    setBackupDirName(name);
    await patch({ autoBackup: { ...settings.autoBackup, dir: name } });
    push("已设置备份位置", `自动备份会写入「${name}」`);
  };

  const onPickArchiveDir = async () => {
    const h = await pickDir();
    if (!h) {
      push("没能选择文件夹", "请用 Chrome / Edge 打开，才能直接写入归档目录");
      return;
    }
    const name = h.name ?? "COC跑团记录";
    setDirName(name);
    await patch({ downloadDir: name });
    push("已设置归档位置", `下载与备份会写入「${name}」`);
  };

  const onOpenArchiveDir = async () => {
    const r = await openArchiveDir();
    if (r === "no-support") push("浏览器不支持跳转", "请用 Chrome / Edge 打开本应用");
    else if (r === "no-auth") push("还没设置归档位置", "点输入框右侧的文件夹图标选一次");
    else if (r === "denied") push("没有目录权限", "重新选择一次归档目录即可");
  };

  const onClear = async () => {
    const { clearAll } = await import("../lib/db");
    await clearAll();
    push("已清空全部数据");
    void useData.getState().load();
    void useCharacters.getState().load();
  };

  const onClearCaches = async () => {
    await useData.getState().clearRecordCaches();
    push("已清理记录缓存", "场次元数据、链接与日期保留");
    void useData.getState().load();
  };

  return (
    <>
      <ModuleTop
        module="m3"
        title="数据与设置"
        subtitle="全部数据仅保存在本机"
        actions={<ThemeButton />}
      />
      <div className="content">
        {/* 1. 数据概览 */}
        <div className="card" data-testid="overview">
          <div className="ch">
            <b>数据概览</b>
          </div>
          <div className="cb g4">
            <div className="stat">
              <div className="stat-n" data-testid="stat-modules">
                {modules.length}
              </div>
              <div className="stat-l">模组</div>
            </div>
            <div className="stat">
              <div className="stat-n" data-testid="stat-records">
                {records.length}
              </div>
              <div className="stat-l">场次</div>
            </div>
            <div className="stat">
              <div className="stat-n" data-testid="stat-chars">
                {characters.length}
              </div>
              <div className="stat-l">角色卡</div>
            </div>
            <div className="stat">
              <div className="stat-n" data-testid="stat-size">
                {fmtSize(size)}
              </div>
              <div className="stat-l">占用空间</div>
            </div>
          </div>
        </div>

        {/* 2. 备份与恢复 */}
        <div className="card">
          <div className="ch">
            <b>备份与恢复</b>
          </div>
          <div className="cb">
            <div className="field">
              <button className="btn" data-testid="export-backup" onClick={onExport}>
                导出备份文件
              </button>
              <span className="hint" style={{ marginTop: 6 }}>
                生成一份独立 JSON，文件名形如 {backupFileName()}
              </span>
            </div>
            <hr />
            <div className="field">
              <button className="btn" data-testid="import-open" onClick={() => setImportOpen(true)}>
                从备份恢复
              </button>
              <span className="hint" style={{ marginTop: 6 }}>
                选择之前导出的 JSON；恢复会先清空当前数据，请确认已备份。
              </span>
              {importOpen ? (
                <input
                  type="file"
                  accept=".json"
                  data-testid="import-file"
                  style={{ display: "block", marginTop: 8 }}
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) void onImportFile(f);
                  }}
                />
              ) : null}
            </div>
          </div>
        </div>

        {/* 3. 自动备份 */}
        <div className="card">
          <div className="ch">
            <b>自动备份</b>
          </div>
          <div className="cb">
            <div className="field">
              <label className="lb">自动备份</label>
              <div className="sub" style={{ marginBottom: 8 }}>
                <button
                  className={`sw${settings.autoBackup.enabled ? " on" : ""}`}
                  data-testid="autobackup-switch"
                  onClick={() => void patch({ autoBackup: { ...settings.autoBackup, enabled: !settings.autoBackup.enabled } })}
                >
                  <i />
                </button>
                <span>{settings.autoBackup.enabled ? "已开启" : "已关闭"}</span>
              </div>
              <div className="g2">
                <div className="f">
                  <label>时机</label>
                  <select
                    className="inp"
                    data-testid="autobackup-timing"
                    value={settings.autoBackup.timing}
                    onChange={(e) =>
                      void patch({
                        autoBackup: { ...settings.autoBackup, timing: e.target.value as BackupTiming },
                      })
                    }
                  >
                    <option value="onClose">关闭窗口时</option>
                    <option value="daily">每天</option>
                    <option value="weekly">每周</option>
                  </select>
                </div>
                <div className="f">
                  <label>保留份数</label>
                  <input
                    type="number"
                    className="inp"
                    data-testid="autobackup-keep"
                    value={settings.autoBackup.keepCount}
                    onChange={(e) =>
                      void patch({
                        autoBackup: { ...settings.autoBackup, keepCount: Number(e.target.value) || 1 },
                      })
                    }
                  />
                </div>
              </div>
              <div className="field" style={{ marginTop: 10 }}>
                <label className="lb">自动备份位置</label>
                <div className="inp-row">
                  <input
                    className="inp"
                    data-testid="autobackup-dir"
                    value={settings.autoBackup.dir}
                    placeholder={backupDirName || "默认：归档目录 / 自动备份"}
                    onChange={(e) =>
                      void patch({ autoBackup: { ...settings.autoBackup, dir: e.target.value } })
                    }
                  />
                  <button
                    className="ico"
                    data-testid="autobackup-dir-pick"
                    title="更改备份文件夹"
                    onClick={() => void onPickBackupDir()}
                  >
                    <FolderIcon />
                  </button>
                </div>
                <span className="hint" style={{ marginTop: 6 }}>
                  {settings.autoBackup.lastAt
                    ? `上次备份：${new Date(settings.autoBackup.lastAt).toLocaleString("zh-CN")}`
                    : "还没有自动备份过；不单独指定时，备份写入「归档目录 / 自动备份」。"}
                </span>
              </div>
              <button className="btn" data-testid="autobackup-run" style={{ marginTop: 10 }} onClick={onAutoBackup}>
                立即备份一次
              </button>
            </div>
          </div>
        </div>

        {/* 4. 界面外观 */}
        <div className="card">
          <div className="ch">
            <b>界面外观</b>
          </div>
          <div className="cb">
            <div className="field">
              <label className="lb">主题</label>
              <div style={{ marginTop: 6 }}>
                <ThemeButton testid="theme-toggle-card" />
              </div>
              <span className="hint" style={{ marginTop: 6 }}>
                只提供浅色与深色两种，选择会被记住。
              </span>
            </div>
          </div>
        </div>

        {/* 5. 下载归档位置 */}
        <div className="card">
          <div className="ch">
            <b>下载归档位置</b>
          </div>
          <div className="cb">
            <div className="field">
              <label className="lb dirlb">
                下载归档目录（文件夹名，用于本地归档）
                <button
                  className="ico"
                  data-testid="download-dir-open"
                  title="打开当前归档目录"
                  onClick={() => void onOpenArchiveDir()}
                >
                  <FolderIcon />
                </button>
              </label>
              <div className="inp-row">
                <input
                  className="inp"
                  data-testid="download-dir"
                  value={settings.downloadDir}
                  placeholder={dirName || "例：COC跑团记录"}
                  onChange={(e) => void patch({ downloadDir: e.target.value })}
                />
                <button
                  className="ico"
                  data-testid="download-dir-pick"
                  title="选择归档位置"
                  onClick={() => void onPickArchiveDir()}
                >
                  <FolderIcon />
                </button>
              </div>
              <span className="hint" style={{ marginTop: 6 }}>
                {dirName
                  ? `已授权：${dirName}。下载会写入「${dirName}/{模组名}/」，备份写入「${dirName}/自动备份/」。`
                  : "点右侧文件夹图标授权一次，之后下载与备份都会静默写入这个目录；不授权时改用浏览器下载。"}
              </span>
            </div>
          </div>
        </div>

        {/* 6. 缓存清理 */}
        <div className="card">
          <div className="ch">
            <b>缓存清理</b>
          </div>
          <div className="cb">
            <div className="field">
              <button className="btn" data-testid="clear-caches" onClick={() => void onClearCaches()}>
                清理记录缓存
              </button>
              <span className="hint" style={{ marginTop: 6 }}>
                删除已抓取的正文与图片缓存；模组、场次、链接、日期与归档文件均保留，可重新联网抓取。
              </span>
            </div>
          </div>
        </div>

        {/* 7. 清空数据 */}
        <div className="card">
          <div className="ch">
            <b>清空数据</b>
          </div>
          <div className="cb">
            <div className="field">
              <button className="danger-link" data-testid="clear-open" onClick={() => setConfirmClear(true)}>
                清空全部数据
              </button>
              <span className="hint" style={{ marginTop: 6 }}>
                清空后所有模组、记录、角色卡都会被删除，且无法恢复。操作前请先导出备份。
              </span>
            </div>
          </div>
        </div>
      </div>

      {pendingRestore ? (
        <ConfirmDialog
          open
          title="从备份恢复"
          text={`${backupSummary(pendingRestore)}。当前数据会被替换，建议先导出一份备份。确定恢复吗？`}
          onCancel={() => setPendingRestore(null)}
          onOk={() => void doRestore()}
          okText="确认恢复"
        />
      ) : null}

      <ConfirmDialog
        open={confirmClear}
        title="清空全部数据"
        text="确定清空所有模组、记录与角色卡？此操作不可恢复，建议先导出备份。"
        onCancel={() => setConfirmClear(false)}
        onOk={() => void onClear()}
        okText="确认清空"
      />
    </>
  );
}
