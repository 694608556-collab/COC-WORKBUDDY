import { useEffect, useMemo, useState } from "react";
import { ModuleTop } from "../components/layout/ModuleTop";
import { ThemeButton } from "../components/layout/ThemeButton";
import { ModuleDialog, type ModuleForm } from "../components/records/ModuleDialog";
import { AddRecordDialog, type RecordForm } from "../components/records/AddRecordDialog";
import { ModuleGroup } from "../components/records/ModuleGroup";
import { ConfirmDialog } from "../components/ui/ConfirmDialog";
import { PresetPanel } from "../components/records/PresetPanel";
import { BatchPanel } from "../components/records/BatchPanel";
import { useData, recordsOf } from "../store/useData";
import { useCharacters } from "../store/useCharacters";
import { useSettings } from "../store/useSettings";
import { useToast } from "../store/useToast";
import { defaultRecordName } from "../lib/naming";
import { downloadOne, base64ToBlob, type DownloadKind } from "../lib/export";
import { sealExport } from "../lib/api";
import { writeFile, openArchiveDir } from "../lib/archive";
import {
  downloadTableCsv,
  downloadTableXlsx,
  type ImportResult,
} from "../lib/table";
import { ExportMenu } from "../components/records/ExportMenu";
import { ImportTableDialog } from "../components/records/ImportTableDialog";
import { MergeDialog, type MergeKind } from "../components/records/MergeDialog";
import type { LogEntry, Module, RecordItem } from "../lib/types";

type ModuleDlgState = { mode: "new" | "edit"; module?: Module } | null;
type RecordDlgState = { mode: "new" | "edit"; module: Module; record?: RecordItem } | null;

export default function RecordsPage() {
  const { modules, records, loaded, load } = useData();
  const push = useToast((s) => s.push);

  const [moduleDlg, setModuleDlg] = useState<ModuleDlgState>(null);
  const [recordDlg, setRecordDlg] = useState<RecordDlgState>(null);
  const [checkingId, setCheckingId] = useState<string | null>(null);
  const [presetOpen, setPresetOpen] = useState(false);
  const [batchOpen, setBatchOpen] = useState(false);
  const [tableImportOpen, setTableImportOpen] = useState(false);
  const [mergeOpen, setMergeOpen] = useState(false);
  const [confirmDel, setConfirmDel] = useState<
    | { kind: "module"; id: string; text: string }
    | { kind: "record"; id: string; text: string }
    | null
  >(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  useEffect(() => {
    if (!loaded) void load();
  }, [loaded, load]);

  const sorted = useMemo(() => [...modules].sort((a, b) => a.order - b.order), [modules]);

  const moduleNameOf = (id: string) => modules.find((m) => m.id === id)?.name ?? "";

  const saveModule = async (form: ModuleForm) => {
    if (!moduleDlg) return;
    if (moduleDlg.mode === "new") {
      await useData.getState().addModule(form);
      push("模组已创建", form.name);
    } else if (moduleDlg.module) {
      await useData.getState().updateModule(moduleDlg.module.id, {
        name: form.name,
        kps: form.kps,
        pairs: form.pairs,
      });
      push("模组已保存", form.name);
    }
    setModuleDlg(null);
  };

  const saveRecord = async (form: RecordForm) => {
    if (!recordDlg) return;
    if (recordDlg.mode === "new") {
      const created = await useData.getState().addRecord({
        moduleId: recordDlg.module.id,
        name: form.name,
        link: form.link,
        manualText: form.manualText,
        playDate: form.playDate.trim() || null,
      });
      push("场次已新增", created.name);
    } else if (recordDlg.record) {
      await useData.getState().updateRecord(recordDlg.record.id, {
        name: form.name.trim() || recordDlg.record.name,
        link: form.link,
        manualText: form.manualText.trim() || null,
        playDate: form.playDate.trim() || null,
      });
      push("场次已保存");
    }
    setRecordDlg(null);
  };

  const runCheck = async (r: RecordItem) => {
    setCheckingId(r.id);
    try {
      const result = await useData.getState().checkRecord(r.id);
      if (result.status === "valid") {
        push("链接有效", `跑团日期 ${result.playDate ?? "未取到"}`);
      } else if (result.status === "dead") {
        push("链接失效", result.message ?? "这份日志已经打不开了");
      } else {
        push("暂时连不上网络", result.message ?? "检测没有完成，链接状态保持不变");
      }
    } finally {
      setCheckingId(null);
    }
  };

  const runDownload = async (r: RecordItem, kind: DownloadKind) => {
    if (!r.content && r.status !== "valid") {
      push("先检测一下", "下载前请先让这条记录状态变为「有效」");
      return;
    }
    const preset = useSettings.getState().settings.exportOptions;
    try {
      const fileName = await downloadOne(
        r,
        moduleNameOf(r.moduleId),
        kind,
        preset,
        (id) => useData.getState().ensureContent(id),
      );
      push("已下载并归档", fileName);
    } catch (err) {
      push("下载失败", err instanceof Error ? err.message : String(err));
    }
  };

  const openModuleDir = async (name: string) => {
    const r = await openArchiveDir(name);
    if (r === "no-support") push("浏览器不支持跳转", "请用 Chrome / Edge 打开本应用");
    else if (r === "no-auth") push("还没设置归档位置", "到设置里点文件夹图标选一次归档目录");
    else if (r === "denied") push("没有目录权限", "重新选择一次归档目录即可");
  };

  const runTxt = (r: RecordItem) => void runDownload(r, "txt");
  const runPdf = (r: RecordItem) => void runDownload(r, "pdf");

  const runBatch = async (kind: DownloadKind) => {
    const chosen = chosenRecords();
    if (!chosen.length) {
      push("请先勾选记录", "在表格里勾选要下载的记录，再点「批量下载」");
      return;
    }
    const preset = useSettings.getState().settings.exportOptions;
    let ok = 0;
    let fail = 0;
    for (const r of chosen) {
      try {
        await downloadOne(
          r,
          moduleNameOf(r.moduleId),
          kind,
          preset,
          (id) => useData.getState().ensureContent(id),
        );
        ok++;
      } catch {
        fail++;
      }
    }
    push("批量下载完成", `成功 ${ok} 份${fail ? `，失败 ${fail} 份` : ""}`);
  };

  const runExportCsv = () => {
    const { modules, records } = useData.getState();
    downloadTableCsv(modules, records);
    push("已导出表格", "coc-跑团记录表.csv");
  };

  const runExportXlsx = () => {
    const { modules, records } = useData.getState();
    downloadTableXlsx(modules, records);
    push("已导出表格", "coc-跑团记录表.xlsx");
  };

  const onImportDone = (r: ImportResult) => {
    setTableImportOpen(false);
    push(
      "导入完成",
      `新增模组 ${r.modules} · 场次 ${r.records}${r.skipped ? ` · 跳过 ${r.skipped}` : ""}`,
    );
  };

  const runMerge = async (kind: MergeKind) => {
    const chosen = chosenRecords();
    if (!chosen.length) {
      push("请先勾选记录", "在表格里勾选要合并的记录，再点「批量合成」");
      return;
    }
    setMergeOpen(false);
    const preset = useSettings.getState().settings.exportOptions;
    const entries: LogEntry[] = [];
    for (const r of chosen) {
      const c = await useData.getState().ensureContent(r.id);
      if (c) entries.push(...(c.entries as LogEntry[]));
    }
    if (!entries.length) {
      push("没有可合并的正文", "请先检测 / 抓取需要合并的记录");
      return;
    }
    try {
      const res = await sealExport(entries, kind, preset);
      if (res.status !== "ok") {
        push("合成失败", res.message ?? "生成文档出错");
        return;
      }
      const blob = base64ToBlob(res.data, res.mime);
      const fileName = `跑团记录汇总合并.${res.ext}`;
      await writeFile("跑团记录汇总", fileName, blob);
      push("已生成合并文档", fileName);
    } catch (err) {
      push("合成失败", err instanceof Error ? err.message : String(err));
    }
  };

  /** 勾选的记录，按「模组顺序 + 场次顺序」排列 */
  const chosenRecords = (): RecordItem[] => {
    const all = useData.getState().records;
    const order = new Map(sorted.map((m, i) => [m.id, i]));
    return all
      .filter((r) => selectedIds.has(r.id))
      .sort(
        (a, b) =>
          (order.get(a.moduleId) ?? 0) - (order.get(b.moduleId) ?? 0) || a.order - b.order,
      );
  };

  const toggleSelect = (id: string) =>
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });

  const selectAllInModule = (moduleId: string, checked: boolean) =>
    setSelectedIds((prev) => {
      const next = new Set(prev);
      recordsOf(records, moduleId)
        .map((r) => r.id)
        .forEach((id) => (checked ? next.add(id) : next.delete(id)));
      return next;
    });

  const moveRecord = (r: RecordItem, dir: -1 | 1) =>
    void useData.getState().moveRecord(r.moduleId, r.id, dir);

  const moveModule = (id: string, dir: -1 | 1) =>
    void useData.getState().moveModule(id, dir);

  const statusSummary = (recs: RecordItem[]): string => {
    let ok = 0;
    let no = 0;
    let wa = 0;
    for (const r of recs) {
      if (!r.link && r.manualText) wa++;
      else if (r.status === "valid") ok++;
      else if (r.status === "dead") no++;
      else wa++;
    }
    const parts: string[] = [];
    if (ok) parts.push(`有效 ${ok}`);
    if (no) parts.push(`失效 ${no}`);
    if (wa) parts.push(`待检测 ${wa}`);
    return parts.join(" · ");
  };

  const doDelete = async () => {
    if (!confirmDel) return;
    if (confirmDel.kind === "module") {
      await useData.getState().removeModule(confirmDel.id);
      await useCharacters.getState().load();
      push("模组已删除", "该模组下的场次已一并删除，角色卡保留但不再关联模组");
    } else {
      await useData.getState().removeRecord(confirmDel.id);
      push("场次已删除");
    }
    setConfirmDel(null);
  };

  return (
    <>
      <ModuleTop
        module="m1"
        title="跑团记录汇总"
        subtitle={`模组 ${modules.length} · 场次 ${records.length}`}
        actions={
          <>
            <button
              className="btn"
              data-testid="table-import-open"
              onClick={() => setTableImportOpen(true)}
            >
              导入表格
            </button>
            <ExportMenu onCsv={runExportCsv} onXlsx={runExportXlsx} />
            <button className="btn" data-testid="batch-open" onClick={() => setBatchOpen(true)}>
              批量下载
            </button>
            <button className="btn" data-testid="merge-open" onClick={() => setMergeOpen(true)}>
              批量合成
            </button>
            <button className="btn" data-testid="preset-open" onClick={() => setPresetOpen(true)}>
              选项预设
            </button>
            <ThemeButton />
            <button
              className="btn primary"
              data-testid="module-new"
              onClick={() => setModuleDlg({ mode: "new" })}
            >
              + 新建模组
            </button>
          </>
        }
      />
      <div className="content">
        {sorted.length === 0 ? (
          <div className="empty" data-testid="records-empty">
            还没有模组，点右上角「+ 新建模组」开始
          </div>
        ) : (
          sorted.map((m) => (
            <ModuleGroup
              key={m.id}
              module={m}
              records={recordsOf(records, m.id)}
              checkingId={checkingId}
              isFirst={sorted.findIndex((x) => x.id === m.id) === 0}
              isLast={sorted.findIndex((x) => x.id === m.id) === sorted.length - 1}
              selectedIds={selectedIds}
              statusSummary={statusSummary(recordsOf(records, m.id))}
              onToggle={() => void useData.getState().toggleCollapse(m.id)}
              onEditModule={() => setModuleDlg({ mode: "edit", module: m })}
              onAddRecord={() => setRecordDlg({ mode: "new", module: m })}
              onCheck={(r) => void runCheck(r)}
              onDownload={(r, k) => void runDownload(r, k)}
              onTxt={runTxt}
              onPdf={runPdf}
              onEditRecord={(r) => setRecordDlg({ mode: "edit", module: m, record: r })}
              onDeleteRecord={(r) =>
                setConfirmDel({
                  kind: "record",
                  id: r.id,
                  text: `确定删除场次「${r.name}」？删除后无法恢复。`,
                })
              }
              onFolder={(name) => void openModuleDir(name)}
              onSelectAll={(c) => selectAllInModule(m.id, c)}
              onMoveModule={(d) => moveModule(m.id, d)}
              onToggleSelect={toggleSelect}
              onMoveRecord={moveRecord}
            />
          ))
        )}

        <div className="hint" data-testid="records-hint">
          新增场次默认按「模组名 + 第几场」命名，可自行修改；点击模组名旁的文件夹图标可打开该模组的归档文件夹。
          <br />
          跑团日期自动取自海豹链接记录首页第一行的时间；状态需联网检测，检测后显示有效 / 失效。
          <br />
          下载按海豹页面提供的四种方式点选；导出内容按「选项预设」的过滤状态。
        </div>
      </div>

      {moduleDlg ? (
        <ModuleDialog
          open
          mode={moduleDlg.mode}
          initial={
            moduleDlg.module
              ? {
                  name: moduleDlg.module.name,
                  kps: moduleDlg.module.kps,
                  pairs: moduleDlg.module.pairs,
                }
              : undefined
          }
          onCancel={() => setModuleDlg(null)}
          onSave={(f) => void saveModule(f)}
          onDelete={
            moduleDlg.mode === "edit" && moduleDlg.module
              ? () => {
                  const m = moduleDlg.module!;
                  const n = recordsOf(records, m.id).length;
                  setModuleDlg(null);
                  setConfirmDel({
                    kind: "module",
                    id: m.id,
                    text: `确定删除模组「${m.name}」？该模组下的 ${n} 条场次记录会一并删除，且无法恢复。`,
                  });
                }
              : undefined
          }
        />
      ) : null}

      {recordDlg ? (
        <AddRecordDialog
          open
          mode={recordDlg.mode}
          moduleName={recordDlg.module.name}
          autoNameHint={defaultRecordName(
            recordDlg.module.name,
            recordsOf(records, recordDlg.module.id).length + 1,
          )}
          initial={
            recordDlg.record
              ? {
                  name: recordDlg.record.name,
                  link: recordDlg.record.link,
                  manualText: recordDlg.record.manualText ?? "",
                  playDate: recordDlg.record.playDate ?? "",
                }
              : undefined
          }
          onCancel={() => setRecordDlg(null)}
          onSave={(f) => void saveRecord(f)}
        />
      ) : null}

      <PresetPanel open={presetOpen} onClose={() => setPresetOpen(false)} />
      <BatchPanel
        open={batchOpen}
        count={selectedIds.size}
        onClose={() => setBatchOpen(false)}
        onRun={(k) => void runBatch(k)}
      />
      <ImportTableDialog
        open={tableImportOpen}
        onCancel={() => setTableImportOpen(false)}
        onDone={onImportDone}
      />
      <MergeDialog
        open={mergeOpen}
        count={selectedIds.size}
        onCancel={() => setMergeOpen(false)}
        onMerge={(k) => void runMerge(k)}
      />

      {confirmDel ? (
        <ConfirmDialog
          open
          title={confirmDel.kind === "module" ? "删除模组" : "删除场次"}
          text={confirmDel.text}
          onCancel={() => setConfirmDel(null)}
          onOk={() => void doDelete()}
        />
      ) : null}
    </>
  );
}
