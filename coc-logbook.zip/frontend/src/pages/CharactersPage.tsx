import { useEffect, useRef, useState } from "react";
import { ModuleTop } from "../components/layout/ModuleTop";
import { ThemeButton } from "../components/layout/ThemeButton";
import { CharacterCard } from "../components/characters/CharacterCard";
import { CharacterEditor } from "../components/characters/CharacterEditor";
import { NewCardDialog } from "../components/characters/NewCardDialog";
import { useCharacters } from "../store/useCharacters";
import { useData } from "../store/useData";
import { useToast } from "../store/useToast";
import type { Character, Edition } from "../lib/types";

export default function CharactersPage() {
  const { characters, loaded, load, add, update, remove } = useCharacters();
  const modules = useData((s) => s.modules);
  const push = useToast((s) => s.push);

  const [activeId, setActiveId] = useState<string | null>(null);
  const [editing, setEditing] = useState<Character | null>(null);
  const [newCtx, setNewCtx] = useState<{ moduleId: string | null; edition: Edition } | null>(null);
  const [newOpen, setNewOpen] = useState(false);
  const cardScrollRef = useRef<HTMLDivElement>(null);

  const scrollCards = (dir: -1 | 1) => {
    cardScrollRef.current?.scrollBy({ left: dir * 320, behavior: "smooth" });
  };

  useEffect(() => {
    if (!loaded) void load();
  }, [loaded, load]);

  // 打开模块二时，自动展开位于首位的角色卡
  const autoOpened = useRef(false);
  useEffect(() => {
    if (!loaded || autoOpened.current) return;
    autoOpened.current = true;
    if (characters.length > 0) {
      setActiveId(characters[0].id);
      setEditing(characters[0]);
    }
  }, [loaded, characters]);

  const moduleOf = (m?: string | null) =>
    typeof m === "string" ? modules.find((x) => x.id === m) : undefined;

  const openNew = (moduleId: string | null, edition: Edition) => {
    setNewCtx({ moduleId, edition });
    setNewOpen(false);
    setEditing(null);
    setActiveId(null);
  };

  const openEdit = (c: Character) => {
    setActiveId(c.id);
    setEditing(c);
  };

  const saveEditor = async (card: Character) => {
    if (editing) {
      const { id, ...patch } = card;
      await update(id, patch);
      push("角色卡已保存");
    } else if (newCtx) {
      await add({ moduleId: newCtx.moduleId, edition: newCtx.edition, card });
      push("角色卡已创建");
    }
    setEditing(null);
    setNewCtx(null);
    setActiveId(null);
  };

  return (
    <>
      <ModuleTop
        module="m2"
        title="调查员角色卡"
        subtitle={`角色 ${characters.length}`}
        actions={
          <>
            <ThemeButton />
            <button className="btn primary" data-testid="char-new" onClick={() => setNewOpen(true)}>
              + 新建角色卡
            </button>
          </>
        }
      />
      <div className="content">
        {characters.length === 0 ? (
          <div className="empty" data-testid="chars-empty">
            还没有角色卡，点右上角「+ 新建角色卡」开始
          </div>
        ) : (
          <div className="card-scroller">
            <button className="card-nav" data-testid="card-prev" title="向左" onClick={() => scrollCards(-1)}>
              ‹
            </button>
            <div className="cards" data-testid="card-list" ref={cardScrollRef}>
              {characters.map((c) => (
                <CharacterCard
                  key={c.id}
                  character={c}
                  module={moduleOf(c.moduleId)}
                  active={c.id === activeId}
                  onSelect={() => openEdit(c)}
                  onDelete={() => void remove(c.id)}
                />
              ))}
            </div>
            <button className="card-nav" data-testid="card-next" title="向右" onClick={() => scrollCards(1)}>
              ›
            </button>
          </div>
        )}
      </div>

      <NewCardDialog
        open={newOpen}
        modules={modules}
        onCancel={() => setNewOpen(false)}
        onConfirm={(moduleId, edition) => openNew(moduleId, edition)}
      />

      {(editing || newCtx) && (
        <CharacterEditor
          open
          mode={editing ? "edit" : "new"}
          modules={modules}
          initial={editing ?? undefined}
          onCancel={() => {
            setEditing(null);
            setNewCtx(null);
            setActiveId(null);
          }}
          onSave={(card) => void saveEditor(card)}
          onDelete={editing ? () => void remove(editing.id) : undefined}
        />
      )}
    </>
  );
}
