import { useEffect } from "react";
import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import { Winbar } from "./components/layout/Winbar";
import { SideNav } from "./components/layout/SideNav";
import { ToastHost } from "./components/ui/ToastHost";
import { useSettings } from "./store/useSettings";
import { runAutoBackup, shouldAutoBackup } from "./lib/backup";
import RecordsPage from "./pages/RecordsPage";
import CharactersPage from "./pages/CharactersPage";
import SettingsPage from "./pages/SettingsPage";
import NotFound from "./pages/NotFound";
import "./styles/tokens.css";
import "./styles/app.css";

/** 启动时：时机为「每天 / 每周」且到了该跑的那天就补跑一次 */
export async function maybeAutoBackupOnStart(now: number = Date.now()): Promise<string | null> {
  const s = useSettings.getState().settings;
  if (!s.autoBackup.enabled) return null;
  if (s.autoBackup.timing === "onClose") return null;
  if (!shouldAutoBackup(s.autoBackup.timing, s.autoBackup.lastAt, now)) return null;
  const name = await runAutoBackup(now);
  await useSettings.getState().load();
  return name;
}

function Shell() {
  const load = useSettings((s) => s.load);
  const loaded = useSettings((s) => s.loaded);

  useEffect(() => {
    void (async () => {
      await load();
      await maybeAutoBackupOnStart();
    })();
  }, [load]);

  // 关闭窗口时（时机选了「关闭窗口时」）跑一次自动备份
  useEffect(() => {
    const onClose = () => {
      const s = useSettings.getState().settings;
      if (s.autoBackup.enabled && s.autoBackup.timing === "onClose") {
        void runAutoBackup();
      }
    };
    window.addEventListener("beforeunload", onClose);
    return () => window.removeEventListener("beforeunload", onClose);
  }, []);

  return (
    <div className="app-shell" data-testid="app-shell" data-ready={loaded ? "1" : "0"}>
      <Winbar />
      <div className="app-body">
        <SideNav />
        <div className="main">
          <Routes>
            <Route path="/" element={<Navigate to="/records" replace />} />
            <Route path="/records" element={<RecordsPage />} />
            <Route path="/characters" element={<CharactersPage />} />
            <Route path="/settings" element={<SettingsPage />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </div>
      </div>
      <ToastHost />
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <Shell />
    </BrowserRouter>
  );
}
