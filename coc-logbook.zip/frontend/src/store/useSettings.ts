import { create } from "zustand";
import { getSettings, saveSettings } from "../lib/db";
import { DEFAULT_SETTINGS, type Settings } from "../lib/types";

type SettingsState = {
  settings: Settings;
  loaded: boolean;
  load: () => Promise<void>;
  patch: (patch: Partial<Settings>) => Promise<void>;
};

export const useSettings = create<SettingsState>((set) => ({
  settings: { ...DEFAULT_SETTINGS },
  loaded: false,
  load: async () => {
    const s = await getSettings();
    applyTheme(s.theme);
    set({ settings: s, loaded: true });
  },
  patch: async (patch) => {
    const next = await saveSettings(patch);
    if (patch.theme) applyTheme(patch.theme);
    set({ settings: next });
    return;
  },
}));

export function applyTheme(theme: Settings["theme"]) {
  if (typeof document === "undefined") return;
  document.documentElement.dataset.theme = theme;
  document.documentElement.style.colorScheme = theme;
}

/** 切换浅色 / 深色 */
export async function toggleTheme() {
  const { settings, patch } = useSettings.getState();
  await patch({ theme: settings.theme === "dark" ? "light" : "dark" });
}
