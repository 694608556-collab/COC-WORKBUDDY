import { create } from "zustand";
import { uid } from "../lib/db";

export type ToastItem = {
  id: string;
  title: string;
  desc?: string;
};

type ToastState = {
  items: ToastItem[];
  push: (title: string, desc?: string) => void;
  close: (id: string) => void;
};

export const useToast = create<ToastState>((set, get) => ({
  items: [],
  push: (title, desc) => {
    const item: ToastItem = { id: uid(), title, desc };
    set({ items: [...get().items, item] });
    setTimeout(() => {
      set({ items: get().items.filter((t) => t.id !== item.id) });
    }, 3200);
  },
  close: (id) => set({ items: get().items.filter((t) => t.id !== id) }),
}));
