import { create } from "zustand";
import {
  deleteModule as dbDeleteModule,
  deleteRecord as dbDeleteRecord,
  detachCharactersFromModule,
  listModules,
  listRecords,
  putModule,
  putRecord,
  uid,
} from "../lib/db";
import type { LogPayload, Module, RecordItem } from "../lib/types";
import { defaultRecordName, parseSealLink } from "../lib/naming";
import { ApiError, OFFLINE_MSG, parseText, sealCheck, sealFetch, type CheckResult } from "../lib/api";

type DataState = {
  modules: Module[];
  records: RecordItem[];
  loaded: boolean;
  load: () => Promise<void>;
  addModule: (input: {
    name: string;
    kps: string[];
    pairs: { pc: string; pl: string }[];
  }) => Promise<Module>;
  updateModule: (id: string, patch: Partial<Module>) => Promise<void>;
  removeModule: (id: string) => Promise<void>;
  toggleCollapse: (id: string) => Promise<void>;
  addRecord: (input: {
    moduleId: string;
    name?: string;
    link: string;
    manualText?: string;
    playDate?: string | null;
  }) => Promise<RecordItem>;
  updateRecord: (id: string, patch: Partial<RecordItem>) => Promise<void>;
  removeRecord: (id: string) => Promise<void>;
  moveModule: (id: string, dir: -1 | 1) => Promise<void>;
  moveRecord: (moduleId: string, id: string, dir: -1 | 1) => Promise<void>;
  clearRecordCaches: () => Promise<void>;
  /** 检测一条记录：有链接就查链接，没有链接就查手动粘贴的文本 */
  checkRecord: (id: string) => Promise<CheckResult>;
  /** 抓回正文并缓存，供下载 / 转换使用 */
  ensureContent: (id: string) => Promise<LogPayload | null>;
};

export const useData = create<DataState>((set, get) => ({
  modules: [],
  records: [],
  loaded: false,

  load: async () => {
    const [modules, records] = await Promise.all([listModules(), listRecords()]);
    set({ modules, records, loaded: true });
  },

  addModule: async ({ name, kps, pairs }) => {
    const modules = get().modules;
    const m: Module = {
      id: uid(),
      name: name.trim() || "未命名模组",
      kps: kps.map((k) => k.trim()).filter(Boolean),
      pairs: pairs
        .map((p) => ({ pc: p.pc.trim(), pl: p.pl.trim() }))
        .filter((p) => p.pc || p.pl),
      collapsed: false,
      createdAt: Date.now(),
      order: modules.length,
    };
    await putModule(m);
    set({ modules: [...modules, m] });
    return m;
  },

  updateModule: async (id, patch) => {
    const modules = get().modules.map((m) => (m.id === id ? { ...m, ...patch } : m));
    const target = modules.find((m) => m.id === id);
    if (target) await putModule(target);
    set({ modules });
  },

  removeModule: async (id) => {
    await dbDeleteModule(id);
    // 角色卡不跟着删，只是所属模组置空
    await detachCharactersFromModule(id);
    const [modules, records] = await Promise.all([listModules(), listRecords()]);
    set({ modules, records });
  },

  toggleCollapse: async (id) => {
    const modules = get().modules.map((m) =>
      m.id === id ? { ...m, collapsed: !m.collapsed } : m,
    );
    const target = modules.find((m) => m.id === id);
    if (target) await putModule(target);
    set({ modules });
  },

  addRecord: async ({ moduleId, name, link, manualText, playDate }) => {
    const records = get().records;
    const module = get().modules.find((m) => m.id === moduleId);
    const inModule = records.filter((r) => r.moduleId === moduleId);
    const r: RecordItem = {
      id: uid(),
      moduleId,
      name: (name ?? "").trim() || defaultRecordName(module?.name ?? "", inModule.length + 1),
      link: link.trim(),
      status: "unknown",
      playDate: (playDate ?? "").trim() || null,
      fetchedAt: null,
      content: null,
      manualText: (manualText ?? "").trim() || null,
      order: inModule.length,
    };
    await putRecord(r);
    set({ records: [...records, r] });
    return r;
  },

  updateRecord: async (id, patch) => {
    const records = get().records.map((r) => (r.id === id ? { ...r, ...patch } : r));
    const target = records.find((r) => r.id === id);
    if (target) await putRecord(target);
    set({ records });
  },

  removeRecord: async (id) => {
    await dbDeleteRecord(id);
    set({ records: await listRecords() });
  },

  moveModule: async (id, dir) => {
    const modules = [...get().modules].sort((a, b) => a.order - b.order);
    const idx = modules.findIndex((m) => m.id === id);
    const swap = idx + dir;
    if (idx < 0 || swap < 0 || swap >= modules.length) return;
    const a = modules[idx];
    const b = modules[swap];
    await putModule({ ...a, order: b.order });
    await putModule({ ...b, order: a.order });
    set({ modules: await listModules() });
  },

  moveRecord: async (moduleId, id, dir) => {
    const recs = recordsOf(get().records, moduleId);
    const idx = recs.findIndex((r) => r.id === id);
    const swap = idx + dir;
    if (idx < 0 || swap < 0 || swap >= recs.length) return;
    const a = recs[idx];
    const b = recs[swap];
    await putRecord({ ...a, order: b.order });
    await putRecord({ ...b, order: a.order });
    set({ records: await listRecords() });
  },

  clearRecordCaches: async () => {
    for (const r of get().records) {
      if (r.content) await putRecord({ ...r, content: null, fetchedAt: null });
    }
    set({ records: await listRecords() });
  },

  checkRecord: async (id) => {
    const r = get().records.find((x) => x.id === id);
    if (!r) {
      return { status: "dead", playDate: null, count: 0, message: "记录不存在" };
    }

    const parsed = r.link ? parseSealLink(r.link) : null;
    if (r.link && !parsed) {
      await get().updateRecord(id, { status: "dead" });
      return { status: "dead", playDate: r.playDate, count: 0, message: "链接格式不正确，找不到 key" };
    }

    let result: CheckResult;
    try {
      result = parsed ? await sealCheck(r.link) : await parseText(r.manualText ?? "");
    } catch (err) {
      if (err instanceof ApiError) {
        return { status: "offline", playDate: r.playDate, count: 0, message: err.message || OFFLINE_MSG };
      }
      return {
        status: "dead",
        playDate: r.playDate,
        count: 0,
        message: err instanceof Error ? err.message : "检测失败",
      };
    }

    if (result.status === "offline") {
      // 断网时保持原状态，只把原因带回去提示
      return result;
    }

    await get().updateRecord(id, {
      status: result.status === "valid" ? "valid" : "dead",
      playDate: result.playDate ?? r.playDate,
      fetchedAt: Date.now(),
    });
    return result;
  },

  ensureContent: async (id) => {
    const r = get().records.find((x) => x.id === id);
    if (!r) return null;
    if (r.content) return r.content;
    const parsed = r.link ? parseSealLink(r.link) : null;
    if (!parsed && !r.manualText) return null;
    const result = parsed ? await sealFetch(r.link) : await parseText(r.manualText ?? "");
    if (result.status !== "valid" || !result.payload) return null;
    await get().updateRecord(id, {
      content: result.payload,
      playDate: r.playDate ?? result.playDate,
      fetchedAt: Date.now(),
    });
    return result.payload;
  },
}));

/** 某模组下的记录，按 order 排序 */
export function recordsOf(records: RecordItem[], moduleId: string): RecordItem[] {
  return records.filter((r) => r.moduleId === moduleId).sort((a, b) => a.order - b.order);
}
