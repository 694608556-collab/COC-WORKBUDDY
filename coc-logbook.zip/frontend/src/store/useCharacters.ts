import { create } from "zustand";
import {
  deleteCharacter as dbDelete,
  listCharacters,
  putCharacter,
  uid,
} from "../lib/db";
import type { Character, Edition } from "../lib/types";

type State = {
  characters: Character[];
  loaded: boolean;
  load: () => Promise<void>;
  add: (input: { moduleId: string | null; edition: Edition; card: Character }) => Promise<Character>;
  update: (id: string, patch: Partial<Character>) => Promise<void>;
  remove: (id: string) => Promise<void>;
};

export const useCharacters = create<State>((set, get) => ({
  characters: [],
  loaded: false,

  load: async () => {
    set({ characters: await listCharacters(), loaded: true });
  },

  add: async ({ moduleId, edition, card }) => {
    const list = get().characters;
    const c: Character = {
      ...card,
      id: uid(),
      moduleId,
      edition,
    };
    await putCharacter(c);
    set({ characters: [...list, c] });
    return c;
  },

  update: async (id, patch) => {
    const list = get().characters.map((c) => (c.id === id ? { ...c, ...patch } : c));
    const target = list.find((c) => c.id === id);
    if (target) await putCharacter(target);
    set({ characters: list });
  },

  remove: async (id) => {
    await dbDelete(id);
    set({ characters: get().characters.filter((c) => c.id !== id) });
  },
}));
