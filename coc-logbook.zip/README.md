# COC 跑团记录簿

个人本地使用的 Call of Cthulhu 跑团辅助工具，全部数据存在**你浏览器本机**（IndexedDB），
不需要登录、不需要数据库、不上云。包含三个模块：

1. **跑团记录汇总** —— 按模组分组管理场次，抓取海豹日志、检测链接、导出 docx / TXT / PDF、表格导入导出、批量下载与批量合成。
2. **调查员角色卡** —— 导入 / 新建六版或七版角色卡，完整属性、技能、财产与装备、背景。
3. **数据与设置** —— 数据概览、备份导出 / 恢复、自动备份、浅色 / 深色切换、清空数据。

> 下载、转换、批量合成依赖本地后端把海豹日志渲染成文档（docx / pdf / txt），
> 所以本地运行时**前后端要一起启动**。

---

## 一、最快的方式（Windows）：双击 start.bat

解压后双击 **`start.bat`**（就是项目根目录里那个批处理文件），它会自己完成：

1. 检查并安装 Node.js、pnpm（只第一次需要）
2. 安装依赖（只第一次需要，可能要几分钟）
3. 启动后端(3000) 和 前端(5173)
4. 自动打开浏览器到 **http://localhost:5173**

注意：

- **那个黑色窗口要一直开着**，关掉它应用就停了；按 `Ctrl + C` 停止。
- 如果浏览器没自动弹出，手动在地址栏输入 `http://localhost:5173`。
- Windows 首次启动若弹防火墙提示，选“允许访问”（私有网络）。
- 其他系统（macOS / Linux）没有这个批处理，按下面的步骤用命令启动。

---

## 二、安装运行环境（只需一次）

只需要两样东西：**Node.js** 和 **pnpm**。不需要数据库。

### Windows

1. 安装 Node.js（自带 npm）。推荐用系统自带的 `winget`：
   ```powershell
   winget install OpenJS.NodeJS.LTS
   ```
   装完重开一个 PowerShell，验证：
   ```powershell
   node -v      # 应 >= 20
   npm -v
   ```
   也可以去 https://nodejs.org 下载 “LTS” 安装包双击安装。

2. 安装 pnpm（在 PowerShell 里）：
   ```powershell
   npm install -g pnpm
   pnpm -v
   ```

### macOS

```bash
brew install node          # 或 nvm install 20
npm install -g pnpm
```

### Linux

```bash
# 推荐用 nvm，避免系统 Node 过旧
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.1/install.sh | bash
nvm install 20
npm install -g pnpm
```

---

## 三、拿到项目代码

- 在 Genie 界面右上角选择「导出 / 下载项目」，得到一个压缩包，解压到本地文件夹
  （例如 `D:\coc-logbook`）。
- 或者在已推到代码仓库时直接 `git clone`。

解压后的 `samples` 文件夹里有 4 个现成的测试文件，可以直接用来试导入表格、
恢复备份和手动粘贴，不用自己先造数据：

| 文件 | 用来测什么 |
|---|---|
| `01-导入样例-标准表头.csv` | 模块一「导入表格」 |
| `02-导入样例-外部表格自动识别链接列.csv` | 表头没有「链接」时能否自动认出链接列 |
| `03-恢复样例-coc-backup-20250308-1200.json` | 模块三「导入备份文件」 |
| `04-手动粘贴样例-日志原文.txt` | 新增场次时的「手动粘贴」 |

---

## 四、启动（一条命令）

在项目**根目录**（包含本文件的目录）打开终端，执行：

```bash
pnpm install     # 首次会安装根 / 后端 / 前端所有依赖，稍慢
pnpm dev         # 同时启动后端(3000) 和前端(5173)
```

启动成功后，浏览器打开 **http://localhost:5173** 即可使用。

- 保持这个终端窗口开着；`Ctrl + C` 停止。
- Windows 首次启动若弹出防火墙提示，选择“允许访问”（私有网络）。
- 数据只存在你本机浏览器，清理浏览器数据或换电脑前记得在「数据与设置」里导出备份。

---

## 五、其他命令

```bash
pnpm build                   # 分别构建后端与前端到 dist/
pnpm --dir backend test      # 后端测试（Jest）
pnpm --dir frontend test     # 前端测试（Vitest）
```
