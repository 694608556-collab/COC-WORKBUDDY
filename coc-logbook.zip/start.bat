@echo off
chcp 65001 >nul
setlocal ENABLEEXTENSIONS
title COC 跑团记录簿 - 启动器

set "LOG=%~dp0install.log"
echo [%date% %time%] Script started. > "%LOG%"

cd /d "%~dp0" 2>>"%LOG%"
if errorlevel 1 (
    echo.
    echo 无法进入脚本所在目录。
    echo 请先把压缩包解压到本地磁盘（例如 D:\coc-logbook），不要直接在压缩包里双击运行。
    echo.
    pause
    exit /b 1
)
echo [%date% %time%] Working dir: %cd% >> "%LOG%"

if not exist "package.json" (
    echo.
    echo 找不到 package.json。
    echo 请确认 start.bat 和 package.json 在同一个文件夹里。
    echo 当前目录：%cd%
    echo.
    pause
    exit /b 1
)

echo ============================================
echo   COC 跑团记录簿 - 一键启动
echo ============================================
echo 日志：%LOG%
echo 目录：%cd%
echo.

rem --- 1. Node.js ---
where node >nul 2>nul
if errorlevel 1 (
    echo [1/3] 没检测到 Node.js，正在尝试安装...
    where winget >nul 2>nul
    if errorlevel 1 (
        echo.
        echo 系统里没有 winget，无法自动安装。
        echo 请手动到 https://nodejs.org 下载 LTS 版本安装，然后重新双击本脚本。
        echo.
        pause
        exit /b 1
    )
    winget install --accept-package-agreements --accept-source-agreements OpenJS.NodeJS.LTS
    echo.
    echo Node.js 安装已触发。请关闭本窗口，重新双击 start.bat 继续。
    echo.
    pause
    exit /b 1
)
for /f "tokens=*" %%v in ('node -v') do echo [1/3] Node.js 已就绪：%%v

rem --- 2. pnpm ---
where pnpm.cmd >nul 2>nul
if errorlevel 1 (
    echo [2/3] 没检测到 pnpm，正在安装...
    call npm.cmd install -g pnpm >> "%LOG%" 2>&1
    where pnpm.cmd >nul 2>nul
    if errorlevel 1 (
        echo.
        echo pnpm 安装失败。请手动执行：npm install -g pnpm
        echo 然后重新双击 start.bat。详情见 install.log
        echo.
        pause
        exit /b 1
    )
)
for /f "tokens=*" %%v in ('pnpm.cmd -v') do echo [2/3] pnpm 已就绪：%%v

rem --- 3. 放行预编译依赖（pnpm 不读上级目录配置，必须写在 frontend 目录里）---
if not exist "frontend\.npmrc" (
    echo [3/4] 正在写入依赖编译放行配置...
    >"frontend\.npmrc" echo only-built-dependencies[]=esbuild
    >>"frontend\.npmrc" echo only-built-dependencies[]=@swc/core
    >>"frontend\.npmrc" echo only-built-dependencies[]=lightningcss
    >>"frontend\.npmrc" echo only-built-dependencies[]=rollup
    >>"frontend\.npmrc" echo minimum-release-age=0
) else (
    echo [3/4] 依赖编译放行配置已存在。
)

rem --- 4. 依赖：按实际产物判断，上次装一半也能自动补全 ---
set "NEED=0"
if not exist "node_modules" set "NEED=1"
if not exist "backend\node_modules" set "NEED=1"
if not exist "frontend\node_modules" set "NEED=1"
if not exist "frontend\node_modules\.bin\vite.cmd" set "NEED=1"

if "%NEED%"=="1" (
    echo [4/4] 正在安装依赖，首次或上次未装完时需要几分钟，请耐心等待...
    call pnpm.cmd install >> "%LOG%" 2>&1
    if errorlevel 1 (
        echo.
        echo 常规安装被依赖构建策略拦下了，改用「跳过构建脚本」的方式重试。
        echo 这只是跳过依赖自带的编译步骤，不影响应用功能。
        echo.
        call pnpm.cmd install --ignore-scripts >> "%LOG%" 2>&1
        call pnpm.cmd --dir backend install --ignore-scripts >> "%LOG%" 2>&1
        call pnpm.cmd --dir frontend install --ignore-scripts >> "%LOG%" 2>&1
    )
    if not exist "frontend\node_modules" (
        echo.
        echo 依赖安装失败，详情见 install.log
        echo 也可以自己打开 PowerShell，进到本目录执行：pnpm install
        echo.
        pause
        exit /b 1
    )
    if not exist "frontend\node_modules\.bin\vite.cmd" (
        echo.
        echo 依赖装完了但没找到 vite 启动入口，可能仍有问题。详情见 install.log
        echo.
        pause
        exit /b 1
    )
) else (
    echo [4/4] 依赖已装好，跳过安装。
)

echo.
echo 正在启动，浏览器会自动打开 http://localhost:5173
echo 如果浏览器没自动弹出，手动在地址栏输入：http://localhost:5173
echo.
echo 这个黑窗口要一直开着，关掉它应用就停了。要停止请按 Ctrl+C。
echo.

start "" /b cmd /c "ping -n 8 127.0.0.1 >nul & start http://localhost:5173"

call pnpm.cmd dev
set "RC=%ERRORLEVEL%"
echo.
echo 应用已停止（退出码 %RC%）。如果上面有报错，把这段内容或 install.log 发我。
echo.
pause
