import type { LogPayload } from "./types";
import { buildPayload, decodeSealData, firstPlayDate } from "./sealParser";

export const SEAL_API = "https://dice-api.weizaima.com/dice/api/load_data";

export type SealStatus = "valid" | "dead" | "offline";

export class SealError extends Error {
  constructor(
    public status: SealStatus,
    message: string,
  ) {
    super(message);
    this.name = "SealError";
    Object.setPrototypeOf(this, SealError.prototype);
  }
}

export type SealSource = { key: string; password: string };

/** https://log.weizaima.com/?key=jmyh#201454 → { key: 'jmyh', password: '201454' } */
export function parseSealLink(link: string): SealSource | null {
  try {
    const u = new URL(link.trim());
    const key = u.searchParams.get("key") ?? "";
    if (!key) return null;
    return { key, password: u.hash.replace(/^#/, "") };
  } catch {
    return null;
  }
}

type MinimalResponse = {
  ok: boolean;
  status: number;
  json: () => Promise<unknown>;
};

export type FetchLike = (
  url: string,
  init?: { signal?: AbortSignal },
) => Promise<MinimalResponse>;

export type SealResult = {
  status: SealStatus;
  playDate: string | null;
  count: number;
  payload: LogPayload | null;
  message?: string;
};

export async function loadSealLog(
  src: SealSource,
  fetchFn?: FetchLike,
  timeoutMs = 15000,
): Promise<SealResult> {
  const doFetch: FetchLike = fetchFn ?? (globalThis.fetch as unknown as FetchLike);
  const url = `${SEAL_API}?key=${encodeURIComponent(src.key)}&password=${encodeURIComponent(
    src.password,
  )}`;

  let res: MinimalResponse;
  try {
    res = await doFetch(url, { signal: AbortSignal.timeout(timeoutMs) });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    throw new SealError("offline", `连不上海豹服务器：${msg}`);
  }

  if (!res.ok) {
    throw new SealError("dead", `链接无效或已失效（HTTP ${res.status}）`);
  }

  let raw: { data?: string; name?: string; created_at?: string; updated_at?: string };
  try {
    raw = (await res.json()) as typeof raw;
  } catch {
    throw new SealError("dead", "返回内容不是合法的日志数据");
  }

  if (!raw || typeof raw.data !== "string" || !raw.data) {
    throw new SealError("dead", "这份日志没有可用的内容");
  }

  let decoded;
  try {
    decoded = decodeSealData(raw.data);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    throw new SealError("dead", msg);
  }

  const items = decoded.items ?? [];
  const payload = buildPayload(
    decoded,
    String(raw.name ?? ""),
    String(raw.created_at ?? ""),
    String(raw.updated_at ?? ""),
  );

  return {
    status: "valid",
    playDate: firstPlayDate(items),
    count: items.length,
    payload,
  };
}
