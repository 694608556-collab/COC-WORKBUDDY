import { inflateRawSync, inflateSync } from "node:zlib";
import type {
  LogEntry,
  LogPayload,
  RawItem,
  SealDecoded,
  EntryKind,
} from "./types";

/** base64 → zlib 解出来的一段 JSON 文本 */
export function inflateBase64(b64: string): string {
  const buf = Buffer.from(b64, "base64");
  try {
    return inflateSync(buf).toString("utf8");
  } catch {
    // 少数情况下没有 zlib 头，退化为 raw deflate
    return inflateRawSync(buf).toString("utf8");
  }
}

export function decodeSealData(b64: string): SealDecoded {
  const text = inflateBase64(b64);
  const obj = JSON.parse(text) as SealDecoded;
  if (!obj || !Array.isArray(obj.items)) {
    throw new Error("日志内容格式不正确");
  }
  return obj;
}

const IMAGE_RE = /\[CQ:image[^\]]*\]/g;
const URL_RE = /url=([^,\]]+)/;

export function extractImages(message: string): string[] {
  const out: string[] = [];
  for (const m of message.match(IMAGE_RE) ?? []) {
    const u = m.match(URL_RE);
    if (u) out.push(u[1]);
  }
  return out;
}

/** 整条消息都被括号包起来，视为场外发言 */
export function isOoc(message: string): boolean {
  const t = message.trim();
  if (t.length < 2) return false;
  const open = t[0];
  const close = t[t.length - 1];
  return (
    (open === "(" && close === ")") || (open === "（" && close === "）")
  );
}

export function kindOf(item: RawItem, message: string): EntryKind {
  if (item.isDice === true) return "dice";
  if (/\[CQ:image[^\]]*\]/.test(message)) return "image";
  if (isOoc(message)) return "ooc";
  return "dialog";
}

export function toEntry(item: RawItem, index: number): LogEntry {
  const message = String(item.message ?? "");
  return {
    id: typeof item.id === "number" ? item.id : index,
    nickname: String(item.nickname ?? ""),
    account: String(item.uniformId ?? item.IMUserId ?? ""),
    time: typeof item.time === "number" ? item.time : 0,
    message,
    isDice: item.isDice === true,
    kind: kindOf(item, message),
    images: extractImages(message),
  };
}

export function itemsToEntries(items: RawItem[]): LogEntry[] {
  return items.map(toEntry);
}

/** 跑团日期 = 第一条记录的时间（东八区） */
export function toPlayDate(unixSec: number | undefined): string | null {
  if (!unixSec || !Number.isFinite(unixSec)) return null;
  const d = new Date((unixSec + 8 * 3600) * 1000);
  return d.toISOString().slice(0, 10);
}

export function firstPlayDate(items: RawItem[]): string | null {
  if (!items.length) return null;
  return toPlayDate(items[0].time);
}

export function buildPayload(decoded: SealDecoded, metaName: string, createdAt: string, updatedAt: string): LogPayload {
  const items = decoded.items ?? [];
  return {
    meta: {
      name: metaName,
      createdAt,
      updatedAt,
      version: typeof decoded.version === "number" ? decoded.version : 0,
    },
    entries: itemsToEntries(items),
  };
}

/* ---------------------- 手动粘贴的记录文本 ---------------------- */

const DATE_RE = /(\d{4})[-/年.](\d{1,2})[-/月.](\d{1,2})/;
const LINE_HEAD_RE =
  /^\[?\s*(?:(\d{4}[-/年.]\d{1,2}[-/月.]\d{1,2})日?[\sT]*(?:\d{1,2}:\d{2}(?::\d{2})?)?)\s*\]?\s*(.*)$/;
const SPEAKER_RE = /^(?:\[)?([^\]:：()]{1,24})(?:\(([^)]*)\))?[\]:：]\s*(.*)$/;

export type ManualParseResult = {
  playDate: string | null;
  entries: LogEntry[];
};

/**
 * 解析手动粘贴的记录文本：
 * - 跑团日期取文本中出现的第一个日期
 * - 每行尽量拆成「时间 / 发言者 / 内容」，拆不出来就整行当内容
 */
export function parseManualText(text: string): ManualParseResult {
  const lines = text.replace(/\r\n?/g, "\n").split("\n");
  let playDate: string | null = null;
  const entries: LogEntry[] = [];

  lines.forEach((raw, index) => {
    const line = raw.trim();
    if (!line) return;

    if (!playDate) {
      const d = line.match(DATE_RE);
      if (d) {
        playDate = `${d[1]}-${d[2].padStart(2, "0")}-${d[3].padStart(2, "0")}`;
      }
    }

    let rest = line;
    let time = 0;
    const head = line.match(LINE_HEAD_RE);
    if (head) {
      rest = head[2];
      const d = line.match(DATE_RE);
      if (d) {
        const hhmm = line.match(/(\d{1,2}):(\d{2})/);
        const t = Date.UTC(
          Number(d[1]),
          Number(d[2]) - 1,
          Number(d[3]),
          hhmm ? Number(hhmm[1]) : 0,
          hhmm ? Number(hhmm[2]) : 0,
        );
        // 东八区：UTC 时间减 8 小时存成 Unix 秒
        time = Math.floor(t / 1000) - 8 * 3600;
      }
    }

    const speaker = rest.match(SPEAKER_RE);
    let nickname = "";
    let account = "";
    let message = rest;
    if (speaker) {
      nickname = speaker[1].trim();
      account = (speaker[2] ?? "").trim();
      message = speaker[3];
    }

    entries.push({
      id: index + 1,
      nickname,
      account,
      time,
      message,
      isDice: false,
      kind: isOoc(message) ? "ooc" : "dialog",
      images: extractImages(message),
    });
  });

  return { playDate, entries };
}
