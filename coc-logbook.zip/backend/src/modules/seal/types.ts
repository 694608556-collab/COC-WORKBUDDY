export type EntryKind = "dialog" | "dice" | "ooc" | "image" | "system";

/** 与前端 lib/types.ts 中的 LogEntry 一致 */
export type LogEntry = {
  id: number;
  nickname: string;
  /** 平台账号，形如 QQ:3593972548 */
  account: string;
  /** Unix 秒 */
  time: number;
  message: string;
  isDice: boolean;
  kind: EntryKind;
  images: string[];
};

export type LogMeta = {
  name: string;
  createdAt: string;
  updatedAt: string;
  version: number;
};

export type LogPayload = {
  meta: LogMeta;
  entries: LogEntry[];
};

/** 海豹原始条目 */
export type RawItem = {
  id?: number;
  nickname?: string;
  IMUserId?: string;
  uniformId?: string;
  time?: number;
  message?: string;
  isDice?: boolean;
  commandId?: number;
  commandInfo?: unknown;
  rawMsgId?: string;
  channel?: string;
  GroupID?: string;
};

export type SealRaw = {
  client?: string;
  created_at?: string;
  updated_at?: string;
  data?: string;
  name?: string;
  note?: string;
};

export type SealDecoded = {
  version?: number;
  items?: RawItem[];
};

/** 与前端 lib/types.ts 的 ExportOptions 一致：海豹页面 8 项过滤选项 */
export type ExportOptions = {
  filterDice: boolean;
  filterImage: boolean;
  filterOoc: boolean;
  filterTime: boolean;
  hideAccount: boolean;
  hideDate: boolean;
  indentFirstLine: boolean;
  darkMode: boolean;
};

export const DEFAULT_EXPORT_OPTIONS: ExportOptions = {
  filterDice: false,
  filterImage: false,
  filterOoc: false,
  filterTime: false,
  hideAccount: true,
  hideDate: true,
  indentFirstLine: false,
  darkMode: false,
};
