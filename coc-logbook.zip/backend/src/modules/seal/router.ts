import { Router, Request, Response } from "express";
import { SealError, loadSealLog, parseSealLink, type SealSource } from "./sealClient";
import { parseManualText } from "./sealParser";
import { renderDocx, renderPdf, renderRaw, renderTxt } from "./render";
import type { ExportOptions, LogEntry } from "./types";

export const sealRouter: Router = Router();

type Body = {
  link?: unknown;
  key?: unknown;
  password?: unknown;
  text?: unknown;
};

function sourceOf(body: Body): SealSource | null {
  if (typeof body.link === "string" && body.link.trim()) {
    return parseSealLink(body.link);
  }
  const key = typeof body.key === "string" ? body.key.trim() : "";
  if (!key) return null;
  return { key, password: typeof body.password === "string" ? body.password : "" };
}

async function load(body: Body) {
  const src = sourceOf(body);
  if (!src) {
    return { http: 400, json: { status: "error", message: "链接格式不正确，找不到 key" } };
  }
  try {
    const result = await loadSealLog(src);
    return { http: 200, json: result };
  } catch (err) {
    if (err instanceof SealError) {
      return {
        http: 200,
        json: { status: err.status, playDate: null, count: 0, payload: null, message: err.message },
      };
    }
    throw err;
  }
}

/** 检测：只要状态与跑团日期，不带正文 */
sealRouter.post("/check", async (req: Request, res: Response) => {
  const out = await load(req.body as Body);
  if (out.http !== 200) {
    res.status(out.http).json(out.json);
    return;
  }
  const j = out.json as { status: string; playDate: string | null; count: number; message?: string };
  res.json({
    status: j.status,
    playDate: j.playDate,
    count: j.count,
    message: j.message ?? null,
  });
});

/** 抓取：带完整正文，用于下载与转换 */
sealRouter.post("/fetch", async (req: Request, res: Response) => {
  const out = await load(req.body as Body);
  res.status(out.http).json(out.json);
});

/** 手动粘贴的记录文本：解析跑团日期与正文 */
sealRouter.post("/parse-text", async (req: Request, res: Response) => {
  const text = (req.body as Body)?.text;
  if (typeof text !== "string" || !text.trim()) {
    res.status(400).json({ status: "error", message: "没有可解析的文本" });
    return;
  }
  const parsed = parseManualText(text);
  res.json({ status: "valid", playDate: parsed.playDate, count: parsed.entries.length, payload: { meta: { name: "", createdAt: "", updatedAt: "", version: 0 }, entries: parsed.entries } });
});

/** 导出：把结构化正文渲染成 txt / docx / pdf，以 base64 返回 */
sealRouter.post("/export", async (req: Request, res: Response) => {
  const body = req.body as {
    type?: unknown;
    entries?: unknown;
    options?: unknown;
    embedImages?: unknown;
  };
  const type = body.type;
  if (type !== "raw" && type !== "txt" && type !== "docx" && type !== "pdf") {
    res.status(400).json({ status: "error", message: "不支持的导出类型" });
    return;
  }
  if (!Array.isArray(body.entries)) {
    res.status(400).json({ status: "error", message: "没有可导出的正文" });
    return;
  }
  const entries = body.entries as LogEntry[];
  const options = (body.options ?? {}) as ExportOptions;
  const embedImages = body.embedImages === true;

  try {
    if (type === "raw") {
      // 海豹原始内容原样落盘：不过滤、不转换
      const text = renderRaw(entries);
      res.json({ status: "ok", data: Buffer.from(text, "utf8").toString("base64"), mime: "text/plain;charset=utf-8", ext: "txt" });
      return;
    }
    if (type === "txt") {
      const text = renderTxt(entries, options);
      res.json({ status: "ok", data: Buffer.from(text, "utf8").toString("base64"), mime: "text/plain;charset=utf-8", ext: "txt" });
      return;
    }
    if (type === "docx") {
      const buf = await renderDocx(entries, options, embedImages);
      res.json({ status: "ok", data: buf.toString("base64"), mime: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", ext: "docx" });
      return;
    }
    const buf = await renderPdf(entries, options);
    res.json({ status: "ok", data: buf.toString("base64"), mime: "application/pdf", ext: "pdf" });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ status: "error", message: msg });
  }
});
