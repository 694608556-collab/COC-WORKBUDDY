import { join } from "node:path";
import PDFDocument from "pdfkit";
import { Document, ImageRun, Packer, Paragraph, TextRun } from "docx";
import type { ExportOptions, LogEntry } from "./types";

// 构建期从 Noto Sans CJK TTC 提取出的单面 TTF，仅供 PDF 中文嵌入
// 后端以 backend/ 为工作目录运行时，字体位于 ./assets 下
const FONT_PATH = join(process.cwd(), "assets", "NotoSansCJK-Regular.ttf");

function pad(n: number): string {
  return String(n).padStart(2, "0");
}

/** 应用 8 项过滤选项；返回用于导出的条目（filterTime / hideAccount 只改展示，不改实体） */
export function applyFilters(entries: LogEntry[], opts: ExportOptions): LogEntry[] {
  let out = entries;
  if (opts.filterDice) out = out.filter((e) => !e.isDice);
  if (opts.filterImage) out = out.filter((e) => e.kind !== "image");
  if (opts.filterOoc) out = out.filter((e) => e.kind !== "ooc");
  return out;
}

function lineOf(e: LogEntry, opts: ExportOptions): string {
  const parts: string[] = [];
  if (!opts.hideDate) {
    const d = new Date((e.time + 8 * 3600) * 1000);
    const date = `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`;
    parts.push(date);
  }
  if (!opts.filterTime) {
    const d = new Date((e.time + 8 * 3600) * 1000);
    parts.push(`${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}`);
  }
  const who = opts.hideAccount || !e.account ? e.nickname : `${e.nickname}(${e.account})`;
  if (who) parts.push(who);
  let body = e.message.replace(/\[CQ:image[^\]]*\]/g, "[图片]");
  if (opts.indentFirstLine && parts.length) body = "　　" + body;
  parts.push(body);
  return parts.filter(Boolean).join("：");
}

export function renderTxt(entries: LogEntry[], opts: ExportOptions): string {
  return applyFilters(entries, opts)
    .map((e) => lineOf(e, opts))
    .join("\n");
}

/** 原始文件：海豹返回什么就原样落盘，不做任何过滤与转换（含时间、账号、CQ 图片码） */
export function renderRaw(entries: LogEntry[]): string {
  return entries
    .map((e) => {
      const d = new Date((e.time + 8 * 3600) * 1000);
      const stamp = `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}`;
      const who = e.account ? `${e.nickname}(${e.account})` : e.nickname;
      return `[${stamp}] ${who}: ${e.message}`;
    })
    .join("\n");
}

export async function renderDocx(
  entries: LogEntry[],
  opts: ExportOptions,
  embedImages = false,
): Promise<Buffer> {
  const list = applyFilters(entries, opts);
  const paras: Paragraph[] = [];
  for (const e of list) {
    paras.push(
      new Paragraph({
        children: [new TextRun({ text: lineOf(e, opts), font: "Noto Sans CJK SC" })],
      }),
    );
    if (embedImages && !opts.filterImage && e.images?.length) {
      const runs = await imageRuns(e.images);
      for (const run of runs) paras.push(new Paragraph({ children: [run] }));
    }
  }
  const doc = new Document({
    sections: [{ children: paras }],
  });
  return Buffer.from(await Packer.toBuffer(doc));
}

/* ------------------------------ 图片内嵌 ------------------------------ */

export type ImageFetcher = (url: string) => Promise<Buffer | null>;
let injectedFetcher: ImageFetcher | null = null;

/** 测试用：替换真实的网络抓图 */
export function __setImageFetcher(f: ImageFetcher | null) {
  injectedFetcher = f;
}

const FETCH_TIMEOUT = 5000;

async function fetchImage(url: string): Promise<Buffer | null> {
  if (injectedFetcher) return injectedFetcher(url);
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), FETCH_TIMEOUT);
    const res = await fetch(url, { signal: ctrl.signal });
    clearTimeout(timer);
    if (!res.ok) return null;
    const buf = Buffer.from(await res.arrayBuffer());
    return buf.length ? buf : null;
  } catch {
    // 防盗链 / 超时 / 断网：降级为占位文字，不中断整份文档
    return null;
  }
}

function detectType(buf: Buffer): "png" | "jpg" | "gif" | "bmp" | null {
  if (buf.length > 8 && buf[0] === 0x89 && buf[1] === 0x50) return "png";
  if (buf.length > 3 && buf[0] === 0xff && buf[1] === 0xd8) return "jpg";
  if (buf.length > 3 && buf[0] === 0x47 && buf[1] === 0x49) return "gif";
  if (buf.length > 2 && buf[0] === 0x42 && buf[1] === 0x4d) return "bmp";
  return null;
}

/** 把条目里的图片抓下来内嵌；抓不到就返回空数组，由调用方继续输出 [图片] 占位 */
export async function imageRuns(urls: string[]): Promise<ImageRun[]> {
  const runs: ImageRun[] = [];
  for (const url of urls) {
    const buf = await fetchImage(url);
    if (!buf) continue;
    const type = detectType(buf);
    if (!type) continue;
    runs.push(new ImageRun({ type, data: buf, transformation: { width: 200, height: 150 } }));
  }
  return runs;
}

export async function renderPdf(entries: LogEntry[], opts: ExportOptions): Promise<Buffer> {
  const doc = new PDFDocument({ size: "A4", margin: 48 });
  let fontReady = false;
  try {
    doc.registerFont("CJK", FONT_PATH);
    doc.font("CJK");
    fontReady = true;
  } catch {
    fontReady = false;
  }

  for (const e of applyFilters(entries, opts)) {
    const text = lineOf(e, opts);
    if (fontReady) doc.font("CJK");
    doc.fontSize(11).text(text, { continued: false });
  }

  const chunks: Buffer[] = [];
  return new Promise<Buffer>((resolve, reject) => {
    doc.on("data", (c: Buffer) => chunks.push(c));
    doc.on("end", () => resolve(Buffer.concat(chunks)));
    doc.on("error", reject);
    doc.end();
  });
}
