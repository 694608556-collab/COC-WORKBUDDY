import request from 'supertest'
import { deflateSync } from 'node:zlib'
import { createApp } from '../app'
import { env } from '../config/env'
import {
  SealError,
  loadSealLog,
  parseSealLink,
  SEAL_API,
} from '../modules/seal/sealClient'
import {
  decodeSealData,
  extractImages,
  firstPlayDate,
  isOoc,
  kindOf,
  parseManualText,
  toPlayDate,
} from '../modules/seal/sealParser'
import type { RawItem } from '../modules/seal/types'

const app = createApp()

function makeItem(over: Partial<RawItem> = {}): RawItem {
  return {
    id: 1,
    nickname: '夏恩',
    IMUserId: '3593972548',
    uniformId: 'QQ:3593972548',
    time: 1788520826,
    message: '记录已经开启',
    isDice: false,
    ...over,
  }
}

function encode(items: RawItem[], version = 1000) {
  return deflateSync(Buffer.from(JSON.stringify({ version, items }), 'utf8')).toString('base64')
}

const FIRST_TIME_DATE = '2026-09-04'

describe('P3 · 海豹链接解析', () => {
  it('从链接里取到 key 与 # 后面的密码', () => {
    expect(parseSealLink('https://log.weizaima.com/?key=jmyh#201454')).toEqual({
      key: 'jmyh',
      password: '201454',
    })
  })

  it('没有 # 时密码为空串', () => {
    expect(parseSealLink('https://log.weizaima.com/?key=jmyh')).toEqual({
      key: 'jmyh',
      password: '',
    })
  })

  it('不是链接或没有 key 时返回 null', () => {
    expect(parseSealLink('随便一段文字')).toBeNull()
    expect(parseSealLink('https://log.weizaima.com/')).toBeNull()
  })
})

describe('P3 · 日志解码与条目归类', () => {
  it('base64 + zlib 能解出条目', () => {
    const decoded = decodeSealData(encode([makeItem(), makeItem({ id: 2 })]))
    expect(decoded.items).toHaveLength(2)
    expect(decoded.version).toBe(1000)
  })

  it('骰子、图片、场外发言能分开', () => {
    expect(kindOf(makeItem({ isDice: true }), '.r 1d100')).toBe('dice')
    expect(kindOf(makeItem({ message: '[CQ:image,file=a.jpg,url=http://x/y.jpg]' }), '[CQ:image,file=a.jpg,url=http://x/y.jpg]')).toBe('image')
    expect(kindOf(makeItem({ message: '（我去倒杯水）' }), '（我去倒杯水）')).toBe('ooc')
    expect(kindOf(makeItem({ message: '我们走进屋子' }), '我们走进屋子')).toBe('dialog')
  })

  it('半角与全角括号都算场外', () => {
    expect(isOoc('(稍等)')).toBe(true)
    expect(isOoc('（稍等）')).toBe(true)
    expect(isOoc('(前面还有字) 后面')).toBe(false)
  })

  it('能从 CQ 码里取到图片地址', () => {
    expect(extractImages('看这个[CQ:image,file=a.jpg,url=https://gchat.qpic.cn/abc]')).toEqual([
      'https://gchat.qpic.cn/abc',
    ])
  })

  it('跑团日期取第一条的时间（东八区）', () => {
    expect(toPlayDate(1788520826)).toBe(FIRST_TIME_DATE)
    expect(firstPlayDate([makeItem({ time: 1788520826 }), makeItem({ time: 1788600000 })])).toBe(
      FIRST_TIME_DATE
    )
    expect(firstPlayDate([])).toBeNull()
  })
})

describe('P3 · 抓取（用假的联网请求）', () => {
  const okItems = [makeItem(), makeItem({ id: 2, message: '我们走进屋子' })]

  function respond(body: unknown, status = 200) {
    return {
      ok: status >= 200 && status < 300,
      status,
      json: async () => body,
    } as unknown as Response
  }

  it('正常返回时状态为有效，并带回日期与条数', async () => {
    const seen: string[] = []
    const res = await loadSealLog({ key: 'jmyh', password: '201454' }, async (url) => {
      seen.push(url)
      return respond({ name: '假面之夜', data: encode(okItems), created_at: '', updated_at: '' })
    })
    expect(res.status).toBe('valid')
    expect(res.playDate).toBe(FIRST_TIME_DATE)
    expect(res.count).toBe(2)
    expect(res.payload?.entries[0].nickname).toBe('夏恩')
    expect(seen[0]).toBe(`${SEAL_API}?key=jmyh&password=201454`)
  })

  it('404 判为失效', async () => {
    await expect(
      loadSealLog({ key: 'nope', password: '1' }, async () => respond({}, 404))
    ).rejects.toMatchObject({ status: 'dead' })
  })

  it('返回体里没有日志内容也判为失效', async () => {
    await expect(
      loadSealLog({ key: 'nope', password: '1' }, async () => respond({ data: '' }))
    ).rejects.toMatchObject({ status: 'dead' })
  })

  it('断网时判为离线，并给出原因', async () => {
    let err: unknown
    try {
      await loadSealLog({ key: 'a', password: '1' }, async () => {
        throw new Error('getaddrinfo ENOTFOUND')
      })
    } catch (e) {
      err = e
    }
    expect(err).toBeInstanceOf(SealError)
    expect((err as SealError).status).toBe('offline')
    expect((err as SealError).message).toContain('ENOTFOUND')
  })
})

describe('P3 · 接口（/api/seal）', () => {
  const originalFetch = globalThis.fetch

  afterEach(() => {
    globalThis.fetch = originalFetch
  })

  function mockFetch(body: unknown, status = 200) {
    globalThis.fetch = (async () =>
      ({
        ok: status >= 200 && status < 300,
        status,
        json: async () => body,
      }) as unknown as Response) as unknown as typeof globalThis.fetch
  }

  it('检测有效链接：返回有效与跑团日期', async () => {
    mockFetch({ name: '假面之夜', data: encode([makeItem()]) })
    const res = await request(app)
      .post(`${env.API_PREFIX}/seal/check`)
      .send({ link: 'https://log.weizaima.com/?key=jmyh#201454' })
      .expect(200)
    expect(res.body.status).toBe('valid')
    expect(res.body.playDate).toBe(FIRST_TIME_DATE)
    expect(res.body.count).toBe(1)
    expect(res.body.payload).toBeUndefined()
  })

  it('检测失效链接：返回失效，不是 500', async () => {
    mockFetch({}, 404)
    const res = await request(app)
      .post(`${env.API_PREFIX}/seal/check`)
      .send({ link: 'https://log.weizaima.com/?key=nope#1' })
      .expect(200)
    expect(res.body.status).toBe('dead')
  })

  it('断网时返回离线，附带明确提示', async () => {
    globalThis.fetch = (async () => {
      throw new Error('fetch failed')
    }) as unknown as typeof globalThis.fetch
    const res = await request(app)
      .post(`${env.API_PREFIX}/seal/check`)
      .send({ link: 'https://log.weizaima.com/?key=jmyh#201454' })
      .expect(200)
    expect(res.body.status).toBe('offline')
    expect(res.body.message).toContain('连不上海豹服务器')
  })

  it('链接格式不对时给出 400 与提示', async () => {
    const res = await request(app)
      .post(`${env.API_PREFIX}/seal/check`)
      .send({ link: '不是链接' })
      .expect(400)
    expect(res.body.message).toContain('链接格式不正确')
  })

  it('抓取接口带回完整正文', async () => {
    mockFetch({ data: encode([makeItem(), makeItem({ id: 2, message: '我们走进屋子' })]) })
    const res = await request(app)
      .post(`${env.API_PREFIX}/seal/fetch`)
      .send({ link: 'https://log.weizaima.com/?key=jmyh#201454' })
      .expect(200)
    expect(res.body.payload.entries).toHaveLength(2)
  })
})

describe('P3 · 手动粘贴的记录文本', () => {
  it('解析出跑团日期与发言者', async () => {
    const text = [
      '2026-09-04 20:14:26 夏恩(QQ:3593972548): 一趟新的旅程开始了',
      '2026-09-04 20:15:01 艾伦: 我们走进屋子',
      '（我去倒杯水）',
    ].join('\n')
    const res = await request(app)
      .post(`${env.API_PREFIX}/seal/parse-text`)
      .send({ text })
      .expect(200)

    expect(res.body.playDate).toBe('2026-09-04')
    expect(res.body.count).toBe(3)
    expect(res.body.payload.entries[0].nickname).toBe('夏恩')
    expect(res.body.payload.entries[0].account).toBe('QQ:3593972548')
    expect(res.body.payload.entries[0].message).toBe('一趟新的旅程开始了')
    expect(res.body.payload.entries[2].kind).toBe('ooc')
  })

  it('文本里没有日期时日期留空', () => {
    const parsed = parseManualText('夏恩: 我们走进屋子')
    expect(parsed.playDate).toBeNull()
    expect(parsed.entries).toHaveLength(1)
  })

  it('空文本返回 400', async () => {
    await request(app).post(`${env.API_PREFIX}/seal/parse-text`).send({ text: '  ' }).expect(400)
  })
})
