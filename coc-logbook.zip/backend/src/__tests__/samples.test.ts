import { readFileSync } from "fs";
import { join } from "path";
import { parseManualText } from "../modules/seal/sealParser";

const sample = (name: string) =>
  readFileSync(join(__dirname, "..", "..", "..", "samples", name), "utf8");

describe("交付样例 · 手动粘贴原文", () => {
  it("04 日志原文能被解析出日期与全部发言", () => {
    const text = sample("04-手动粘贴样例-日志原文.txt");
    const parsed = parseManualText(text);

    expect(parsed.playDate).toBe("2025-03-08");
    expect(parsed.entries).toHaveLength(8);

    const first = parsed.entries[0];
    expect(first.nickname).toBe("张三");
    expect(first.account).toBe("QQ:10000");
    expect(first.message).toContain("布莱克伍德宅邸");

    // 骰子指令单独成条，便于后续按过滤选项剔除
    expect(parsed.entries.some((e) => e.message.includes(".ra"))).toBe(true);

    // 时间戳按东八区落库，顺序递增
    const times = parsed.entries.map((e) => e.time);
    expect(times.every((t) => t > 0)).toBe(true);
    expect([...times].sort((a, b) => a - b)).toEqual(times);
  });
});
