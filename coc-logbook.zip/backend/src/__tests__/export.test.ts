import request from "supertest";
import { createApp } from "../app";
import { env } from "../config/env";
import { applyFilters, imageRuns, renderDocx, renderPdf, renderRaw, renderTxt, __setImageFetcher } from "../modules/seal/render";
import { DEFAULT_EXPORT_OPTIONS } from "../modules/seal/types";
import type { LogEntry } from "../modules/seal/types";

const app = createApp();

const entries: LogEntry[] = [
  {
    id: 1,
    nickname: "夏恩",
    account: "QQ:3593972548",
    time: 1788520826,
    message: "我们走进屋子",
    isDice: false,
    kind: "dialog",
    images: [],
  },
  {
    id: 2,
    nickname: "骰子",
    account: "QQ:1",
    time: 1788520900,
    message: ".r 1d100=80",
    isDice: true,
    kind: "dice",
    images: [],
  },
  {
    id: 3,
    nickname: "艾伦",
    account: "QQ:2",
    time: 1788521000,
    message: "[CQ:image,file=a.jpg,url=http://x/y.jpg]",
    isDice: false,
    kind: "image",
    images: ["http://x/y.jpg"],
  },
  {
    id: 4,
    nickname: "贝拉",
    account: "QQ:3",
    time: 1788521100,
    message: "（我去倒杯水）",
    isDice: false,
    kind: "ooc",
    images: [],
  },
];

describe("P4 · 过滤选项", () => {
  it("默认只隐藏平台账号与年月日", () => {
    const out = renderTxt(entries, DEFAULT_EXPORT_OPTIONS);
    expect(out).toContain("夏恩");
    expect(out).toContain("我们走进屋子");
    expect(out).not.toContain("QQ:3593972548"); // 账号隐藏
    expect(out).not.toMatch(/2026-09-04/); // 年月日不展示
  });

  it("骰子指令过滤：去掉骰子行", () => {
    const out = renderTxt(entries, { ...DEFAULT_EXPORT_OPTIONS, filterDice: true });
    expect(out).not.toContain(".r 1d100");
  });

  it("表情图片过滤：去掉图片行", () => {
    const out = renderTxt(entries, { ...DEFAULT_EXPORT_OPTIONS, filterImage: true });
    expect(out).not.toContain("http://x/y.jpg");
  });

  it("场外发言过滤：去掉括号行", () => {
    const out = renderTxt(entries, { ...DEFAULT_EXPORT_OPTIONS, filterOoc: true });
    expect(out).not.toContain("我去倒杯水");
  });

  it("时间显示过滤：去掉时分", () => {
    const out = renderTxt(entries, { ...DEFAULT_EXPORT_OPTIONS, hideDate: false, filterTime: true });
    expect(out).toMatch(/2026-09-04/);
    expect(out).not.toMatch(/20:14/);
  });

  it("平台账号隐藏：保留账号", () => {
    const out = renderTxt(entries, { ...DEFAULT_EXPORT_OPTIONS, hideAccount: false });
    expect(out).toContain("QQ:3593972548");
  });

  it("首行缩进对齐：消息前加全角空格", () => {
    const out = renderTxt(entries, { ...DEFAULT_EXPORT_OPTIONS, hideDate: false, filterTime: false, indentFirstLine: true });
    expect(out).toContain("　　我们走进屋子");
  });

  it("darkMode 不影响纯文本导出内容", () => {
    const a = renderTxt(entries, DEFAULT_EXPORT_OPTIONS);
    const b = renderTxt(entries, { ...DEFAULT_EXPORT_OPTIONS, darkMode: true });
    expect(a).toBe(b);
  });

  it("applyFilters 不改原数组", () => {
    const copy = entries.map((e) => ({ ...e }));
    applyFilters(entries, { ...DEFAULT_EXPORT_OPTIONS, filterDice: true });
    expect(entries).toEqual(copy);
  });
});

describe("P3 · 原始文件（不过滤、不转换）", () => {
  it("renderRaw 保留骰子、图片、场外与时间账号", () => {
    const out = renderRaw(entries);
    expect(out).toContain("我们走进屋子");
    expect(out).toContain(".r 1d100=80"); // 骰子不过滤
    expect(out).toContain("（我去倒杯水）"); // 场外不过滤
    expect(out).toContain("[CQ:image,file=a.jpg,url=http://x/y.jpg]"); // 原始 CQ 码保留
    expect(out).toContain("QQ:3593972548"); // 账号保留
    expect(out).toMatch(/2026-09-04 \d{2}:\d{2}/); // 完整时间保留
  });

  it("raw 导出的内容与过滤选项无关", () => {
    const a = renderRaw(entries);
    const b = renderRaw(entries.filter((e) => !e.isDice));
    expect(a).not.toBe(b);
    expect(renderRaw(entries)).toBe(a);
  });

  it("/api/seal/export?type=raw 返回 txt", async () => {
    const res = await request(app)
      .post(`${env.API_PREFIX}/seal/export`)
      .send({ entries, options: { ...DEFAULT_EXPORT_OPTIONS, filterDice: true, filterOoc: true }, type: "raw" })
      .expect(200);
    expect(res.body.ext).toBe("txt");
    const text = Buffer.from(res.body.data, "base64").toString("utf8");
    expect(text).toContain(".r 1d100=80");
    expect(text).toContain("我去倒杯水");
  });
});

describe("P3 · 带图 doc 内嵌图片", () => {
  const PNG = Buffer.from(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8DwHwAFAAH/q842iQAAAABJRU5ErkJggg==",
    "base64",
  );

  afterEach(() => {
    __setImageFetcher(null);
  });

  it("抓到图片时内嵌进 docx，文档里出现图片资源", async () => {
    const asked: string[] = [];
    __setImageFetcher(async (url) => {
      asked.push(url);
      return PNG;
    });
    const buf = await renderDocx(entries, { ...DEFAULT_EXPORT_OPTIONS, filterImage: false }, true);
    expect(asked).toEqual(["http://x/y.jpg"]);
    const zip = buf.toString("latin1");
    expect(zip).toMatch(/media\/[^"']+\.png/); // docx 里出现内嵌的 png 资源
    expect(buf[0]).toBe(0x50);
  });

  it("抓图失败时降级为占位文字，整份文档照常生成", async () => {
    __setImageFetcher(async () => null);
    const buf = await renderDocx(entries, { ...DEFAULT_EXPORT_OPTIONS, filterImage: false }, true);
    expect(buf[0]).toBe(0x50);
    expect(buf[1]).toBe(0x4b);
    expect(buf.length).toBeGreaterThan(1000);
  });

  it("不请求内嵌时（普通 docx）不抓图", async () => {
    let asked = 0;
    __setImageFetcher(async () => {
      asked++;
      return PNG;
    });
    const buf = await renderDocx(entries, DEFAULT_EXPORT_OPTIONS, false);
    expect(asked).toBe(0);
    expect(buf[0]).toBe(0x50);
  });

  it("imageRuns 跳过非图片数据与失败的请求", async () => {
    __setImageFetcher(async () => Buffer.from("not an image"));
    expect(await imageRuns(["http://x/y.jpg"])).toHaveLength(0);
  });
});

describe("P4 · 后端渲染", () => {
  it("renderDocx 输出 Office Open XML（以 PK 开头）", async () => {
    const buf = await renderDocx(entries, DEFAULT_EXPORT_OPTIONS);
    expect(buf[0]).toBe(0x50); // P
    expect(buf[1]).toBe(0x4b); // K
    expect(buf.length).toBeGreaterThan(1000);
  });

  it("renderPdf 输出合法的 PDF（以 %PDF 开头）", async () => {
    const buf = await renderPdf(entries, DEFAULT_EXPORT_OPTIONS);
    expect(buf.slice(0, 5).toString()).toBe("%PDF-");
    expect(buf.length).toBeGreaterThan(1000);
  });
});

describe("P4 · /api/seal/export", () => {
  const body = { entries, options: DEFAULT_EXPORT_OPTIONS };

  it("txt：返回 base64 纯文本，内容含对话不含账号", async () => {
    const res = await request(app).post(`${env.API_PREFIX}/seal/export`).send({ ...body, type: "txt" }).expect(200);
    const text = Buffer.from(res.body.data, "base64").toString("utf8");
    expect(res.body.ext).toBe("txt");
    expect(text).toContain("我们走进屋子");
    expect(text).not.toContain("QQ:3593972548");
  });

  it("docx：返回 Office 文档", async () => {
    const res = await request(app).post(`${env.API_PREFIX}/seal/export`).send({ ...body, type: "docx" }).expect(200);
    const buf = Buffer.from(res.body.data, "base64");
    expect(res.body.ext).toBe("docx");
    expect(buf[0]).toBe(0x50);
  });

  it("pdf：返回 PDF", async () => {
    const res = await request(app).post(`${env.API_PREFIX}/seal/export`).send({ ...body, type: "pdf" }).expect(200);
    const buf = Buffer.from(res.body.data, "base64");
    expect(res.body.ext).toBe("pdf");
    expect(buf.slice(0, 5).toString()).toBe("%PDF-");
  });

  it("不支持的类型返回 400", async () => {
    await request(app).post(`${env.API_PREFIX}/seal/export`).send({ ...body, type: "mp3" }).expect(400);
  });
});
